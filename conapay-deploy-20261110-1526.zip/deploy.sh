#!/bin/bash

# ==========================================
# ConaPay 官网 一键部署脚本
# 适用于全新 Ubuntu 云服务器（以 root 身份运行，无需 sudo）
#
# 用法：
#   1. 本地执行 ./pack.sh 生成干净的上传包（自动排除 node_modules / dist / .backup / 竞品代码目录等）
#   2. 上传到服务器后 unzip 解压（更新时解压覆盖到同一目录即可）
#   3. chmod +x deploy.sh
#   4. ./deploy.sh
#   更新网站时重复以上步骤即可（脚本可重复执行，更新过程中网站不下线）
#
# 脚本会自动完成：
#   - 系统依赖 (curl/unzip/git 等)
#   - Node.js / npm 安装
#   - 项目依赖安装 + 构建 (npm ci && npm run build)
#   - Docker / Docker Compose 安装
#   - Nginx 容器化部署 (静态资源 + Gzip + SPA 路由)
#   - 零停机发布：构建成功后才把新版本同步到线上目录 site/，构建失败时旧版本继续在线
#   - 低内存 VPS 自动开启 swap，防止构建被 OOM Kill
#   - 防火墙放行 80/443（若 ufw 已启用）
# ==========================================

set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}>>> $1${NC}"; }
warn() { echo -e "${YELLOW}!!! $1${NC}"; }
err()  { echo -e "${RED}✗ $1${NC}"; }

# 脚本所在目录 = 项目根目录（不管解压到哪个路径都能正确工作）
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

# ---------- 0. 权限检查 ----------
if [ "$(id -u)" -ne 0 ]; then
    err "请以 root 用户运行本脚本（当前脚本假设无需 sudo，即你已经是 root）。"
    exit 1
fi

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN} ConaPay 部署开始，项目目录: $PROJECT_DIR ${NC}"
echo -e "${GREEN}=============================================${NC}"

# ---------- 1. 基础系统依赖 ----------
log "1. 更新软件源并安装基础依赖 (curl/unzip/ca-certificates/gnupg)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl unzip ca-certificates gnupg git rsync

# ---------- 2. 低内存服务器自动开启 swap ----------
log "2. 检查内存与 swap（防止构建时被 OOM 杀死）..."
MEM_TOTAL_MB=$(free -m | awk '/^Mem:/{print $2}')
SWAP_TOTAL_MB=$(free -m | awk '/^Swap:/{print $2}')
if [ "$SWAP_TOTAL_MB" -eq 0 ] && [ "$MEM_TOTAL_MB" -lt 4096 ]; then
    if [ ! -f /swapfile ]; then
        warn "检测到内存较小 (${MEM_TOTAL_MB}MB) 且无 swap，正在创建 2G swap 文件..."
        fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
        chmod 600 /swapfile
        mkswap /swapfile
        swapon /swapfile
        grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
        log "swap 创建完成。"
    else
        swapon /swapfile 2>/dev/null || true
    fi
else
    echo "内存/swap 充足，跳过。"
fi

# ---------- 3. 安装 Node.js / npm ----------
log "3. 检查并安装 Node.js (LTS 22.x，Vite 7 需要 Node >= 20.19)..."
NEED_NODE_INSTALL=1
if command -v node &> /dev/null; then
    NODE_MAJOR=$(node -v | sed -E 's/^v([0-9]+)\..*/\1/')
    NODE_MINOR=$(node -v | sed -E 's/^v[0-9]+\.([0-9]+).*/\1/')
    if [ "$NODE_MAJOR" -ge 22 ] || { [ "$NODE_MAJOR" -eq 20 ] && [ "$NODE_MINOR" -ge 19 ]; }; then
        NEED_NODE_INSTALL=0
        echo "已安装 Node.js $(node -v)，跳过安装。"
    else
        warn "当前 Node.js $(node -v) 版本过低，将升级到 22.x"
    fi
fi
if [ "$NEED_NODE_INSTALL" -eq 1 ]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
fi
echo "Node: $(node -v)  npm: $(npm -v)"

# ---------- 4. 安装依赖并构建前端 ----------
log "4. 安装项目依赖并执行生产构建 (npm ci && npm run build)..."
if [ -f package-lock.json ]; then
    npm ci --no-audit --no-fund || npm install --no-audit --no-fund
else
    npm install --no-audit --no-fund
fi
# 只清理构建目录；线上服务读取的是 site/，构建期间网站照常在线
rm -rf "$PROJECT_DIR/dist" "$PROJECT_DIR/dist-ssr"
if ! npm run build; then
    err "构建失败，线上网站保持旧版本不变。请检查上面的构建日志。"
    exit 1
fi

if [ ! -f "$PROJECT_DIR/dist/index.html" ] || [ ! -d "$PROJECT_DIR/dist/assets" ]; then
    err "构建产物不完整（缺少 dist/index.html 或 dist/assets），线上网站保持旧版本不变。"
    exit 1
fi
log "构建成功，产物位于 $PROJECT_DIR/dist"

# ---------- 5. 安装 Docker ----------
log "5. 环境检查与 Docker 安装..."
if ! command -v docker &> /dev/null; then
    echo "Docker 未安装，正在自动安装..."
    curl -fsSL https://get.docker.com | bash -s docker
    systemctl enable docker
    systemctl start docker
else
    echo "Docker 已安装，跳过安装步骤。"
fi

# ---------- 6. 生成 Nginx 配置 ----------
log "6. 生成 Nginx 高性能配置..."
mkdir -p "$PROJECT_DIR/conf"

# 安全响应头单独成文件，每个 location 都 include：
# Nginx 的子级 location 只要自己写了 add_header，就不再继承上级的 add_header，容易漏掉
cat > "$PROJECT_DIR/conf/security-headers.conf" <<'NGINX'
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header X-Frame-Options "SAMEORIGIN" always;
NGINX

cat > "$PROJECT_DIR/conf/default.conf" <<'NGINX'
server {
    listen 80;
    server_name _;

    root /usr/share/nginx/html;
    index index.html;

    # 安全设置：隐藏 Nginx 版本号 + 基础安全响应头
    server_tokens off;
    include /etc/nginx/snippets/security-headers.conf;

    # 性能优化：开启 Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_min_length 256;
    gzip_types
        text/plain
        text/css
        text/javascript
        application/javascript
        application/json
        application/xml
        image/svg+xml
        font/woff2;

    # 使用构建时预压缩的 .gz 文件（vite-plugin-compression 生成）
    gzip_static on;

    # 旧的"全球覆盖"页已并入首页通道板块，301 保留 SEO 权重
    location = /network { return 301 /#coverage; }
    location = /network/ { return 301 /#coverage; }

    # 已删除的法律条款页，301 回首页
    location ~ ^/(terms|privacy|cookies)/?$ { return 301 /; }

    # 预渲染页面（/payment-methods/xxx 等）优先命中各自的 index.html，
    # 其余路径回退到 SPA 入口，防止刷新 404
    # 页面 HTML 不做长缓存，保证发布后立即生效
    location / {
        try_files $uri $uri/index.html /index.html;
        add_header Cache-Control "no-cache";
        include /etc/nginx/snippets/security-headers.conf;
    }

    # 构建产物带哈希（含 three.js 地球分包、背景视频、页面图片），可长期缓存；视频支持拖动播放（Range）
    location ^~ /assets/ {
        expires 1y;
        add_header Cache-Control "public, no-transform, immutable";
        include /etc/nginx/snippets/security-headers.conf;
        access_log off;
    }

    # 其它静态文件（logo、robots、sitemap 等）短缓存
    location ~* \.(png|jpg|jpeg|gif|ico|svg|webp|avif|woff2|ttf|txt|xml|mp4|webm)$ {
        expires 1d;
        add_header Cache-Control "public";
        include /etc/nginx/snippets/security-headers.conf;
        access_log off;
    }

    # 健康检查端点 (可选，给云监控用)
    location /health {
        access_log off;
        default_type text/plain;
        return 200 'healthy';
    }
}
NGINX

# ---------- 7. 生成 Docker Compose 配置 ----------
log "7. 生成 Docker Compose 配置..."
# 线上目录是 site/（不是 dist/）：构建期间与构建失败时都不影响正在运行的网站
cat > "$PROJECT_DIR/docker-compose.yml" <<'YAML'
services:
  web:
    image: nginx:alpine
    container_name: conapay_web
    restart: always
    ports:
      - "80:80"
    volumes:
      - ./site:/usr/share/nginx/html:ro
      - ./conf/default.conf:/etc/nginx/conf.d/default.conf:ro
      - ./conf/security-headers.conf:/etc/nginx/snippets/security-headers.conf:ro
    environment:
      - TZ=Asia/Shanghai
YAML

# ---------- 8. 发布新版本（零停机） ----------
log "8. 发布新版本到线上目录 site/ ..."
SITE_DIR="$PROJECT_DIR/site"
mkdir -p "$SITE_DIR/assets"
# 顺序很重要：
#   ① 先放新的带哈希资源（不删旧的）→ 此刻线上旧页面仍完整可用
#   ② 再替换页面 HTML / sitemap 等（--delete 不碰 assets/）→ 访客刷新即拿到新版
#   ③ 旧哈希资源保留 7 天再清理，避免正在浏览旧页面的访客懒加载分包时 404
rsync -a "$PROJECT_DIR/dist/assets/" "$SITE_DIR/assets/"
rsync -a --delete --exclude '/assets/' "$PROJECT_DIR/dist/" "$SITE_DIR/"
find "$SITE_DIR/assets" -type f -mtime +7 -print0 | while IFS= read -r -d '' f; do
    [ -e "$PROJECT_DIR/dist/assets/$(basename "$f")" ] || rm -f "$f"
done

log "启动/更新 Nginx 容器..."
# 同名容器若不是由本目录的 Compose 管理（旧版本从其它目录部署过），先移除再重建
EXISTING_DIR=$(docker inspect -f '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}' conapay_web 2>/dev/null || true)
if docker inspect conapay_web >/dev/null 2>&1 && [ "$EXISTING_DIR" != "$PROJECT_DIR" ]; then
    warn "发现非本目录管理的旧容器 conapay_web（${EXISTING_DIR:-未知来源}），移除后重建..."
    docker rm -f conapay_web >/dev/null
fi
# 只有 compose 配置变化（如首次从 dist/ 切换到 site/）才会重建容器，否则容器保持运行
docker compose up -d
# 配置文件是绑定挂载的，内容已经更新；先校验再热重载，校验失败则 Nginx 继续用旧配置服务
if docker exec conapay_web nginx -t >/dev/null 2>&1; then
    docker exec conapay_web nginx -s reload >/dev/null
else
    err "Nginx 配置校验失败（网站仍以旧配置运行），详情："
    docker exec conapay_web nginx -t || true
    exit 1
fi

# ---------- 9. 防火墙放行（若 ufw 已启用才处理，避免误开防火墙） ----------
if command -v ufw &> /dev/null && ufw status | grep -q "Status: active"; then
    log "9. 检测到 ufw 已启用，放行 80/443 端口..."
    ufw allow 80/tcp || true
    ufw allow 443/tcp || true
else
    echo "ufw 未启用，跳过防火墙配置（云厂商安全组请自行确保 80 端口已放行）。"
fi

# ---------- 10. 健康检查 ----------
# 最多等 15 秒；同时确认首页和一个预渲染子页面都能正常返回
HEALTH="⚠️  未响应，请用 docker logs conapay_web 排查"
for _ in $(seq 1 15); do
    if curl -sf http://localhost/health > /dev/null \
        && curl -sf -o /dev/null http://localhost/ \
        && curl -sf -o /dev/null http://localhost/payment-methods/united-states; then
        HEALTH="✅ 正常（首页与子页面均可访问）"
        break
    fi
    sleep 1
done

PUBLIC_IP=$(curl -s --max-time 5 ifconfig.me || echo "获取失败")

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN} ✅ 部署成功！ConaPay 官网已上线。 ${NC}"
echo -e "${GREEN} 🌍 访问地址: http://${PUBLIC_IP} ${NC}"
echo -e "${GREEN} 🩺 健康检查: ${HEALTH} ${NC}"
echo -e "${GREEN} ⚠️  如使用 Cloudflare，请确保已开启 Proxy（小黄云）。 ${NC}"
echo -e "${GREEN}=============================================${NC}"
