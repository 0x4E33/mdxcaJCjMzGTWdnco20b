import { useRef } from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import RailsBackdrop from '../components/visuals/RailsBackdrop';
import { CountUp } from '../components/coverage/shared';
import { COVERAGE_STATS } from '../data/channels';

// Milestone dates: ConaPay started in Feb 2024. The last entry is upcoming.
const MILESTONES = [
    { key: 'genesis', date: 'Feb 2024' },
    { key: 'apac', date: 'Jun 2024' },
    { key: 'smartRouting', date: 'Nov 2024' },
    { key: 'security', date: 'Apr 2025' },
    { key: 'payouts', date: 'Sep 2025' },
    { key: 'regions', date: '2026' },
    { key: 'next', date: '', upcoming: true },
];

/** One milestone: the dot lights up and the text sharpens as it scrolls into view (and stays lit). */
const Milestone = ({ m, t }) => (
    <motion.li
        initial={{ opacity: 0.25, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '0px 0px -30% 0px' }}
        transition={{ duration: 0.5 }}
        className="relative pb-14 pl-10 last:pb-0 md:pl-14"
    >
        <motion.span
            initial={{ scale: 0.6, backgroundColor: 'rgba(255,255,255,0.15)', boxShadow: '0 0 0 0 rgba(255,153,0,0)' }}
            whileInView={{ scale: 1, backgroundColor: m.upcoming ? 'rgba(7,7,10,1)' : '#FF9900', boxShadow: '0 0 24px 2px rgba(255,153,0,0.55)' }}
            viewport={{ once: true, margin: '0px 0px -30% 0px' }}
            transition={{ duration: 0.4 }}
            className={`absolute left-0 top-1.5 h-3.5 w-3.5 -translate-x-1/2 rounded-full ${m.upcoming ? 'border-2 border-dashed border-primary' : ''}`}
        />
        <p className={`font-mono text-xs tracking-wide ${m.upcoming ? 'text-primary' : 'text-text-muted'}`}>
            {m.upcoming ? t('roadmap.status.active') : m.date}
        </p>
        <h2 className="mt-2 font-sans text-2xl font-semibold text-white md:text-[1.75rem]">{t(`roadmap.milestones.${m.key}.title`)}</h2>
        <p className="mt-2 max-w-xl text-base leading-relaxed text-text-body md:text-lg">{t(`roadmap.milestones.${m.key}.desc`)}</p>
    </motion.li>
);

const Roadmap = () => {
    const { t } = useTranslation();
    const listRef = useRef(null);
    const { scrollYProgress } = useScroll({ target: listRef, offset: ['start 55%', 'end 55%'] });
    const fill = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 });

    const live = [
        [COVERAGE_STATS.markets, '', t('about.stats.markets')],
        [COVERAGE_STATS.payinMethods, '+', t('about.stats.methods')],
        [COVERAGE_STATS.payoutMarkets, '', t('about.stats.payout')],
    ];

    return (
        <div className="relative pb-24">
            <RailsBackdrop height={600} />

            <div className="container relative mx-auto grid gap-14 px-5 pt-14 md:pt-24 lg:grid-cols-[1fr_1.4fr] lg:gap-20">
                {/* Sticky intro */}
                <aside className="lg:sticky lg:top-32 lg:self-start">
                    <span style={{ animationDelay: '0ms' }} className="eyebrow animate-rise">{t('roadmap.eyebrow')}</span>
                    <h1 style={{ animationDelay: '60ms' }} className="animate-rise mt-6 text-4xl font-bold leading-[1.06] text-white md:text-6xl">
                        {t('roadmap.titlePrefix')} {t('roadmap.titleHighlight') && <span className="text-ember">{t('roadmap.titleHighlight')}</span>}
                    </h1>
                    <p style={{ animationDelay: '120ms' }} className="animate-rise mt-5 max-w-md text-lg text-text-body">{t('roadmap.subtitle')}</p>

                    <div style={{ animationDelay: '180ms' }} className="animate-rise mt-10 border-t border-white/[0.08] pt-6">
                        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">{t('roadmap.nowLive')}</p>
                        <dl className="mt-4 grid grid-cols-3 gap-4">
                            {live.map(([v, suf, label]) => (
                                <div key={label} className="flex flex-col-reverse">
                                    <dt className="mt-1 text-xs text-text-muted">{label}</dt>
                                    <dd className="font-display text-3xl font-bold text-white"><CountUp value={v} suffix={suf} /></dd>
                                </div>
                            ))}
                        </dl>
                    </div>
                </aside>

                {/* Timeline */}
                <div ref={listRef} className="relative">
                    <div className="absolute bottom-2 left-0 top-2 w-px bg-white/[0.08]" aria-hidden="true">
                        <motion.div style={{ scaleY: fill }} className="h-full w-full origin-top bg-gradient-to-b from-primary-soft via-primary to-primary/0" />
                    </div>
                    <ol>
                        {MILESTONES.map((m) => <Milestone key={m.key} m={m} t={t} />)}
                    </ol>
                </div>
            </div>

            {/* CTA */}
            <section className="container relative mx-auto mt-28 px-5">
                <div className="flex flex-col items-start justify-between gap-6 border-t border-white/[0.08] pt-10 md:flex-row md:items-center">
                    <div>
                        <h2 className="text-2xl font-bold text-white md:text-3xl">{t('roadmap.cta.title')}</h2>
                        <p className="mt-2 text-text-body">{t('roadmap.cta.desc')}</p>
                    </div>
                    <Link to="/contact" className="btn-primary shrink-0 max-sm:w-full">{t('roadmap.cta.button')} <ArrowRight size={18} /></Link>
                </div>
            </section>
        </div>
    );
};

export default Roadmap;
