import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import RailsBackdrop from '../components/visuals/RailsBackdrop';
import { INDUSTRIES, industryPhoto } from '../data/industries';

/** Photo with a slow push-in and a warm dark grade. */
const IndustryPhoto = ({ ind }) => {
    const src = industryPhoto(ind.id);
    return (
        <div className="group relative aspect-[4/3] overflow-hidden rounded-[28px] border border-white/[0.08] bg-surface-2 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.95)]">
            {src ? (
                <motion.img
                    src={src} alt="" loading="lazy" decoding="async"
                    initial={{ scale: 1.12 }} whileInView={{ scale: 1.02 }} viewport={{ once: true }}
                    transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute inset-0 h-full w-full object-cover"
                />
            ) : (
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,153,0,0.25),transparent_60%)]" />
            )}
            {/* grade: warm tint + soft dark vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent" />
            <div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(255,120,0,0.2),transparent_45%)] mix-blend-overlay" />
            <div className="pointer-events-none absolute inset-0 rounded-[28px] ring-1 ring-inset ring-white/[0.06]" />

        </div>
    );
};

const Industries = () => {
    const { t } = useTranslation();
    const [active, setActive] = useState(INDUSTRIES[0].id);

    // Highlight the jump-nav pill for the section in view
    useEffect(() => {
        const io = new IntersectionObserver((entries) => {
            const hit = entries.filter((e) => e.isIntersecting)[0];
            if (hit) setActive(hit.target.id);
        }, { rootMargin: '-45% 0px -50% 0px' });
        INDUSTRIES.forEach(({ id }) => { const el = document.getElementById(id); if (el) io.observe(el); });
        return () => io.disconnect();
    }, []);

    return (
        <div className="relative pb-24">
            <RailsBackdrop height={640} />

            <section className="container relative mx-auto px-5 pt-14 text-center md:pt-24">
                <span style={{ animationDelay: '0ms' }} className="eyebrow animate-rise">{t('nav.solutions')}</span>
                <h1 style={{ animationDelay: '60ms' }} className="animate-rise mx-auto mt-6 max-w-4xl text-4xl font-bold leading-[1.06] text-white md:text-6xl">
                    {t('industries.titlePrefix')} <span className="text-ember">{t('industries.titleHighlight')}</span>
                </h1>
                <p style={{ animationDelay: '120ms' }} className="animate-rise mx-auto mt-6 max-w-2xl text-lg text-text-body">{t('industries.subtitle')}</p>
            </section>

            {/* Jump nav */}
            <nav aria-label={t('industries.jump')} className="sticky top-20 z-30 mt-12 border-y border-white/[0.06] bg-background/80 backdrop-blur-xl">
                <ul className="no-scrollbar mx-auto flex w-max max-w-full gap-1 overflow-x-auto px-5 py-3">
                    {INDUSTRIES.map(({ id, icon: Icon }) => (
                        <li key={id} className="shrink-0">
                            <a href={`#${id}`}
                                className={`inline-flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-medium transition-colors ${active === id ? 'bg-primary/15 text-primary ring-1 ring-primary/40' : 'text-text-body hover:bg-white/[0.05] hover:text-white'}`}>
                                <Icon size={15} /> {t(`industries.items.${id}.title`)}
                            </a>
                        </li>
                    ))}
                </ul>
            </nav>

            <div className="container relative mx-auto mt-16 space-y-24 px-5 md:mt-24 md:space-y-32">
                {INDUSTRIES.map((ind, i) => {
                    const features = t(`industries.items.${ind.id}.features`, { returnObjects: true });
                    const Icon = ind.icon;
                    return (
                        <section key={ind.id} id={ind.id} className="grid scroll-mt-40 items-center gap-10 max-sm:gap-7 lg:grid-cols-2 lg:gap-16">
                            <motion.div
                                initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }}
                                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                                className={i % 2 ? 'lg:order-2' : ''}
                            >
                                <div className="flex items-center gap-2.5 text-sm font-semibold text-primary">
                                    <Icon size={16} /> {t(`industries.items.${ind.id}.title`)}
                                </div>
                                <h2 className="mt-5 text-3xl font-bold leading-tight text-white md:text-[2.6rem]">{t(`industries.items.${ind.id}.tagline`)}</h2>
                                <p className="mt-5 text-lg leading-relaxed text-text-body">{t(`industries.items.${ind.id}.content`)}</p>
                                <ul className="mt-7 grid gap-3 sm:grid-cols-2">
                                    {Object.values(features || {}).map((f) => (
                                        <li key={f} className="flex items-start gap-3 rounded-xl border border-white/[0.06] bg-white/[0.025] p-3.5 text-sm text-text-heading/90">
                                            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary"><Check size={12} strokeWidth={3} /></span>
                                            {f}
                                        </li>
                                    ))}
                                </ul>
                                <Link to="/contact" className="group mt-8 inline-flex items-center gap-2 font-semibold text-primary transition-colors hover:text-white">
                                    {t('industries.deployCta')} <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
                                </Link>
                            </motion.div>
                            <motion.div
                                initial={{ opacity: 0, y: 32 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }}
                                transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
                                className={`max-lg:order-first ${i % 2 ? 'lg:order-1' : ''}`}
                            >
                                <IndustryPhoto ind={ind} />
                            </motion.div>
                        </section>
                    );
                })}
            </div>
        </div>
    );
};

export default Industries;
