import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { INDUSTRIES, industryPhoto } from '../../data/industries';

/** Home: industry photo cards, each deep-linking to its section on /industries. */
const SolutionsGrid = () => {
    const { t } = useTranslation();

    return (
        <section className="relative z-10 overflow-hidden bg-background py-24 md:py-32">
            <div className="container relative z-10 mx-auto px-5">
                <div className="mb-14 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
                    <h2 className="text-3xl font-bold text-white sm:text-4xl md:text-5xl">
                        {t('home.solutions.title_prefix')} <br />
                        <span className="text-ember">{t('home.solutions.title_highlight')}</span>
                    </h2>
                    <Link to="/industries" className="btn-ghost shrink-0 text-sm">{t('home.solutions.cta')} <ArrowRight size={16} /></Link>
                </div>

                <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
                    {INDUSTRIES.map(({ id }, i) => {
                        const src = industryPhoto(id);
                        return (
                            <motion.div key={id}
                                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                                transition={{ delay: (i % 4) * 0.06 }}>
                                <Link to={`/industries#${id}`}
                                    className="group relative flex aspect-[4/5] flex-col justify-end overflow-hidden rounded-2xl border border-white/[0.08] bg-surface-2 p-4 sm:aspect-[3/4] sm:p-5">
                                    {src && <img src={src} alt="" loading="lazy" decoding="async" className="absolute inset-0 h-full w-full object-cover opacity-70 transition-all duration-700 group-hover:scale-105 group-hover:opacity-90" />}
                                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/5" />
                                    <span className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full border border-white/15 bg-background/40 text-white opacity-0 backdrop-blur-md transition-all duration-300 group-hover:opacity-100 sm:right-5 sm:top-5">
                                        <ArrowUpRight size={15} />
                                    </span>
                                    <div className="relative">
                                        <span className="mb-3 block h-0.5 w-6 rounded-full bg-primary transition-all duration-500 group-hover:w-12" />
                                        <h3 className="text-base font-bold text-white sm:text-lg">{t(`home.solutions.items.${id}.title`)}</h3>
                                        <p className="mt-1 line-clamp-2 text-xs text-text-body sm:text-sm">{t(`home.solutions.items.${id}.desc`)}</p>
                                    </div>
                                </Link>
                            </motion.div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
};

export default SolutionsGrid;
