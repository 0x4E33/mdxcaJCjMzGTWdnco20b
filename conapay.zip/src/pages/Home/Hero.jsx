import { useCallback, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ChevronDown, Zap, Activity, GitBranch, Check, Move } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getMarket, marketName } from '../../data/channels';
import { Flag } from '../../components/coverage/shared';
import PaymentGlobe from '../../components/visuals/PaymentGlobe';

const POPULAR = ['united-states', 'eurozone', 'united-kingdom', 'brazil', 'mexico', 'philippines', 'nigeria', 'usdt'];

// Deterministic first state so server HTML and the first client render match.
const INITIAL_ROUTE = { market: getMarket('brazil'), method: 'Pix', a: 74.2, b: 81.6, n: 0 };

const short = (method, market) => (method.startsWith(`${market.name.en} `) ? method.slice(market.name.en.length + 1) : method);

/** Smart-routing card: which route the last payment took and why. Success rates kept realistic (~75–86%). */
const RoutingCard = ({ route }) => {
    const { t, i18n } = useTranslation();
    const best = route.b >= route.a ? 'b' : 'a';
    const rows = [['a', t('home.hero.hud.routeA'), route.a], ['b', t('home.hero.hud.routeB'), route.b]];
    return (
        <div className="w-[230px] rounded-2xl border border-white/10 bg-surface/80 p-4 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)] backdrop-blur-xl sm:w-[260px]">
            <div className="flex items-center">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-text-muted">
                    <GitBranch size={12} className="text-primary" /> {t('home.hero.hud.routing')}
                </span>
            </div>
            <AnimatePresence mode="wait" initial={false}>
                <motion.div key={route.n} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.25 }}
                    className="mt-3 flex items-center gap-2.5">
                    <Flag market={route.market} className="h-6 w-8" />
                    <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-white">{short(route.method, route.market)}</p>
                        <p className="truncate text-[11px] text-text-muted">{marketName(route.market, i18n.language)} · {route.market.currency}</p>
                    </div>
                </motion.div>
            </AnimatePresence>
            <div className="mt-3 space-y-2">
                {rows.map(([k, label, v]) => (
                    <div key={k}>
                        <div className="flex items-center justify-between text-[11px]">
                            <span className={k === best ? 'font-semibold text-white' : 'text-text-muted'}>{label}</span>
                            <span className={`inline-flex items-center gap-1 font-mono ${k === best ? 'text-primary' : 'text-text-muted'}`}>
                                {k === best && <Check size={11} />}{v.toFixed(1)}%
                            </span>
                        </div>
                        <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/[0.06]">
                            <div className={`h-full rounded-full transition-[width] duration-700 ease-out ${k === best ? 'bg-gradient-to-r from-primary-soft to-primary' : 'bg-white/20'}`}
                                style={{ width: `${v}%` }} />
                        </div>
                    </div>
                ))}
            </div>
            <p className="mt-3 text-[10px] text-text-muted">{t('home.hero.hud.success')}</p>
        </div>
    );
};

/** Settlement card: each collected payment lands as equivalent USDT. */
const SettlementCard = ({ settled }) => {
    const { t } = useTranslation();
    return (
        <div className="w-[248px] rounded-2xl border border-white/10 bg-surface/80 p-4 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)] backdrop-blur-xl">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-text-muted">{t('home.hero.hud.settlement')}</p>
            <div className="mt-2 flex items-baseline gap-2">
                <span className="font-display text-2xl font-bold text-white">D+0</span>
                <span className="text-xs font-semibold text-[#34D399]">{t('home.hero.hud.settledIn')}</span>
            </div>
            <p className="mt-0.5 text-[10px] text-text-muted">{t('home.hero.hud.d0')}</p>
            <AnimatePresence mode="wait" initial={false}>
                <motion.div key={settled.n} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.25 }}
                    className="mt-3 flex items-center gap-2 rounded-lg bg-white/[0.04] px-2.5 py-2 font-mono text-[11px]">
                    <span className="text-text-heading">{settled.currency}</span>
                    <ArrowRight size={11} className="text-text-muted" />
                    <span className="font-semibold text-[#6EE7B7]">USDT</span>
                    <Check size={12} className="ml-auto text-[#34D399]" />
                </motion.div>
            </AnimatePresence>
        </div>
    );
};

const Hero = () => {
    const { t, i18n } = useTranslation();
    const [route, setRoute] = useState(INITIAL_ROUTE);
    const [settled, setSettled] = useState({ n: 0, currency: 'BRL' });

    const onLaunch = useCallback(({ market, method }) => {
        setRoute((r) => {
            const a = 72 + Math.random() * 8;
            const b = 72 + Math.random() * 13;
            return { market, method, a, b, n: r.n + 1 };
        });
    }, []);
    const onSettle = useCallback(({ market }) => setSettled((s) => ({ n: s.n + 1, currency: market.currency })), []);

    return (
        <section className="relative overflow-hidden pb-6 pt-8 md:pt-12">
            <div className="pointer-events-none absolute inset-0" aria-hidden="true">
                <div className="absolute -top-1/3 left-1/2 h-[900px] w-[1300px] -translate-x-1/2 animate-aurora opacity-50 blur-[100px]"
                    style={{ background: 'conic-gradient(from 200deg at 50% 50%, rgba(255,153,0,0.28), rgba(255,90,54,0.14), rgba(45,212,191,0.08), rgba(255,197,107,0.18), rgba(255,153,0,0.28))', borderRadius: '50%' }} />
                <div className="absolute inset-0 bg-grid-pattern [mask-image:radial-gradient(ellipse_70%_60%_at_50%_30%,black,transparent)]" />
                <div className="absolute inset-0 bg-noise opacity-[0.035] mix-blend-overlay" />
                <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />
            </div>

            <div className="container relative mx-auto px-5">
                <div className="grid items-center gap-4 lg:grid-cols-[1fr_1.05fr] lg:gap-6">
                    <div className="relative z-10 pt-4 lg:pt-0">
                        <div style={{ animationDelay: '0ms' }} className="animate-rise inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] py-1.5 pl-1.5 pr-4 backdrop-blur-md">
                            <span className="rounded-full bg-primary px-2 py-0.5 font-display text-[11px] font-bold tracking-wide text-black">D+0</span>
                            <span className="text-sm text-text-heading/90">{t('home.hero.badge')}</span>
                        </div>

                        <h1 style={{ animationDelay: '80ms' }} className="animate-rise mt-7 text-[2.75rem] font-bold leading-[1.04] text-white sm:text-6xl xl:text-[4.25rem]">
                            {t('home.hero.title_prefix')}
                            <br />
                            <span className="text-ember">{t('home.hero.title_highlight')}</span>
                        </h1>

                        <p style={{ animationDelay: '160ms' }} className="animate-rise mt-6 max-w-xl text-lg leading-relaxed text-text-body">
                            {t('home.hero.subtitle')}
                        </p>

                        <div style={{ animationDelay: '240ms' }} className="animate-rise mt-9 flex flex-col gap-3 sm:flex-row">
                            <Link to="/contact" className="btn-primary text-base">
                                {t('home.hero.cta')} <ArrowRight size={18} />
                            </Link>
                            <Link to="/#coverage" className="btn-ghost text-base">
                                {t('home.hero.coverage')} <ChevronDown size={18} />
                            </Link>
                        </div>

                        <div style={{ animationDelay: '320ms' }} className="animate-rise mt-8 flex flex-wrap items-center gap-2">
                            <span className="mr-1 text-sm text-text-muted">{t('home.hero.popular')}</span>
                            {POPULAR.map((slug) => {
                                const m = getMarket(slug);
                                return (
                                    <Link key={slug} to={`/payment-methods/${slug}`}
                                        className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] py-1 pl-1 pr-3 text-xs text-text-body transition-colors hover:border-primary/40 hover:text-white">
                                        <Flag market={m} className="h-4 w-4 rounded-full" />
                                        {marketName(m, i18n.language)}
                                    </Link>
                                );
                            })}
                        </div>

                        <ul style={{ animationDelay: '400ms' }} className="animate-rise mt-9 flex flex-wrap gap-x-7 gap-y-3 text-sm text-text-body">
                            <li className="inline-flex items-center gap-2"><Zap size={16} className="text-primary" /> {t('home.hero.stats.settlement')}</li>
                            <li className="inline-flex items-center gap-2"><GitBranch size={16} className="text-primary" /> {t('home.hero.stats.routing')}</li>
                            <li className="inline-flex items-center gap-2"><Activity size={16} className="text-primary" /> {t('home.hero.stats.monitoring')}</li>
                        </ul>
                    </div>

                    {/* Globe + HUD */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.94 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1.2, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
                        className="relative mx-auto w-full max-w-[640px] lg:-mr-8 lg:max-w-none"
                    >
                        <div className="relative">
                            <PaymentGlobe className="aspect-square w-full" onLaunch={onLaunch} onSettle={onSettle} />
                            <div className="absolute bottom-[12%] right-0 hidden sm:block lg:right-[4%]">
                                <SettlementCard settled={settled} />
                            </div>
                            <div className="absolute inset-x-0 bottom-[3%] flex items-center justify-center gap-5 text-[11px] text-text-muted">
                            <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" /> {t('coverage.payin')}</span>
                            <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full ring-[1.5px] ring-payout" /> {t('coverage.payout')}</span>
                                <span className="hidden items-center gap-1.5 sm:inline-flex"><Move size={12} /> {t('home.hero.hud.drag')}</span>
                            </div>
                        </div>
                        {/* Routing card: floats over the globe on larger screens, sits below it on phones */}
                        <div className="mx-auto mt-2 w-fit sm:absolute sm:left-[2%] sm:top-[6%] sm:mt-0">
                            <RoutingCard route={route} />
                        </div>
                    </motion.div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
