import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ArrowUpRight, ArrowDownLeft, ChevronDown, X, MessageSquarePlus } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
    MARKETS, REGIONS, COVERAGE_STATS,
    hasPayout, marketName, regionName,
} from '../../data/channels';
import { Flag, MethodIcon, methodLogo, CountUp, handleSpotlight } from '../../components/coverage/shared';

// "All" view priority: Global USDT → United States → Europe bank transfers → LatAm → Asia Pacific → Africa.
// Within a group, markets keep their order in channels.js.
const PRIORITY = (m) => (m.slug === 'usdt' ? 0 : m.slug === 'united-states' ? 1 : { europe_me: 2, americas: 3, apac: 4, africa: 5 }[m.region] ?? 6);
const INITIAL = 12;
const MOBILE_INITIAL = 6; // phones show fewer cards before "Show all"

const REGION_ORDER = ['americas', 'europe_me', 'apac', 'africa', 'global'];

/** "Brazil Bank Transfer" -> "Bank Transfer", "EUR Bank Transfer" -> "Bank Transfer", "Mobile Money GH" -> "Mobile Money". */
const shortName = (method, market) => method
    .replace(new RegExp(`^(${market.name.en}|Ivory Coast|${market.currency}) `), '')
    .replace(/^(Mobile Money) [A-Z]{2}$/, '$1');

/** Calm method summary: brand logos (only where a brand exists) + a short text list. */
const MethodSummary = ({ methods, market }) => {
    const names = [...new Set(methods.map((m) => shortName(m, market)))];
    const logos = methods.filter((m) => methodLogo(m)).slice(0, 4);
    return (
        <div className="min-w-0">
            <p className="text-[13px] leading-5 text-text-heading/85">{names.join(' · ')}</p>
            {logos.length > 0 && (
                <span className="mt-1.5 flex gap-1">
                    {logos.map((m) => <MethodIcon key={m} method={m} size={14} />)}
                </span>
            )}
        </div>
    );
};

export const MarketCard = ({ market, lang, t }) => {
    const payout = hasPayout(market);
    const highlight = market.region === 'global';
    return (
        <Link
            to={`/payment-methods/${market.slug}`}
            className={`spotlight group flex h-full flex-col rounded-2xl border bg-surface/80 p-5 shadow-card transition-[transform,border-color,background-color] duration-300 hover:-translate-y-1 hover:bg-surface-2 ${highlight ? 'border-[#26A17B]/40' : 'border-white/[0.07] hover:border-white/15'}`}
        >
            <div className="flex items-start gap-3.5">
                <Flag market={market} />
                <div className="min-w-0 flex-1">
                    <h3 className="truncate text-[15px] font-semibold text-text-heading">{marketName(market, lang)}</h3>
                    <p className="mt-0.5 text-xs text-text-muted">
                        <span className="font-mono text-text-body">{market.currency}</span>
                        <span className="mx-1.5">·</span>
                        {regionName(market.region, lang)}
                    </p>
                </div>
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/10 text-text-muted transition-all duration-300 group-hover:border-primary/50 group-hover:bg-primary group-hover:text-black">
                    <ArrowUpRight size={14} />
                </span>
            </div>

            <dl className="mt-5 space-y-3 border-t border-white/[0.05] pt-4">
                <div className="grid grid-cols-[4.25rem_1fr] items-start gap-2">
                    <dt className="inline-flex items-center gap-1 pt-0.5 text-[11px] font-semibold text-primary"><ArrowDownLeft size={12} />{t('coverage.payin')}</dt>
                    <dd><MethodSummary methods={market.payin} market={market} /></dd>
                </div>
                <div className="grid grid-cols-[4.25rem_1fr] items-start gap-2">
                    <dt className={`inline-flex items-center gap-1 pt-0.5 text-[11px] font-semibold ${payout ? 'text-payout' : 'text-text-muted'}`}><ArrowUpRight size={12} />{t('coverage.payout')}</dt>
                    <dd>{payout ? <MethodSummary methods={market.payout} market={market} /> : <span className="text-[13px] leading-5 text-text-muted">{t('coverage.payinOnly')}</span>}</dd>
                </div>
            </dl>

            {market.networks && (
                <p className="mt-auto pt-4 text-[11px] text-text-muted">{t('coverage.networks')}: {market.networks.join(' · ')}</p>
            )}
        </Link>
    );
};

const Coverage = () => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const [region, setRegion] = useState('all');
    const [payoutOnly, setPayoutOnly] = useState(false);
    const [query, setQuery] = useState('');
    const [expanded, setExpanded] = useState(false);

    const counts = useMemo(() => Object.fromEntries(REGION_ORDER.map((r) => [r, MARKETS.filter((m) => m.region === r).length])), []);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        let list = MARKETS.filter((m) => {
            if (region !== 'all' && m.region !== region) return false;
            if (payoutOnly && !hasPayout(m)) return false;
            if (!q) return true;
            const hay = [m.name.en, m.name.zh, m.currency, m.slug, ...m.payin, ...(m.payout || []), REGIONS.find((r) => r.key === m.region)?.en, REGIONS.find((r) => r.key === m.region)?.zh]
                .join(' ').toLowerCase();
            return hay.includes(q);
        });
        if (region === 'all' && !q) {
            list = [...list].sort((a, b) => PRIORITY(a) - PRIORITY(b) || MARKETS.indexOf(a) - MARKETS.indexOf(b));
        }
        return list;
    }, [region, payoutOnly, query]);

    const limited = !expanded && !query && filtered.length > INITIAL;
    const visible = limited ? filtered.slice(0, INITIAL) : filtered;
    const showDesktopToggle = limited || (expanded && filtered.length > INITIAL);
    const showMobileToggle = !query && filtered.length > MOBILE_INITIAL;

    const tabs = [{ key: 'all', label: t('coverage.all'), count: MARKETS.length }, ...REGION_ORDER.map((k) => ({ key: k, label: regionName(k, lang), count: counts[k] }))];

    const stats = [
        { value: COVERAGE_STATS.markets, suffix: '', label: t('coverage.stats.markets') },
        { value: COVERAGE_STATS.payinMethods, suffix: '+', label: t('coverage.stats.methods') },
        { value: COVERAGE_STATS.payoutMarkets, suffix: '', label: t('coverage.stats.payout') },
        { value: COVERAGE_STATS.currencies, suffix: '', label: t('coverage.stats.currencies') },
    ];

    return (
        <section id="coverage" aria-labelledby="coverage-title" className="relative pb-24 pt-8 md:pb-32 md:pt-10">
            {/* ambient glow */}
            <div className="pointer-events-none absolute inset-x-0 top-0 h-[600px] bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(255,153,0,0.12),transparent_70%)]" />

            <div className="container relative mx-auto px-5">
                {/* Heading */}
                <div className="mx-auto max-w-3xl text-center">
                    <span className="eyebrow">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                        {t('coverage.eyebrow')}
                    </span>
                    <h2 id="coverage-title" className="mt-5 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
                        {t('coverage.title')} <span className="text-ember whitespace-nowrap">{t('coverage.titleHighlight', { count: COVERAGE_STATS.markets })}</span>
                    </h2>
                    <p className="mt-5 text-base text-text-body md:text-lg">{t('coverage.subtitle')}</p>
                </div>

                {/* Stats */}
                <dl className="mx-auto mt-12 grid max-w-4xl grid-cols-2 overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.02] md:grid-cols-4">
                    {stats.map((s, i) => (
                        <div key={s.label} className={`px-5 py-5 text-center md:py-6 ${i % 2 === 0 ? 'border-r border-white/[0.07]' : ''} ${i < 2 ? 'border-b border-white/[0.07] md:border-b-0' : ''} md:border-r md:last:border-r-0`}>
                            <dt className="sr-only">{s.label}</dt>
                            <dd className="font-display text-3xl font-bold text-white md:text-4xl"><CountUp value={s.value} suffix={s.suffix} /></dd>
                            <dd className="mt-1 text-xs font-medium uppercase tracking-[0.12em] text-text-muted">{s.label}</dd>
                        </div>
                    ))}
                </dl>

                {/* Controls */}
                <div className="sticky top-20 z-20 -mx-5 mt-12 border-y border-white/[0.06] bg-background/85 px-5 py-3 backdrop-blur-xl md:static md:mx-0 md:border-0 md:bg-transparent md:p-0 md:backdrop-blur-0">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                        <div role="tablist" aria-label={t('coverage.region')} className="no-scrollbar -mx-5 flex gap-1 overflow-x-auto px-5 md:mx-0 md:px-0">
                            <div className="flex gap-1 rounded-full border border-white/[0.07] bg-white/[0.03] p-1">
                                {tabs.map((tab) => {
                                    const active = region === tab.key;
                                    return (
                                        <button
                                            key={tab.key}
                                            role="tab"
                                            aria-selected={active}
                                            onClick={() => { setRegion(tab.key); setExpanded(false); }}
                                            className={`relative whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors ${active ? 'text-black' : 'text-text-body hover:text-white'}`}
                                        >
                                            {active && (
                                                <motion.span
                                                    layoutId="region-pill"
                                                    className="absolute inset-0 rounded-full bg-gradient-to-r from-primary-soft via-primary to-primary-deep"
                                                    transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                                                />
                                            )}
                                            <span className="relative">{tab.label}</span>
                                            <span className={`relative ml-1.5 text-xs ${active ? 'text-black/60' : 'text-text-muted'}`}>{tab.count}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            <label className="relative flex-1 lg:w-72 lg:flex-none">
                                <span className="sr-only">{t('coverage.search')}</span>
                                <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                                <input
                                    type="search"
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    placeholder={t('coverage.search')}
                                    className="w-full rounded-full border border-white/10 bg-white/[0.04] py-2.5 pl-10 pr-9 text-sm text-white placeholder:text-text-muted transition-colors focus:border-primary/50 focus:bg-white/[0.06] focus:outline-none [&::-webkit-search-cancel-button]:hidden"
                                />
                                {query && (
                                    <button onClick={() => setQuery('')} aria-label="Clear" className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-white">
                                        <X size={14} />
                                    </button>
                                )}
                            </label>
                            <button
                                role="switch"
                                aria-checked={payoutOnly}
                                onClick={() => setPayoutOnly((v) => !v)}
                                className={`inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-2.5 text-sm font-medium transition-colors ${payoutOnly ? 'border-payout/40 bg-payout/10 text-payout' : 'border-white/10 bg-white/[0.04] text-text-body hover:text-white'}`}
                            >
                                <span className={`relative h-4 w-7 rounded-full transition-colors ${payoutOnly ? 'bg-payout' : 'bg-white/15'}`}>
                                    <span className={`absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all ${payoutOnly ? 'left-3.5' : 'left-0.5'}`} />
                                </span>
                                {t('coverage.payout')}
                            </button>
                        </div>
                    </div>
                </div>

                {/* Grid */}
                <motion.ul layout onMouseMove={handleSpotlight} className="spotlight-group mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    <AnimatePresence mode="popLayout" initial={false}>
                        {visible.map((m, i) => (
                            <motion.li
                                key={m.slug}
                                layout
                                initial={{ opacity: 0, scale: 0.96, y: 8 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.96 }}
                                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                                className={`list-none ${!expanded && !query && i >= MOBILE_INITIAL ? 'max-sm:hidden' : ''}`}
                            >
                                <MarketCard market={m} lang={lang} t={t} />
                            </motion.li>
                        ))}
                    </AnimatePresence>
                </motion.ul>

                {filtered.length === 0 && (
                    <div className="mt-6 rounded-2xl border border-dashed border-white/10 p-10 text-center">
                        <p className="text-text-body">{t('coverage.empty', { q: query })}</p>
                        <Link to="/contact" className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary hover:text-primary-hover">
                            {t('coverage.emptyCta')} <ArrowUpRight size={14} />
                        </Link>
                    </div>
                )}

                {(showDesktopToggle || showMobileToggle) && (
                    <div className={`mt-8 flex justify-center ${showDesktopToggle ? '' : 'sm:hidden'} ${showMobileToggle ? '' : 'max-sm:hidden'}`}>
                        <button onClick={() => setExpanded((v) => !v)} className="btn-ghost text-sm">
                            {expanded ? t('coverage.showLess') : t('coverage.showAll', { count: filtered.length })}
                            <ChevronDown size={16} className={`transition-transform ${expanded ? 'rotate-180' : ''}`} />
                        </button>
                    </div>
                )}

                {/* CTA */}
                <div className="border-conic mt-14 rounded-3xl">
                    <div className="relative flex flex-col items-start gap-6 overflow-hidden rounded-3xl bg-gradient-to-br from-surface-2 to-surface p-8 md:flex-row md:items-center md:justify-between md:p-10">
                        <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/20 blur-[80px]" />
                        <div className="relative flex items-start gap-4">
                            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/30">
                                <MessageSquarePlus size={20} />
                            </span>
                            <div>
                                <h3 className="text-xl font-semibold text-white md:text-2xl">{t('coverage.ctaTitle')}</h3>
                                <p className="mt-1.5 max-w-xl text-text-body">{t('coverage.ctaDesc')}</p>
                            </div>
                        </div>
                        <Link to="/contact" className="btn-primary relative shrink-0 max-sm:w-full">
                            {t('coverage.ctaButton')} <ArrowUpRight size={18} />
                        </Link>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Coverage;
