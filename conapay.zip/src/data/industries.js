import { Gamepad2, ShoppingBag, Radio, Coins, AppWindow, Plane, GraduationCap, Banknote } from 'lucide-react';

/**
 * Industry solutions — ids double as #anchors on /industries.
 * Copy lives in locales (industries.items.<id>); photos in src/assets/industries/<id>.jpg (see credits.json).
 */
export const INDUSTRIES = [
    { id: 'gaming', icon: Gamepad2 },
    { id: 'e-commerce', icon: ShoppingBag },
    { id: 'live-streaming', icon: Radio },
    { id: 'web3', icon: Coins },
    { id: 'digital-goods', icon: AppWindow },
    { id: 'travel', icon: Plane },
    { id: 'education', icon: GraduationCap },
    { id: 'global-payroll', icon: Banknote },
];

const PHOTOS = import.meta.glob('../assets/industries/*.jpg', { eager: true, query: '?url', import: 'default' });
export const industryPhoto = (id) => PHOTOS[`../assets/industries/${id}.jpg`] || null;
