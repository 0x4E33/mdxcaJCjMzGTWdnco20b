import { useEffect, useRef } from 'react';

/**
 * "Payment rails" page backdrop: a perspective floor whose rails carry light pulses toward the
 * viewer — transactions moving through infrastructure. Canvas 2D, pauses off-screen, static
 * frame for prefers-reduced-motion. Sits behind page headers (absolute, pointer-events-none).
 *
 * accent: 'primary' (default) | 'payout' — tints a share of the pulses.
 */
const RailsBackdrop = ({ className = '', height = 680, accent = 'primary' }) => {
    const wrapRef = useRef(null);
    const canvasRef = useRef(null);

    useEffect(() => {
        const wrap = wrapRef.current;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        let W = 0, H = 0, raf = 0, running = false;
        let mx = 0, tmx = 0;
        const pulses = [];
        let lastSpawn = 0;
        const RAILS = 26;
        const teal = accent === 'payout' ? 0.5 : 0.2;

        const resize = () => {
            const r = wrap.getBoundingClientRect();
            W = r.width; H = r.height;
            const dpr = Math.min(window.devicePixelRatio || 1, 2);
            canvas.width = Math.round(W * dpr);
            canvas.height = Math.round(H * dpr);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            if (!running) draw(performance.now());
        };

        const geom = () => {
            const hy = H * 0.5; // horizon
            const vx = W / 2 + mx * W * 0.04;
            return { hy, vx };
        };
        // bottom x of rail i
        const railX = (i) => -W * 0.9 + (i / (RAILS - 1)) * W * 2.8;

        const draw = (now) => {
            ctx.clearRect(0, 0, W, H);
            const { hy, vx } = geom();

            // horizon glow
            const g = ctx.createRadialGradient(vx, hy, 0, vx, hy, W * 0.55);
            g.addColorStop(0, 'rgba(255,153,0,0.20)');
            g.addColorStop(0.4, 'rgba(255,90,54,0.06)');
            g.addColorStop(1, 'rgba(255,153,0,0)');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, W, H);

            // rails (converging lines)
            ctx.lineWidth = 1;
            for (let i = 0; i < RAILS; i++) {
                const bx = railX(i);
                const lg = ctx.createLinearGradient(0, hy, 0, H);
                lg.addColorStop(0, 'rgba(255,255,255,0)');
                lg.addColorStop(1, 'rgba(255,255,255,0.07)');
                ctx.strokeStyle = lg;
                ctx.beginPath(); ctx.moveTo(vx, hy); ctx.lineTo(bx, H); ctx.stroke();
            }
            // cross ties, flowing toward the viewer
            const flow = reduced ? 0 : (now / 1000) * 0.35;
            for (let k = 0; k < 14; k++) {
                const d = ((k + (flow % 1)) / 14); // 0..1
                const y = hy + (H - hy) * Math.pow(d, 2.2);
                const a = Math.pow(d, 1.5) * 0.09;
                ctx.strokeStyle = `rgba(255,255,255,${a})`;
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
            }

            // pulses
            for (let i = pulses.length - 1; i >= 0; i--) {
                const p = pulses[i];
                const s = (now - p.t0) / p.dur;
                if (s >= 1) { pulses.splice(i, 1); continue; }
                const bx = railX(p.rail);
                const at = (u) => { const e = Math.pow(u, 2.2); return [vx + (bx - vx) * e, hy + (H - hy) * e]; };
                const [x0, y0] = at(Math.max(0, s - 0.09));
                const [x1, y1] = at(s);
                const col = p.teal ? '45,212,191' : '255,170,60';
                const lg = ctx.createLinearGradient(x0, y0, x1, y1);
                lg.addColorStop(0, `rgba(${col},0)`);
                lg.addColorStop(1, `rgba(${col},${0.25 + s * 0.75})`);
                ctx.strokeStyle = lg;
                ctx.lineWidth = 1 + s * 2;
                ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
                ctx.beginPath();
                ctx.arc(x1, y1, 1 + s * 2.2, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${p.teal ? '180,255,240' : '255,226,184'},${0.4 + s * 0.6})`;
                ctx.fill();
            }
        };

        const frame = (now) => {
            mx += (tmx - mx) * 0.05;
            if (now - lastSpawn > 260 && pulses.length < 14) {
                lastSpawn = now;
                pulses.push({ rail: 4 + Math.floor(Math.random() * (RAILS - 8)), t0: now, dur: 2200 + Math.random() * 1800, teal: Math.random() < teal });
            }
            draw(now);
            if (running) raf = requestAnimationFrame(frame);
        };
        const start = () => { if (running || reduced) return; running = true; raf = requestAnimationFrame(frame); };
        const stop = () => { running = false; cancelAnimationFrame(raf); };

        const onMove = (e) => { tmx = (e.clientX / window.innerWidth - 0.5) * 2; };
        window.addEventListener('pointermove', onMove, { passive: true });
        const ro = new ResizeObserver(resize);
        ro.observe(wrap);
        resize();
        const io = new IntersectionObserver(([en]) => (en.isIntersecting ? start() : stop()), { threshold: 0 });
        io.observe(wrap);
        const onVis = () => (document.visibilityState === 'visible' ? start() : stop());
        document.addEventListener('visibilitychange', onVis);
        return () => {
            stop(); ro.disconnect(); io.disconnect();
            window.removeEventListener('pointermove', onMove);
            document.removeEventListener('visibilitychange', onVis);
        };
    }, [accent]);

    return (
        <div ref={wrapRef} aria-hidden="true" style={{ height }}
            className={`pointer-events-none absolute inset-x-0 top-0 overflow-hidden [mask-image:linear-gradient(to_bottom,transparent,black_25%,black_70%,transparent)] ${className}`}>
            <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
            <div className="absolute inset-0 bg-noise opacity-[0.03] mix-blend-overlay" />
        </div>
    );
};

export default RailsBackdrop;
