import { Suspense, lazy, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import MobileContactBar from './components/MobileContactBar';
import Home from './pages/Home/Home';
import { getSeo, applySeo } from './seo';

// Lazy Load Main Pages
const MarketPage = lazy(() => import('./pages/MarketPage'));
const Industries = lazy(() => import('./pages/Industries'));
const Developers = lazy(() => import('./pages/Developers'));
const Capabilities = lazy(() => import('./pages/Capabilities'));
const Contact = lazy(() => import('./pages/Contact'));
const Roadmap = lazy(() => import('./pages/Roadmap'));
const About = lazy(() => import('./pages/About'));



const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
  </div>
);

/** Scroll to top on route change, or to #hash target (retries while lazy content mounts). */
const useScrollManager = (location) => {
  useEffect(() => {
    if (!location.hash) {
      window.scrollTo(0, 0);
      return;
    }
    let tries = 0;
    let raf;
    const seek = () => {
      const el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else if (tries++ < 60) {
        raf = requestAnimationFrame(seek);
      }
    };
    seek();
    return () => cancelAnimationFrame(raf);
  }, [location.pathname, location.hash, location.key]);
};

const Layout = ({ children }) => {
  const location = useLocation();
  const { i18n } = useTranslation();

  useScrollManager(location);

  useEffect(() => {
    document.documentElement.lang = i18n.language?.startsWith('zh') ? 'zh-CN' : 'en';
    applySeo(getSeo(location.pathname, i18n.language));
  }, [location.pathname, i18n.language]);

  return (
    <div className="min-h-screen flex flex-col font-sans text-text-body selection:bg-primary/30 selection:text-white">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[60] focus:px-4 focus:py-2 focus:rounded-full focus:bg-primary focus:text-black">Skip to content</a>
      <Navbar />
      <main id="main" className="flex-grow pt-20">
        {children}
      </main>
      <Footer />
      <MobileContactBar />
    </div>
  );
};

/** Routes + layout, shared by the browser app and the build-time prerenderer. */
export const AppShell = () => (
  <MotionConfig reducedMotion="user">
    <Layout>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<Home />} />
          {/* Old coverage page now lives on the home page */}
          <Route path="/network" element={<Navigate to="/#coverage" replace />} />
          <Route path="/payment-methods" element={<Navigate to="/#coverage" replace />} />
          <Route path="/payment-methods/:slug" element={<MarketPage />} />
          <Route path="/industries" element={<Industries />} />
          <Route path="/capabilities" element={<Capabilities />} />
          <Route path="/developers" element={<Developers />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/roadmap" element={<Roadmap />} />
          <Route path="/about" element={<About />} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </Layout>
  </MotionConfig>
);

function App() {
  return (
    <Router>
      <AppShell />
    </Router>
  );
}

export default App;
