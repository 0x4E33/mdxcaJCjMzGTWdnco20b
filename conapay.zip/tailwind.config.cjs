/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#07070A',   // ink black with a cool undertone
        surface: {
          DEFAULT: '#0E0E13',
          2: '#15151C',
          3: '#1C1C25',
        },
        primary: {
          DEFAULT: '#FF9900',    // ConaPay orange
          hover: '#FFB13D',
          soft: '#FFC56B',
          deep: '#FF6A1A',
        },
        ember: '#FF5A36',        // warm accent used at the end of brand gradients
        payout: '#2DD4BF',       // teal: payout / success
        text: {
          heading: '#F5F5F7',
          body: '#A6A6B0',
          muted: '#6B6B76',
        },
        border: 'rgba(255, 255, 255, 0.08)',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', '"PingFang SC"', '"Hiragino Sans GB"', '"Microsoft YaHei"', 'sans-serif'],
        display: ['Sora', 'Inter', 'ui-sans-serif', 'system-ui', '"PingFang SC"', '"Microsoft YaHei"', 'sans-serif'],
      },
      container: {
        center: true,
        padding: '1.25rem',
        screens: {
          sm: '640px',
          md: '768px',
          lg: '1024px',
          xl: '1280px',
          '2xl': '1280px',
        }
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(255,153,0,0.25), 0 10px 40px -10px rgba(255,153,0,0.45)',
        card: '0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 40px -24px rgba(0,0,0,0.8)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'grid-flow': 'grid-flow 20s linear infinite',
        'blob-bounce': 'blob-bounce 10s infinite ease-in-out',
        'scan-light': 'scan-light 6s linear infinite',
        'svg-draw': 'svg-draw 2s ease-in-out forwards',
        'float': 'float 3s ease-in-out infinite',
        'glow-pulse': 'glow-pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'aurora': 'aurora 18s ease-in-out infinite alternate',
        'shine': 'shine 3.5s ease-in-out infinite',
        'border-spin': 'border-spin 6s linear infinite',
        'rise': 'rise 0.8s cubic-bezier(0.16, 1, 0.3, 1) both',
      },
      keyframes: {
        'grid-flow': {
          '0%': { transform: 'translateY(0)' },
          '100%': { transform: 'translateY(-40px)' },
        },
        'blob-bounce': {
          '0%, 100%': { transform: 'translate(0, 0) scale(1)' },
          '33%': { transform: 'translate(30px, -50px) scale(1.1)' },
          '66%': { transform: 'translate(-20px, 20px) scale(0.9)' },
        },
        'scan-light': {
          '0%': { backgroundPosition: '0% 50%' },
          '100%': { backgroundPosition: '200% 50%' },
        },
        'svg-draw': {
          '0%': { strokeDashoffset: '100' },
          '100%': { strokeDashoffset: '0' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-5px)' },
        },
        'glow-pulse': {
          '0%, 100%': { filter: 'drop-shadow(0 0 5px currentColor)' },
          '50%': { filter: 'drop-shadow(0 0 15px currentColor)' },
        },
        'aurora': {
          '0%': { transform: 'translate3d(-6%, -4%, 0) rotate(0deg) scale(1)' },
          '50%': { transform: 'translate3d(4%, 3%, 0) rotate(8deg) scale(1.08)' },
          '100%': { transform: 'translate3d(-2%, 6%, 0) rotate(-6deg) scale(0.96)' },
        },
        'shine': {
          '0%': { backgroundPosition: '200% 0' },
          '60%, 100%': { backgroundPosition: '-200% 0' },
        },
        'border-spin': {
          to: { '--angle': '360deg' },
        },
        'rise': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'none' },
        },
      }
    },
  },
  plugins: [],
}
