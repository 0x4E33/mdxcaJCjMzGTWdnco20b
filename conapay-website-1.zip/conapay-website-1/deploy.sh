#!/bin/bash

# ==========================================
# ConaPay 官网 一键部署脚本
# 适用于全新 Ubuntu 云服务器（以 root 身份运行，无需 sudo）
#
# 用法：
#   1. 把整个项目（不含 node_modules）打包上传到服务器
#   2. unzip 解压
#   3. chmod +x deploy.sh
#   4. ./deploy.sh
#
# 脚本会自动完成：
#   - 系统依赖 (curl/unzip/git 等)
#   - Node.js / npm 安装
#   - 项目依赖安装 + 构建 (npm ci && npm run build)
#   - Docker / Docker Compose 安装
#   - Nginx 容器化部署 (静态资源 + Gzip + SPA 路由)
#   - 低内存 VPS 自动开启 swap，防止构建被 OOM Kill
#   - 防火墙放行 80/443（若 ufw 已启用）
# ==========================================

set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}>>> $1${NC}"; }
warn() { echo -e "${YELLOW}!!! $1${NC}"; }
err()  { echo -e "${RED}✗ $1${NC}"; }

# 脚本所在目录 = 项目根目录（不管解压到哪个路径都能正确工作）
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

# ---------- 0. 权限检查 ----------
if [ "$(id -u)" -ne 0 ]; then
    err "请以 root 用户运行本脚本（当前脚本假设无需 sudo，即你已经是 root）。"
    exit 1
fi

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN} ConaPay 部署开始，项目目录: $PROJECT_DIR ${NC}"
echo -e "${GREEN}=============================================${NC}"

# ---------- 1. 基础系统依赖 ----------
log "1. 更新软件源并安装基础依赖 (curl/unzip/ca-certificates/gnupg)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl unzip ca-certificates gnupg git

# ---------- 2. 低内存服务器自动开启 swap ----------
log "2. 检查内存与 swap（防止构建时被 OOM 杀死）..."
MEM_TOTAL_MB=$(free -m | awk '/^Mem:/{print $2}')
SWAP_TOTAL_MB=$(free -m | awk '/^Swap:/{print $2}')
if [ "$SWAP_TOTAL_MB" -eq 0 ] && [ "$MEM_TOTAL_MB" -lt 4096 ]; then
    if [ ! -f /swapfile ]; then
        warn "检测到内存较小 (${MEM_TOTAL_MB}MB) 且无 swap，正在创建 2G swap 文件..."
        fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
        chmod 600 /swapfile
        mkswap /swapfile
        swapon /swapfile
        grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
        log "swap 创建完成。"
    else
        swapon /swapfile 2>/dev/null || true
    fi
else
    echo "内存/swap 充足，跳过。"
fi

# ---------- 3. 安装 Node.js / npm ----------
log "3. 检查并安装 Node.js (LTS 20.x)..."
NEED_NODE_INSTALL=1
if command -v node &> /dev/null; then
    NODE_MAJOR=$(node -v | sed -E 's/^v([0-9]+).*/\1/')
    if [ "$NODE_MAJOR" -ge 20 ]; then
        NEED_NODE_INSTALL=0
        echo "已安装 Node.js $(node -v)，跳过安装。"
    fi
fi
if [ "$NEED_NODE_INSTALL" -eq 1 ]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo "Node: $(node -v)  npm: $(npm -v)"

# ---------- 4. 安装依赖并构建前端 ----------
log "4. 安装项目依赖并执行生产构建 (npm ci && npm run build)..."
if [ -f package-lock.json ]; then
    npm ci --no-audit --no-fund || npm install --no-audit --no-fund
else
    npm install --no-audit --no-fund
fi
npm run build

if [ ! -d "$PROJECT_DIR/dist" ] || [ ! -f "$PROJECT_DIR/dist/index.html" ]; then
    err "构建失败：未找到 dist/index.html，请检查上面的构建日志。"
    exit 1
fi
log "构建成功，产物位于 $PROJECT_DIR/dist"

# ---------- 5. 安装 Docker ----------
log "5. 环境检查与 Docker 安装..."
if ! command -v docker &> /dev/null; then
    echo "Docker 未安装，正在自动安装..."
    curl -fsSL https://get.docker.com | bash -s docker
    systemctl enable docker
    systemctl start docker
else
    echo "Docker 已安装，跳过安装步骤。"
fi

# ---------- 6. 生成 Nginx 配置 ----------
log "6. 生成 Nginx 高性能配置..."
mkdir -p "$PROJECT_DIR/conf"

cat > "$PROJECT_DIR/conf/default.conf" <<EOF
server {
    listen 80;
    server_name _;

    root /usr/share/nginx/html;
    index index.html;

    # 安全设置：隐藏 Nginx 版本号
    server_tokens off;

    # 性能优化：开启 Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_min_length 256;
    gzip_types
        text/plain
        text/css
        text/javascript
        application/javascript
        application/json
        application/xml
        image/svg+xml
        font/woff2;

    # React Router 核心配置：防止刷新 404
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # 静态资源缓存优化 (长期缓存)
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2|ttf)\$ {
        expires 1y;
        add_header Cache-Control "public, no-transform, immutable";
        access_log off;
    }

    # 健康检查端点 (可选，给云监控用)
    location /health {
        return 200 'healthy';
        add_header Content-Type text/plain;
    }
}
EOF

# ---------- 7. 生成 Docker Compose 配置 ----------
log "7. 生成 Docker Compose 配置..."
cat > "$PROJECT_DIR/docker-compose.yml" <<EOF
services:
  web:
    image: nginx:alpine
    container_name: conapay_web
    restart: always
    ports:
      - "80:80"
    volumes:
      - ./dist:/usr/share/nginx/html:ro
      - ./conf/default.conf:/etc/nginx/conf.d/default.conf:ro
    environment:
      - TZ=Asia/Shanghai
EOF

# ---------- 8. 启动/重启服务 ----------
log "8. 启动/重启服务..."
docker compose down 2>/dev/null || true
docker compose up -d --force-recreate

# ---------- 9. 防火墙放行（若 ufw 已启用才处理，避免误开防火墙） ----------
if command -v ufw &> /dev/null && ufw status | grep -q "Status: active"; then
    log "9. 检测到 ufw 已启用，放行 80/443 端口..."
    ufw allow 80/tcp || true
    ufw allow 443/tcp || true
else
    echo "ufw 未启用，跳过防火墙配置（云厂商安全组请自行确保 80 端口已放行）。"
fi

# ---------- 10. 健康检查 ----------
sleep 2
if curl -sf http://localhost/health > /dev/null; then
    HEALTH="✅ 正常"
else
    HEALTH="⚠️  未响应，请用 docker logs conapay_web 排查"
fi

PUBLIC_IP=$(curl -s ifconfig.me || echo "获取失败")

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN} ✅ 部署成功！ConaPay 官网已上线。 ${NC}"
echo -e "${GREEN} 🌍 访问地址: http://${PUBLIC_IP} ${NC}"
echo -e "${GREEN} 🩺 健康检查: ${HEALTH} ${NC}"
echo -e "${GREEN} ⚠️  如使用 Cloudflare，请确保已开启 Proxy（小黄云）。 ${NC}"
echo -e "${GREEN}=============================================${NC}"
