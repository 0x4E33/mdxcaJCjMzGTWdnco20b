import { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home/Home';

// Lazy Load Main Pages
const GlobalNetwork = lazy(() => import('./pages/GlobalNetwork'));
const Industries = lazy(() => import('./pages/Industries'));
const Developers = lazy(() => import('./pages/Developers'));
const Capabilities = lazy(() => import('./pages/Capabilities'));
const Contact = lazy(() => import('./pages/Contact'));
const Roadmap = lazy(() => import('./pages/Roadmap'));
const About = lazy(() => import('./pages/About'));

// Lazy Load Legal Pages
const Terms = lazy(() => import('./pages/Terms'));
const Privacy = lazy(() => import('./pages/Privacy'));
const Cookies = lazy(() => import('./pages/Cookies'));

// Loading Fallback Component
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-[#050505]">
    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
  </div>
);

const Layout = ({ children }) => {
  const location = useLocation();
  const { i18n } = useTranslation();

  // Smooth scroll to top, set dynamically synced SEO attributes
  useEffect(() => {
    if (!location.hash) {
      window.scrollTo(0, 0);
    }

    // Update HTML lang attribute
    document.documentElement.lang = i18n.language || 'en';

    const routeTitles = {
      '/': 'ConaPay | Global Acquiring, Payout & Settlement',
      '/network': 'Global Network | ConaPay',
      '/industries': 'Industries & Solutions | ConaPay',
      '/capabilities': 'Capabilities | ConaPay',
      '/developers': 'Developers | ConaPay',
      '/contact': 'Contact Us | ConaPay',
      '/roadmap': 'Roadmap | ConaPay',
      '/about': 'About Us | ConaPay',
      '/terms': 'Terms of Service | ConaPay',
      '/privacy': 'Privacy Policy | ConaPay',
      '/cookies': 'Cookie Policy | ConaPay',
    };

    const routeDescriptions = {
      '/': 'ConaPay is a next-generation payment gateway for global commerce. Access local fiat and stablecoin payments with a single integration.',
      '/network': 'Explore ConaPay\'s global payment network covering 50+ emerging markets with local currency acquiring and USDT settlement.',
      '/industries': 'Tailored digital payment solutions for E-commerce, Web3, Gaming, and Cross-border trade platforms.',
      '/capabilities': 'Discover our robust acquiring, payout, compliance, and smart routing capabilities.',
      '/developers': 'Integrate ConaPay seamlessly with our developer-friendly APIs, webhooks, and comprehensive documentation.',
      '/contact': 'Connect with the ConaPay team for payment solutions, technical support, and partnership inquiries.',
      '/roadmap': 'View ConaPay\'s product development timeline, upcoming features, and global expansion plans.',
      '/about': 'Learn about ConaPay\'s mission to unify global payment infrastructure for the digital economy.',
    };

    document.title = routeTitles[location.pathname] || 'ConaPay | Global Checkout';

    // Update dynamic meta description
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', routeDescriptions[location.pathname] || routeDescriptions['/']);
    }

  }, [location, i18n.language]);

  return (
    <div className="min-h-screen flex flex-col font-sans text-text-body selection:bg-primary/30 selection:text-white">
      <Navbar />
      <main className="flex-grow pt-24">
        {children}
      </main>
      <Footer />
    </div>
  );
};

function App() {
  return (
    <Router>
      <Layout>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/network" element={<GlobalNetwork />} />
            <Route path="/industries" element={<Industries />} />
            <Route path="/capabilities" element={<Capabilities />} />
            <Route path="/developers" element={<Developers />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/roadmap" element={<Roadmap />} />
            <Route path="/about" element={<About />} />

            {/* Legal Routes */}
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
          </Routes>
        </Suspense>
      </Layout>
    </Router>
  );
}

export default App;
