import React from 'react';
import { motion } from 'framer-motion';
import { Globe, Database, Shield, Activity, Radio, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const MapDot = ({ top, left, delay }) => (
    <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity, delay: delay }}
        className="absolute w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_#FF9900] z-10"
        style={{ top, left }}
    />
);

const GlobalNetwork = () => {
    const { t } = useTranslation();

    // Channel Data
    const channels = [
        {
            name: t('network.channels.fiatOnRamp.name'),
            type: t('network.channels.regions.global'),
            icon: <Globe size={24} className="text-blue-400" />,
            desc: t('network.channels.fiatOnRamp.desc'),
            methods: ['Global Fiat', 'USDT'],
            highlight: true
        },
        {
            name: t('network.channels.usdtChannel.name'),
            type: t('network.channels.regions.global'),
            icon: <Globe size={24} className="text-purple-400" />,
            desc: t('network.channels.usdtChannel.desc'),
            methods: ['USDT'],
            highlight: true
        },
        {
            name: t('network.channels.countries.Malaysia'),
            type: t('network.channels.regions.sea'),
            flag: '🇲🇾',
            desc: t('network.channels.localDesc.Malaysia'),
            methods: ['Touch N Go', 'DuitNow QR', 'FPX', 'BOOST', 'MAE', 'GrabPay']
        },
        {
            name: t('network.channels.countries.Philippines'),
            type: t('network.channels.regions.sea'),
            flag: '🇵🇭',
            desc: t('network.channels.localDesc.Philippines'),
            methods: ['GCash', 'BPI', 'BillEase', 'Maya']
        },
        {
            name: t('network.channels.countries.Indonesia'),
            type: t('network.channels.regions.sea'),
            flag: '🇮🇩',
            desc: t('network.channels.localDesc.Indonesia'),
            methods: ['GoPay', 'DANA', 'Kredivo', 'QRIS', 'BNI', 'BRI', 'Mandiri']
        },
        {
            name: t('network.channels.countries.Nigeria'),
            type: t('network.channels.regions.africa'),
            flag: '🇳🇬',
            desc: t('network.channels.localDesc.Nigeria'),
            methods: ['Opay', 'Nigeria Cards', 'Bank Transfer']
        },
        {
            name: t('network.channels.countries.Kenya'),
            type: t('network.channels.regions.africa'),
            flag: '🇰🇪',
            desc: t('network.channels.localDesc.Kenya'),
            methods: ['M-Pesa', 'Kenya Cards']
        },
        {
            name: t('network.channels.countries.Uganda'),
            type: t('network.channels.regions.africa'),
            flag: '🇺🇬',
            desc: t('network.channels.localDesc.Uganda'),
            methods: ['Mobile Money UG', 'Uganda Cards']
        },
        {
            name: t('network.channels.countries.Tanzania'),
            type: t('network.channels.regions.africa'),
            flag: '🇹🇿',
            desc: t('network.channels.localDesc.Tanzania'),
            methods: ['Mobile Money TZ', 'Tanzania Cards']
        },
        {
            name: t('network.channels.countries.Cameroon'),
            type: t('network.channels.regions.africa'),
            flag: '🇨🇲',
            desc: t('network.channels.localDesc.Cameroon'),
            methods: ['Mobile Money CM', 'Cameroon Cards']
        },
        {
            name: t('network.channels.countries.South Africa'),
            type: t('network.channels.regions.africa'),
            flag: '🇿🇦',
            desc: t('network.channels.localDesc.South Africa'),
            methods: ['Capitec Pay', 'EFT', 'South Africa Cards']
        },
        {
            name: t('network.channels.countries.Mexico'),
            type: t('network.channels.regions.latam'),
            flag: '🇲🇽',
            desc: t('network.channels.localDesc.Mexico'),
            methods: ['Mercado Pago', 'Paysafecard', 'SPEI']
        },
        {
            name: t('network.channels.countries.Egypt'),
            type: t('network.channels.regions.mena'),
            flag: '🇪🇬',
            desc: t('network.channels.localDesc.Egypt'),
            methods: ['Fawry Pay']
        }
    ];

    return (
        <div className="min-h-screen pt-24 pb-24 relative overflow-hidden bg-background">
            {/* Background Map Image (Dotted World Map) */}
            <div
                className="absolute inset-x-0 top-0 h-[800px] opacity-20 pointer-events-none bg-no-repeat bg-center bg-contain"
                style={{ backgroundImage: "url('https://upload.wikimedia.org/wikipedia/commons/e/ec/World_map_blank_without_borders.svg')", filter: 'invert(1) opacity(0.3)' }}
            >
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background"></div>
            </div>

            {/* Animated Map Dots */}
            <div className="absolute inset-x-0 top-0 h-[800px] pointer-events-none max-w-7xl mx-auto w-full">
                {/* SE Asia */}
                <MapDot top="48%" left="78%" delay={0} />
                <MapDot top="52%" left="82%" delay={0.2} />
                {/* Africa */}
                <MapDot top="45%" left="52%" delay={0.5} />
                <MapDot top="55%" left="55%" delay={0.7} />
                {/* LATAM */}
                <MapDot top="40%" left="20%" delay={1.0} />
                {/* MENA/Egypt */}
                <MapDot top="35%" left="54%" delay={1.3} />
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="text-center mb-20">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-semibold mb-6"
                    >
                        <Radio size={12} className="animate-pulse" />
                        <span>{t('network.badge')}</span>
                    </motion.div>
                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-4xl md:text-7xl font-bold text-white mb-6 tracking-tight"
                    >
                        {t('network.title')} <br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-500">{t('network.titleHighlight')}</span>
                    </motion.h1>
                    <p className="text-xl text-text-body max-w-2xl mx-auto">
                        {t('network.subtitle')}
                    </p>
                </div>

                {/* Stats HUD */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-24">
                    {[
                        { label: t('network.stats.markets'), value: '50+', icon: <Globe size={20} /> },
                        { label: t('network.stats.methods'), value: '40+', icon: <Database size={20} /> },
                        { label: t('network.stats.success'), value: '99.9%', icon: <Activity size={20} /> },
                        { label: t('network.stats.settlement'), value: 'T+0', icon: <Shield size={20} /> }
                    ].map((stat, i) => (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            transition={{ delay: i * 0.1 }}
                            className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm hover:bg-white/10 hover:border-primary/30 transition-all group cursor-default shadow-lg hover:shadow-primary/5"
                        >
                            <div className="flex items-center justify-between mb-4 text-primary/50 group-hover:text-primary transition-colors">
                                {stat.icon}
                                <div className="h-1 w-1 rounded-full bg-current animate-ping"></div>
                            </div>
                            <div className="text-3xl md:text-5xl font-bold text-white mb-1 group-hover:scale-105 transition-transform origin-left">{stat.value}</div>
                            <div className="text-xs md:text-sm text-text-body font-mono uppercase tracking-widest">{stat.label}</div>
                        </motion.div>
                    ))}
                </div>

                {/* Channels Grid - Holographic Data Deck Styles */}
                <h2 className="text-2xl font-bold text-white mb-8 pl-2 border-l-4 border-primary">{t('network.channels.title')}</h2>
                <div className="flex overflow-x-auto pb-8 -mx-6 px-6 snap-x snap-mandatory [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 md:gap-6 md:overflow-visible md:pb-0 md:mx-0 md:px-0">
                    {channels.map((channel, i) => (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.05 }}
                            whileHover={{ y: -5 }}
                            className={`relative group bg-[#080808] border ${channel.highlight ? 'border-primary/40 shadow-[0_0_15px_rgba(255,153,0,0.05)]' : 'border-white/10'} rounded-2xl overflow-hidden hover:border-primary/50 hover:shadow-[0_0_30px_rgba(255,153,0,0.1)] transition-all duration-300 min-w-[300px] w-[85vw] sm:w-[320px] md:min-w-0 md:w-auto shrink-0 snap-center mr-4 md:mr-0 last:mr-0`}
                        >
                            {/* Premium Highlight Overlay */}
                            {channel.highlight && (
                                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent pointer-events-none"></div>
                            )}

                            <div className="p-6 h-full flex flex-col relative z-10">
                                <div className="flex items-center justify-between mb-4">
                                    <div className={`p-3 rounded-xl ${channel.highlight ? 'bg-primary/20 text-primary shadow-[0_0_15px_rgba(255,153,0,0.2)]' : 'bg-white/5 text-white'}`}>
                                        {channel.icon ? channel.icon : <span className="text-2xl">{channel.flag}</span>}
                                    </div>
                                    <span className="text-xs font-mono text-white/40 uppercase tracking-wider">{channel.type}</span>
                                </div>

                                <h3 className="text-lg font-bold text-white mb-2">{channel.name}</h3>
                                {channel.desc && <p className="text-sm text-primary mb-3">{channel.desc}</p>}

                                <div className="flex items-center gap-2 mb-4">
                                    <div className="flex items-center gap-1.5 text-[10px] font-medium px-2 py-0.5 rounded border bg-green-500/10 text-green-400 border-green-500/20">
                                        <ArrowDownLeft size={12} />
                                        <span>{t('network.channels.payin')}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5 text-[10px] font-medium px-2 py-0.5 rounded border bg-blue-500/10 text-blue-400 border-blue-500/20">
                                        <ArrowUpRight size={12} />
                                        <span>{t('network.channels.payout')}</span>
                                    </div>
                                </div>

                                <div className="mt-auto pt-4 border-t border-white/5">
                                    <div className="flex flex-wrap gap-2">
                                        {channel.methods.slice(0, 3).map((method, m) => (
                                            <span key={m} className="px-2 py-1 bg-white/5 rounded text-[10px] text-text-body border border-white/5">
                                                {method}
                                            </span>
                                        ))}
                                        {channel.methods.length > 3 && (
                                            <span className="px-2 py-1 bg-white/5 rounded text-[10px] text-primary border border-primary/20">
                                                +{channel.methods.length - 3}
                                            </span>
                                        )}
                                    </div>
                                    {/* Expandable Hover Overlay - Full List */}
                                    <div className="absolute inset-0 bg-[#0A0A0A]/95 backdrop-blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-6 flex flex-col justify-center items-center text-center z-10">
                                        <h4 className="text-primary font-bold mb-4">{channel.name}</h4>
                                        <div className="flex flex-wrap justify-center gap-2">
                                            {channel.methods.map((method, m) => (
                                                <span key={m} className="px-2 py-1 bg-primary/10 text-primary border border-primary/20 rounded text-xs">
                                                    {method}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default GlobalNetwork;
