import React from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, Terminal } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const codeSnippet = `{
  "amount": 2000,
  "currency": "myr",
  "payment_method_types": ["touchngo"],
  "capture_method": "automatic",
  "confirm": true,
  "customer": "cus_80121",
  "metadata": {
    "order_id": "6735"
  }
}`;

const Developers = () => {
    const { t } = useTranslation();

    return (
        <div className="min-h-screen pt-20 pb-20">
            <div className="container mx-auto px-6">
                <div className="flex flex-col lg:flex-row items-center gap-16">
                    {/* Content */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="lg:w-1/2"
                    >
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-semibold mb-6">
                            <Terminal size={12} />
                            <span>{t('developers.badge')}</span>
                        </div>
                        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                            {t('developers.titlePrefix')} <br /> <span className="text-primary">{t('developers.titleHighlight')}</span>.
                        </h1>
                        <p className="text-xl text-text-body mb-8 leading-relaxed">
                            {t('developers.description')}
                        </p>

                        <div className="space-y-4 mb-10">
                            {[
                                t('developers.features.0'),
                                t('developers.features.1'),
                                t('developers.features.2')
                            ].map((item, i) => (
                                <div key={i} className="flex items-center gap-3">
                                    <div className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center">
                                        <Check size={12} strokeWidth={3} />
                                    </div>
                                    <span className="text-text-heading">{item}</span>
                                </div>
                            ))}
                        </div>

                        <a
                            href="/contact"
                            className="inline-flex items-center justify-center px-8 py-4 bg-primary text-white font-bold rounded-full hover:bg-primary-hover transition-all duration-300 shadow-[0_0_20px_rgba(255,153,0,0.3)] hover:shadow-[0_0_30px_rgba(255,153,0,0.5)]"
                        >
                            {t('developers.cta')}
                        </a>
                    </motion.div>

                    {/* Code Block */}
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 }}
                        className="lg:w-1/2 w-full"
                    >
                        <div className="rounded-xl overflow-hidden bg-[#1E1E1E] border border-white/10 shadow-2xl relative">
                            {/* Window Config */}
                            <div className="flex items-center justify-between px-4 py-3 bg-[#252526] border-b border-white/5">
                                <div className="flex items-center gap-2">
                                    <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                                    <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                                    <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                                </div>
                                <span className="text-xs text-text-body font-mono">POST /v1/payment_intents</span>
                            </div>

                            {/* Code */}
                            <div className="p-6 overflow-x-auto">
                                <pre className="font-mono text-sm leading-relaxed">
                                    <code className="language-json">
                                        <span className="text-purple-400">{"{"}</span>{'\n'}
                                        <span className="text-blue-400">  "amount"</span>: <span className="text-green-400">2000</span>,{'\n'}
                                        <span className="text-blue-400">  "currency"</span>: <span className="text-orange-400">"myr"</span>,{'\n'}
                                        <span className="text-blue-400">  "payment_method_types"</span>: [<span className="text-orange-400">"touchngo"</span>],{'\n'}
                                        <span className="text-blue-400">  "capture_method"</span>: <span className="text-orange-400">"automatic"</span>,{'\n'}
                                        {/* <span className="text-blue-400">  "confirm"</span>: <span className="text-blue-400">true</span>,{'\n'} */}
                                        <span className="text-blue-400">  "customer"</span>: <span className="text-orange-400">"cus_80121"</span>,{'\n'}
                                        <span className="text-blue-400">  "metadata"</span>: <span className="text-purple-400">{"{"}</span>{'\n'}
                                        <span className="text-blue-400">    "order_id"</span>: <span className="text-orange-400">"6735"</span>{'\n'}
                                        <span className="text-purple-400">  {"}"}</span>{'\n'}
                                        <span className="text-purple-400">{"}"}</span>
                                    </code>
                                </pre>
                            </div>

                            {/* Copy Button */}
                            <button className="absolute top-14 right-4 p-2 rounded hover:bg-white/10 text-text-body transition-colors">
                                <Copy size={16} />
                            </button>
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};

export default Developers;
