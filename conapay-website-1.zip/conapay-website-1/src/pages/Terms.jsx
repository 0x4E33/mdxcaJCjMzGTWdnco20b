import React from 'react';
import LegalLayout from '../components/LegalLayout';
import { useTranslation } from 'react-i18next';

const Terms = () => {
    const { t } = useTranslation();

    return (
        <LegalLayout title={t('terms.title')}>
            <p className="mb-8 leading-relaxed">
                {t('terms.preamble')}
            </p>

            <h3>{t('terms.sections.regulations.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.regulations.content')}
            </p>

            <h3>{t('terms.sections.ownership.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.ownership.content')}
            </p>

            <h3>{t('terms.sections.warranties.title')}</h3>
            <p className="mb-6 leading-relaxed">
                {t('terms.sections.warranties.p1')}
            </p>
            <p className="mb-6 leading-relaxed">
                {t('terms.sections.warranties.p2')}
            </p>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.warranties.p3')}
            </p>

            <h3>{t('terms.sections.liability.title')}</h3>
            <p className="mb-6 leading-relaxed">
                {t('terms.sections.liability.p1')}
            </p>
            <p className="mb-6 leading-relaxed">
                {t('terms.sections.liability.p2')}
            </p>
            <p className="mb-6 leading-relaxed">
                {t('terms.sections.liability.p3')}
            </p>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.liability.p4')}
            </p>

            <h3>{t('terms.sections.confidentiality.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.confidentiality.content')}
            </p>

            <h3>{t('terms.sections.linked.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.linked.content')}
            </p>

            <h3>{t('terms.sections.thirdParty.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('terms.sections.thirdParty.content')}
            </p>
        </LegalLayout>
    );
};

export default Terms;
