import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { Flag, Globe, Cpu, Shield, Zap, TrendingUp, Radio } from 'lucide-react';
import HeroParticles from './Home/HeroParticles';
import { useTranslation } from 'react-i18next';

const Roadmap = () => {
    const { t } = useTranslation();
    const containerRef = useRef(null);
    const { scrollYProgress } = useScroll({
        target: containerRef,
        offset: ["start end", "end end"]
    });

    const scaleY = useSpring(scrollYProgress, {
        stiffness: 100,
        damping: 30,
        restDelta: 0.001
    });

    const milestones = [
        {
            date: 'January 2025',
            title: t('roadmap.milestones.genesis.title'),
            description: t('roadmap.milestones.genesis.desc'),
            icon: <Zap size={24} />,
            status: 'completed'
        },
        {
            date: 'March 2025',
            title: t('roadmap.milestones.apac.title'),
            description: t('roadmap.milestones.apac.desc'),
            icon: <Globe size={24} />,
            status: 'completed'
        },
        {
            date: 'June 2025',
            title: t('roadmap.milestones.smartRouting.title'),
            description: t('roadmap.milestones.smartRouting.desc'),
            icon: <Cpu size={24} />,
            status: 'completed'
        },
        {
            date: 'September 2025',
            title: t('roadmap.milestones.security.title'),
            description: t('roadmap.milestones.security.desc'),
            icon: <Shield size={24} />,
            status: 'completed'
        },
        {
            date: 'December 2025',
            title: t('roadmap.milestones.t0.title'),
            description: t('roadmap.milestones.t0.desc'),
            icon: <TrendingUp size={24} />,
            status: 'active'
        },
        {
            date: 'January 2026',
            title: t('roadmap.milestones.future.title'),
            description: t('roadmap.milestones.future.desc'),
            icon: <Radio size={24} />,
            status: 'future'
        }
    ];

    return (
        <div className="min-h-screen bg-[#050505] relative overflow-hidden" ref={containerRef}>
            {/* Background Atmosphere */}
            <HeroParticles />
            <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(255,153,0,0.05)_0%,rgba(0,0,0,0)_70%)]"></div>

            <div className="container mx-auto px-6 py-20 md:py-32 relative z-10">
                <div className="text-center mb-24">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-primary text-sm font-semibold mb-6 tracking-wide"
                    >
                        <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                        </span>
                        <span>{t('roadmap.badge')}</span>
                    </motion.div>
                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-4xl md:text-6xl font-bold text-white mb-6"
                    >
                        {t('roadmap.titlePrefix')} <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-400">{t('roadmap.titleHighlight')}</span>
                    </motion.h1>
                    <p className="text-xl text-text-body max-w-2xl mx-auto">
                        {t('roadmap.subtitle')}
                    </p>
                </div>

                <div className="relative max-w-5xl mx-auto">
                    {/* Vertical Timeline Track */}
                    <div className="absolute left-[20px] md:left-1/2 top-0 bottom-0 w-0.5 bg-white/10 -translate-x-1/2"></div>

                    {/* Glowing Progress Beam */}
                    <motion.div
                        className="absolute left-[20px] md:left-1/2 top-0 w-0.5 bg-gradient-to-b from-primary via-orange-400 to-primary origin-top -translate-x-1/2 z-0"
                        style={{ height: '100%', scaleY, boxShadow: '0 0 20px 2px rgba(255, 153, 0, 0.5)' }}
                    ></motion.div>

                    <div className="space-y-24">
                        {milestones.map((item, index) => (
                            <MilestoneCard key={index} item={item} index={index} />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

const MilestoneCard = ({ item, index }) => {
    const isEven = index % 2 === 0;

    return (
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className={`relative flex flex-col md:flex-row items-center md:justify-between gap-8 ${isEven ? 'md:flex-row-reverse' : ''}`}
        >
            {/* Timeline Node */}
            <div className="absolute left-[20px] md:left-1/2 top-0 -translate-x-1/2 z-10">
                <div className="w-10 h-10 rounded-full bg-[#050505] border-2 border-primary flex items-center justify-center shadow-[0_0_20px_rgba(255,153,0,0.3)]">
                    <div className="w-3 h-3 rounded-full bg-white"></div>
                </div>
            </div>

            {/* Content Card */}
            <div className="w-full pl-16 md:pl-0 md:w-[calc(50%-40px)] group">
                <div className="bg-[#0A0A0A] border border-white/10 rounded-2xl p-8 hover:border-primary/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,153,0,0.1)] relative overflow-hidden">
                    {/* Hover Gradient */}
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>

                    <div className="relative z-10">
                        <div className="flex items-center justify-between mb-4">
                            <span className="text-primary font-mono font-bold tracking-wider text-sm">{item.date}</span>
                            <div className={`p-2 rounded-lg ${item.status === 'completed' ? 'bg-green-500/10 text-green-500' :
                                item.status === 'active' ? 'bg-primary/10 text-primary' :
                                    'bg-white/5 text-white/50'
                                }`}>
                                {item.icon}
                            </div>
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-primary transition-colors">{item.title}</h3>
                        <p className="text-text-body leading-relaxed text-sm md:text-base">{item.description}</p>
                    </div>
                </div>
            </div>

            {/* Empty spacer for alignment */}
            <div className="hidden md:block w-[calc(50%-40px)]"></div>
        </motion.div>
    );
};

export default Roadmap;
