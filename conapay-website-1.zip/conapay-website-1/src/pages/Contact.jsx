import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Send, CheckCircle, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import emailjs from '@emailjs/browser';
import { useTranslation } from 'react-i18next';

const BackgroundParticles = () => {
    return (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(20)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute bg-primary/20 rounded-full blur-xl"
                    initial={{
                        x: Math.random() * window.innerWidth,
                        y: Math.random() * window.innerHeight,
                        scale: Math.random() * 0.5 + 0.5,
                        opacity: 0.1
                    }}
                    animate={{
                        x: Math.random() * window.innerWidth,
                        y: Math.random() * window.innerHeight,
                        opacity: [0.1, 0.3, 0.1],
                    }}
                    transition={{
                        duration: Math.random() * 10 + 10,
                        repeat: Infinity,
                        ease: "linear"
                    }}
                    style={{
                        width: Math.random() * 100 + 50,
                        height: Math.random() * 100 + 50,
                    }}
                />
            ))}
            <div className="absolute inset-0 bg-[url('/grid-pattern.svg')] opacity-[0.03]"></div>
        </div>
    );
};

const InputField = ({ label, type = "text", value, onChange, placeholder, required = false, disabled = false, textarea = false }) => {
    const [focused, setFocused] = useState(false);

    return (
        <div className="space-y-2 group">
            <label className={`text-xs font-bold uppercase tracking-wider transition-colors duration-300 ${focused ? 'text-primary' : 'text-text-body'}`}>
                {label} {required && <span className="text-primary">*</span>}
            </label>
            <div className="relative">
                {textarea ? (
                    <textarea
                        required={required}
                        value={value}
                        onChange={onChange}
                        onFocus={() => setFocused(true)}
                        onBlur={() => setFocused(false)}
                        disabled={disabled}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none transition-all duration-300 h-32 resize-none placeholder:text-white/20 backdrop-blur-sm"
                        placeholder={placeholder}
                    />
                ) : (
                    <input
                        type={type}
                        required={required}
                        value={value}
                        onChange={onChange}
                        onFocus={() => setFocused(true)}
                        onBlur={() => setFocused(false)}
                        disabled={disabled}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none transition-all duration-300 placeholder:text-white/20 backdrop-blur-sm"
                        placeholder={placeholder}
                    />
                )}

                {/* Animated Bottom Border */}
                <motion.div
                    initial={{ width: "0%" }}
                    animate={{ width: focused ? "100%" : "0%" }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-primary via-orange-400 to-primary rounded-b-xl"
                />
            </div>
        </div>
    );
};

const Contact = () => {
    const { t, i18n } = useTranslation();
    const isZh = i18n.language === 'zh' || i18n.language === 'zh-CN';
    const [formState, setFormState] = useState({
        firstName: '',
        lastName: '',
        email: '',
        message: ''
    });
    const [status, setStatus] = useState('idle'); // idle, sending, success, error

    const handleSubmit = async (e) => {
        e.preventDefault();
        setStatus('sending');

        // EmailJS Configuration
        const serviceId = 'service_iaxgbvd';
        const templateId = 'template_fezcw0d';
        const publicKey = 'SdxGxQBrcyWcUiyVh';

        // Prepare template parameters matching your EmailJS template
        const templateParams = {
            name: `${formState.firstName} ${formState.lastName}`,
            email: formState.email,
            message: formState.message,
            title: `New Inquiry from ${formState.firstName}`
        };

        try {
            await emailjs.send(serviceId, templateId, templateParams, publicKey);
            setStatus('success');
            setFormState({ firstName: '', lastName: '', email: '', message: '' });
            setTimeout(() => setStatus('idle'), 5000);
        } catch (error) {
            console.error('EmailJS Error:', error);
            setStatus('error');
            setTimeout(() => setStatus('idle'), 5000);
        }
    };

    return (
        <div className="min-h-screen pt-24 pb-16 md:pt-32 md:pb-24 bg-[#050505] relative overflow-hidden font-sans">
            <BackgroundParticles />

            {/* Main Content */}
            <div className="container mx-auto px-6 relative z-10">
                <div className="text-center mb-20 relative">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="absolute left-1/2 -top-20 -translate-x-1/2 w-[600px] h-[300px] bg-primary/20 blur-[120px] rounded-full pointer-events-none"
                    />

                    <motion.h1
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight"
                    >
                        {t('contact.titlePrefix')} <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-400">ConaPay</span>
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-xl text-text-body max-w-2xl mx-auto font-light leading-relaxed"
                    >
                        {t('contact.subtitle')}
                    </motion.p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 max-w-6xl mx-auto items-start">
                    {/* Left Column: Context & Direct Config */}
                    <motion.div
                        initial={{ opacity: 0, x: -50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2, duration: 0.8 }}
                        className="space-y-10"
                    >
                        <div>
                            <h2 className="text-3xl font-bold text-white mb-6">{t('contact.intro.title')}</h2>
                            <p className="text-text-body leading-relaxed mb-8 text-lg">
                                {t('contact.intro.desc')}
                            </p>
                        </div>

                        <div className="space-y-6">
                            {/* Official Email Card */}
                            <div className="group relative">
                                <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/50 to-orange-600/50 rounded-2xl opacity-0 group-hover:opacity-100 transition duration-500 blur"></div>
                                <div className="relative bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
                                    <div className="flex items-start gap-4">
                                        <div className="p-3 rounded-xl bg-white/5 text-primary group-hover:bg-primary group-hover:text-white transition-colors duration-300 shrink-0">
                                            <Mail size={24} />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-bold text-white mb-1">{t('contact.info.email.title')}</h3>
                                            <p className="text-sm text-text-body mb-2">{t('contact.info.email.desc')}</p>
                                            <div className="text-white/60 font-mono text-sm">
                                                official@conapay.global
                                            </div>
                                        </div>
                                    </div>
                                    <a href="mailto:official@conapay.global" className="mt-2 sm:mt-0 w-full sm:w-auto px-6 py-2.5 bg-white/5 hover:bg-primary/20 border border-white/10 hover:border-primary/50 rounded-xl text-white text-sm font-semibold transition-all duration-300 flex items-center justify-center gap-2 group/btn shrink-0">
                                        {isZh ? '发送邮件' : 'Send Email'} <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                                    </a>
                                </div>
                            </div>

                            {/* Telegram Support Card */}
                            <div className="group relative">
                                <div className="absolute -inset-0.5 bg-gradient-to-r from-[#229ED9]/50 to-blue-600/50 rounded-2xl opacity-0 group-hover:opacity-100 transition duration-500 blur"></div>
                                <div className="relative bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
                                    <div className="flex items-start gap-4">
                                        <div className="p-3 rounded-xl bg-white/5 text-[#229ED9] group-hover:bg-[#229ED9] group-hover:text-white transition-colors duration-300 shrink-0">
                                            <Send size={24} />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-bold text-white mb-1">{t('contact.info.telegram.title')}</h3>
                                            <p className="text-sm text-text-body mb-2">{t('contact.info.telegram.desc')}</p>
                                            <div className="text-white/60 font-mono text-sm">
                                                @ConaPayRicky
                                            </div>
                                        </div>
                                    </div>
                                    <a href="https://t.me/ConaPayRicky" target="_blank" rel="noopener noreferrer" className="mt-2 sm:mt-0 w-full sm:w-auto px-6 py-2.5 bg-[#229ED9]/10 hover:bg-[#229ED9]/20 border border-[#229ED9]/20 hover:border-[#229ED9]/50 rounded-xl text-white text-sm font-semibold transition-all duration-300 flex items-center justify-center gap-2 group/btn shrink-0">
                                        {isZh ? '发起对话' : 'Open Chat'} <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </motion.div>

                    {/* Right Column: Holographic Contact Form */}
                    <motion.div
                        initial={{ opacity: 0, x: 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                    >
                        <div className="relative group perspective-[1000px]">
                            {/* Gradient Border & Glow */}
                            <div className="absolute -inset-[1px] bg-gradient-to-b from-white/20 via-primary/20 to-transparent rounded-3xl opacity-100 group-hover:via-primary/40 transition-all duration-700"></div>
                            <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent rounded-3xl opacity-20 blur-2xl group-hover:opacity-30 transition-opacity duration-700"></div>

                            {/* Glass Container */}
                            <div className="relative bg-[#0A0A0A]/80 backdrop-blur-xl border border-white/5 rounded-3xl p-8 md:p-10 shadow-2xl overflow-hidden">
                                {/* Internal Shine */}
                                <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-white/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

                                <AnimatePresence mode="wait">
                                    {status === 'success' ? (
                                        <motion.div
                                            key="success"
                                            initial={{ opacity: 0, scale: 0.9 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            exit={{ opacity: 0, scale: 0.9 }}
                                            className="flex flex-col items-center justify-center py-20 text-center relative z-10"
                                        >
                                            <motion.div
                                                initial={{ scale: 0 }}
                                                animate={{ scale: 1 }}
                                                type="spring"
                                                className="w-24 h-24 bg-gradient-to-br from-primary to-orange-600 rounded-full flex items-center justify-center text-white mb-6 shadow-lg shadow-primary/30"
                                            >
                                                <CheckCircle size={48} />
                                            </motion.div>
                                            <h3 className="text-3xl font-bold text-white mb-2">{t('contact.form.success.title')}</h3>
                                            <p className="text-text-body max-w-xs mb-8">
                                                {t('contact.form.success.desc')} <strong>{formState.email}</strong> {t('contact.form.success.emailSuffix')}
                                            </p>
                                            <button
                                                onClick={() => setStatus('idle')}
                                                className="text-white hover:text-primary transition-colors text-sm font-semibold flex items-center gap-2 group"
                                            >
                                                {t('contact.form.success.retry')} <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                                            </button>
                                        </motion.div>
                                    ) : (
                                        <form key="form" onSubmit={handleSubmit} className="space-y-6 relative z-10">
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                                <InputField
                                                    label={t('contact.form.firstName')}
                                                    value={formState.firstName}
                                                    onChange={(e) => setFormState({ ...formState, firstName: e.target.value })}
                                                    placeholder={t('contact.form.placeholders.firstName')}
                                                    required
                                                    disabled={status === 'sending'}
                                                />
                                                <InputField
                                                    label={t('contact.form.lastName')}
                                                    value={formState.lastName}
                                                    onChange={(e) => setFormState({ ...formState, lastName: e.target.value })}
                                                    placeholder={t('contact.form.placeholders.lastName')}
                                                    disabled={status === 'sending'}
                                                />
                                            </div>

                                            <InputField
                                                label={t('contact.form.email')}
                                                type="email"
                                                value={formState.email}
                                                onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                                                placeholder={t('contact.form.placeholders.email')}
                                                required
                                                disabled={status === 'sending'}
                                            />

                                            <InputField
                                                label={t('contact.form.message')}
                                                textarea
                                                value={formState.message}
                                                onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                                                placeholder={t('contact.form.placeholders.message')}
                                                required
                                                disabled={status === 'sending'}
                                            />

                                            <button
                                                type="submit"
                                                disabled={status === 'sending'}
                                                className={`w-full bg-gradient-to-r from-primary to-orange-600 text-white font-bold py-5 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 group shadow-lg shadow-primary/20 hover:shadow-primary/40 disabled:opacity-70 disabled:cursor-not-allowed ${status === 'sending' ? 'opacity-70' : 'hover:scale-[1.02]'}`}
                                            >
                                                {status === 'sending' ? (
                                                    <>
                                                        <Loader2 size={24} className="animate-spin" /> {t('contact.form.sending')}
                                                    </>
                                                ) : status === 'error' ? (
                                                    <>
                                                        <AlertCircle size={24} /> {t('contact.form.failed')}
                                                    </>
                                                ) : (
                                                    <>
                                                        {t('contact.form.submit')} <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
                                                    </>
                                                )}
                                            </button>

                                            {status === 'error' && (
                                                <motion.p
                                                    initial={{ opacity: 0 }}
                                                    animate={{ opacity: 1 }}
                                                    className="text-red-500 text-sm text-center mt-2"
                                                >
                                                    {t('contact.form.errorMsg')}
                                                </motion.p>
                                            )}
                                        </form>
                                    )}
                                </AnimatePresence>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};

export default Contact;
