import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeftRight, ArrowRight, Globe, Layers, Wallet, Zap } from 'lucide-react';
import HeroParticles from './Home/HeroParticles';
import { useTranslation } from 'react-i18next';

const About = () => {
    const { t } = useTranslation();

    return (
        <div className="min-h-screen bg-[#050505] relative overflow-hidden text-white font-sans selection:bg-primary/30">
            {/* Rich Aurora Background */}
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-primary/20 blur-[120px] rounded-full mix-blend-screen animate-pulse duration-[5000ms]"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[60%] bg-orange-600/10 blur-[150px] rounded-full mix-blend-screen"></div>
                <div className="absolute top-[40%] left-[30%] w-[600px] h-[600px] bg-blue-900/10 blur-[100px] rounded-full mix-blend-screen"></div>
                <HeroParticles />
            </div>

            {/* Hero Section */}
            <section className="relative pt-40 pb-32 container mx-auto px-6 z-10 flex flex-col items-center text-center">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                >
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-md mb-8">
                        <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                        <span className="text-sm font-medium text-white/80 tracking-wide uppercase">{t('about.badge')}</span>
                    </div>

                    <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-8 tracking-tight leading-[1.1]">
                        {t('about.titlePrefix')} <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-orange-200 to-white">
                            {t('about.titleHighlight')}
                        </span>
                    </h1>

                    <p className="text-xl md:text-2xl text-text-body/90 max-w-3xl mx-auto leading-relaxed font-light">
                        {t('about.subtitle')}
                    </p>
                </motion.div>
            </section>

            {/* The Reality Check (Bento Grid) */}
            <section className="py-24 relative z-10">
                <div className="container mx-auto px-6">
                    <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
                        <div className="max-w-xl">
                            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">{t('about.reality.title')}</h2>
                            <p className="text-lg text-text-body">{t('about.reality.desc')}</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Card 1: The Old Way */}
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="col-span-1 p-8 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-lg hover:bg-white/[0.07] transition-all"
                        >
                            <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center text-red-400 mb-6">
                                <Layers size={24} />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-3">{t('about.reality.legacy.title')}</h3>
                            <ul className="space-y-3 text-white/60">
                                <li className="flex items-center gap-2"><span>×</span> {t('about.reality.legacy.points.settlement')}</li>
                                <li className="flex items-center gap-2"><span>×</span> {t('about.reality.legacy.points.spreads')}</li>
                                <li className="flex items-center gap-2"><span>×</span> {t('about.reality.legacy.points.fees')}</li>
                            </ul>
                        </motion.div>

                        {/* Card 2: The ConaPay Way (Featured) */}
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.1 }}
                            className="col-span-1 md:col-span-2 p-8 rounded-3xl bg-gradient-to-br from-primary/10 to-black border border-primary/20 backdrop-blur-lg relative overflow-hidden group"
                        >
                            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[80px] rounded-full group-hover:bg-primary/30 transition-all duration-700"></div>

                            <div className="relative z-10 flex flex-col h-full justify-between">
                                <div>
                                    <div className="flex items-center gap-4 mb-6">
                                        <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary">
                                            <Zap size={24} />
                                        </div>
                                        <span className="px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-wider">
                                            {t('about.reality.standard.badge')}
                                        </span>
                                    </div>
                                    <h3 className="text-3xl font-bold text-white mb-4">{t('about.reality.standard.title')}</h3>
                                    <p className="text-lg text-text-body max-w-lg">
                                        {t('about.reality.standard.desc')}
                                    </p>
                                </div>

                                <div className="mt-8 grid grid-cols-3 gap-4 border-t border-white/10 pt-8">
                                    <div>
                                        <div className="text-2xl font-bold text-white mb-1">T+0</div>
                                        <div className="text-sm text-white/50">{t('about.reality.standard.stats.settlement')}</div>
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-white mb-1">{t('about.reality.standard.stats.midMarket')}</div>
                                        <div className="text-sm text-white/50">{t('about.reality.standard.stats.rates')}</div>
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-white mb-1">100%</div>
                                        <div className="text-sm text-white/50">{t('about.reality.standard.stats.traceability')}</div>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Core Capabilities (Horizontal Scroll / Grid) */}
            <section className="py-24 relative z-10 border-t border-white/5 bg-black/20">
                <div className="container mx-auto px-6">
                    <div className="mb-16">
                        <h2 className="text-4xl font-bold text-white mb-6">{t('about.pillars.title')}</h2>
                        <p className="text-xl text-text-body max-w-2xl">
                            {t('about.pillars.subtitle')}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {/* Pillar 1: Integrated Pay-In & Pay-Out */}
                        <div className="group p-8 rounded-3xl bg-[#0A0A0A] border border-white/10 hover:border-primary/40 transition-colors duration-300">
                            <div className="mb-8 p-4 rounded-2xl bg-white/5 w-fit group-hover:bg-primary/20 group-hover:text-primary transition-colors text-white">
                                <ArrowLeftRight size={32} />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-4">{t('about.pillars.payinout.title')}</h3>
                            <p className="text-text-body leading-relaxed mb-6">
                                {t('about.pillars.payinout.desc')}
                            </p>
                            <ul className="text-sm text-white/60 space-y-2">
                                <li className="flex items-center gap-2">• {t('about.pillars.payinout.points.0')}</li>
                                <li className="flex items-center gap-2">• {t('about.pillars.payinout.points.1')}</li>
                                <li className="flex items-center gap-2">• {t('about.pillars.payinout.points.2')}</li>
                            </ul>
                        </div>

                        {/* Pillar 2: Digital Asset Settlement (USDT) */}
                        <div className="group p-8 rounded-3xl bg-[#0A0A0A] border border-white/10 hover:border-primary/40 transition-colors duration-300">
                            <div className="mb-8 p-4 rounded-2xl bg-white/5 w-fit group-hover:bg-primary/20 group-hover:text-primary transition-colors text-white">
                                <Wallet size={32} />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-4">{t('about.pillars.digital.title')}</h3>
                            <p className="text-text-body leading-relaxed mb-6">
                                {t('about.pillars.digital.desc')}
                            </p>
                            <ul className="text-sm text-white/60 space-y-2">
                                <li className="flex items-center gap-2">• {t('about.pillars.digital.points.0')}</li>
                                <li className="flex items-center gap-2">• {t('about.pillars.digital.points.1')}</li>
                                <li className="flex items-center gap-2">• {t('about.pillars.digital.points.2')}</li>
                            </ul>
                        </div>

                        {/* Pillar 3: Wholesale FX & Liquidity */}
                        <div className="group p-8 rounded-3xl bg-[#0A0A0A] border border-white/10 hover:border-primary/40 transition-colors duration-300">
                            <div className="mb-8 p-4 rounded-2xl bg-white/5 w-fit group-hover:bg-primary/20 group-hover:text-primary transition-colors text-white">
                                <Globe size={32} />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-4">{t('about.pillars.fx.title')}</h3>
                            <p className="text-text-body leading-relaxed mb-6">
                                {t('about.pillars.fx.desc')}
                            </p>
                            <ul className="text-sm text-white/60 space-y-2">
                                <li className="flex items-center gap-2">• {t('about.pillars.fx.points.0')}</li>
                                <li className="flex items-center gap-2">• {t('about.pillars.fx.points.1')}</li>
                                <li className="flex items-center gap-2">• {t('about.pillars.fx.points.2')}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-32 relative z-10 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent pointer-events-none"></div>
                <div className="container mx-auto px-6 text-center relative z-20">
                    <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">{t('about.cta.title')}</h2>
                    <p className="text-xl text-text-body max-w-2xl mx-auto mb-12">
                        {t('about.cta.subtitle')}
                    </p>
                    <a href="/contact" className="inline-flex items-center gap-3 px-8 py-4 bg-white text-black font-bold rounded-full hover:scale-105 transition-transform">
                        {t('about.cta.button')} <ArrowRight size={20} />
                    </a>
                </div>
            </section>
        </div>
    );
};

export default About;
