import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const FAQ = () => {
    const { t } = useTranslation();
    const [activeIndex, setActiveIndex] = useState(null);

    const faqs = [
        {
            question: t('home.faq.questions.settlement.q'),
            answer: t('home.faq.questions.settlement.a')
        },
        {
            question: t('home.faq.questions.highrisk.q'),
            answer: t('home.faq.questions.highrisk.a')
        },
        {
            question: t('home.faq.questions.conversion.q'),
            answer: t('home.faq.questions.conversion.a')
        },
        {
            question: t('home.faq.questions.liquidity.q'),
            answer: t('home.faq.questions.liquidity.a')
        }
    ];

    return (
        <section className="py-32 bg-[#050505] relative overflow-hidden">
            {/* Noise Texture */}
            <div className="absolute inset-0 opacity-[0.05] pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>

            {/* Glowing Separator */}
            <div className="absolute top-0 left-0 right-0 h-px w-full bg-gradient-to-r from-transparent via-orange-500 to-transparent opacity-50"></div>

            {/* Spotlight Effect - Cyber Scan */}
            <div
                className="absolute inset-0 pointer-events-none opacity-40 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.03)_50%,transparent_100%)] animate-scan-light bg-[length:200%_100%]"
            ></div>
            <div className="absolute top-0 left-1/2 w-[800px] h-[500px] bg-white/5 rounded-full blur-[150px] pointer-events-none -translate-x-1/2 -translate-y-1/2 opacity-30 mix-blend-overlay"></div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="flex flex-col lg:flex-row gap-16">
                    {/* Left Side: Title */}
                    <div className="lg:w-1/3">
                        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 sticky top-32">
                            {t('home.faq.title_prefix')} <br /> {t('home.faq.title_suffix')}
                        </h2>
                    </div>

                    {/* Right Side: Accordion */}
                    <div className="lg:w-2/3 space-y-4">
                        {faqs.map((faq, index) => (
                            <div
                                key={index}
                                className={`border rounded-xl overflow-hidden transition-all duration-300 ${activeIndex === index ? 'bg-surface/40 border-primary/30' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
                            >
                                <button
                                    className="w-full px-8 py-6 flex items-center justify-between text-left focus:outline-none"
                                    onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                                >
                                    <span className={`text-lg font-medium transition-colors ${activeIndex === index ? 'text-white' : 'text-text-body group-hover:text-white'}`}>
                                        {faq.question}
                                    </span>
                                    <span className={`transition-transform duration-300 ${activeIndex === index ? 'text-primary rotate-180' : 'text-text-body'}`}>
                                        {activeIndex === index ? <Minus size={24} /> : <Plus size={24} />}
                                    </span>
                                </button>

                                <AnimatePresence>
                                    {activeIndex === index && (
                                        <motion.div
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: 'auto', opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            transition={{ duration: 0.3, ease: 'easeInOut' }}
                                        >
                                            <div className="px-8 pb-8 pt-2 text-base text-text-body leading-relaxed">
                                                {faq.answer}
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default FAQ;
