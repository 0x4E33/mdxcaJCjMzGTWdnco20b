import React from 'react';
import { useTranslation } from 'react-i18next';

const partners = [
    { name: 'Visa', logo: 'https://placehold.co/120x40?text=VISA' },
    { name: 'Mastercard', logo: 'https://placehold.co/120x40?text=Mastercard' },
    { name: 'Binance Pay', logo: 'https://placehold.co/120x40?text=Binance' },
    { name: "Touch N' Go", logo: "https://placehold.co/120x40?text=TNG" },
    { name: 'Boost', logo: 'https://placehold.co/120x40?text=Boost' },
    { name: 'MAE', logo: 'https://placehold.co/120x40?text=MAE' },
    { name: 'Duitnow QR', logo: 'https://placehold.co/120x40?text=DuitnowQR' },
    { name: 'GCash', logo: 'https://placehold.co/120x40?text=GCash' },
    { name: 'QRIS', logo: 'https://placehold.co/120x40?text=QRIS' },
    { name: 'M-Pesa', logo: 'https://placehold.co/120x40?text=M-Pesa' },
    { name: 'MANDIRI', logo: 'https://placehold.co/120x40?text=MANDIRI' },
    { name: 'OPay', logo: 'https://placehold.co/120x40?text=OPay' },
    { name: 'Fawry Pay', logo: 'https://placehold.co/120x40?text=FawryPay' },
];

const TrustMarquee = () => {
    const { t } = useTranslation();

    return (
        <section className="py-24 border-y border-white/10 bg-[#0F0F0F] backdrop-blur-sm overflow-hidden">
            <div className="container mx-auto px-6 mb-12 text-center text-sm text-text-body font-medium uppercase tracking-widest opacity-60">
                {t('home.trust.title')}
            </div>

            <div className="relative flex overflow-x-hidden group">
                <div className="py-4 animate-marquee whitespace-nowrap flex items-center gap-24">
                    {/* Double the list for seamless loop */}
                    {[...partners, ...partners].map((partner, index) => (
                        <div key={`${partner.name}-${index}`} className="flex-shrink-0 grayscale hover:grayscale-0 opacity-40 hover:opacity-100 transition-all duration-300">
                            {/* Using names for now as placeholders are ugly, but user requested slow down */}
                            <span className="text-2xl font-bold text-white tracking-tight">{partner.name}</span>
                        </div>
                    ))}
                </div>
                <div className="absolute top-0 py-4 animate-marquee2 whitespace-nowrap flex items-center gap-24">
                    {[...partners, ...partners].map((partner, index) => (
                        <div key={`${partner.name}-${index}-2`} className="flex-shrink-0 grayscale hover:grayscale-0 opacity-40 hover:opacity-100 transition-all duration-300">
                            <span className="text-2xl font-bold text-white tracking-tight">{partner.name}</span>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default TrustMarquee;
