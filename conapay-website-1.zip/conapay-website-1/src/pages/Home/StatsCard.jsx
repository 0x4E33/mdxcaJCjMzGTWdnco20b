import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';

const StatsCard = () => {
    const { t } = useTranslation();

    const stats = [
        { label: t('home.stats.volume.label'), value: '$10M+', sub: t('home.stats.volume.sub') },
        { label: t('home.stats.currencies.label'), value: '50+', sub: t('home.stats.currencies.sub') },
        { label: t('home.stats.uptime.label'), value: '99.9%', sub: t('home.stats.uptime.sub') },
        { label: t('home.stats.apms.label'), value: '200+', sub: t('home.stats.apms.sub') },
    ];

    return (
        <section className="relative mt-4 md:-mt-20 z-20 container mx-auto px-6 mb-24">
            <div className="glass-card rounded-2xl p-6 pt-16 md:pt-20 md:p-12 shadow-2xl relative overflow-hidden bg-[#111111]/60 backdrop-blur-xl border border-white/5">
                {/* Live Indicator */}
                <div className="absolute top-6 right-6 flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 border border-green-500/30">
                    <div className="relative flex items-center justify-center w-2.5 h-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </div>
                    <span className="text-xs font-mono text-green-500 uppercase tracking-wider">{t('home.stats.operational')}</span>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-y-8 gap-x-4 md:gap-12 mt-4 md:mt-0">
                    {stats.map((stat, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className={`flex flex-col text-center md:text-left ${index % 2 === 0 ? 'border-r border-white/5' : ''} lg:border-r lg:last:border-r-0`}
                        >
                            <h3 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-1 md:mb-2 tracking-tight">
                                {stat.value}
                            </h3>
                            <p className="text-[10px] sm:text-xs md:text-sm font-semibold text-primary mb-0.5 md:mb-1 uppercase tracking-wider">
                                {stat.label}
                            </p>
                            <p className="text-[10px] md:text-xs text-text-body">
                                {stat.sub}
                            </p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default StatsCard;
