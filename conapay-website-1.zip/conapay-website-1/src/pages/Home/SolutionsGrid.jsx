import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Coins, Gamepad2, Globe2, Building, Home, Plane, Banknote, Radio } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const SolutionsGrid = () => {
    const { t } = useTranslation();

    const solutions = [
        {
            title: t('home.solutions.items.ecommerce.title'),
            desc: t('home.solutions.items.ecommerce.desc'),
            icon: <ShoppingCart size={28} />
        },
        {
            title: t('home.solutions.items.web3.title'),
            desc: t('home.solutions.items.web3.desc'),
            icon: <Coins size={28} />
        },
        {
            title: t('home.solutions.items.gaming.title'),
            desc: t('home.solutions.items.gaming.desc'),
            icon: <Gamepad2 size={28} />
        },
        {
            title: t('home.solutions.items.streaming.title'),
            desc: t('home.solutions.items.streaming.desc'),
            icon: <Radio size={28} />
        },
        {
            title: t('home.solutions.items.crossborder.title'),
            desc: t('home.solutions.items.crossborder.desc'),
            icon: <Globe2 size={28} />
        },
        {
            title: t('home.solutions.items.realestate.title'),
            desc: t('home.solutions.items.realestate.desc'),
            icon: <Home size={28} />
        },
        {
            title: t('home.solutions.items.travel.title'),
            desc: t('home.solutions.items.travel.desc'),
            icon: <Plane size={28} />
        },
        {
            title: t('home.solutions.items.payroll.title'),
            desc: t('home.solutions.items.payroll.desc'),
            icon: <Banknote size={28} />
        }
    ];

    return (
        <section className="py-32 relative z-10 bg-[#020204] border-t border-white/5 overflow-hidden">
            {/* Digital Blueprint Grid - Animated */}
            <div className="absolute inset-0 z-0">
                <div className="absolute inset-0 bg-[#020204]"></div>
                <div
                    className="absolute inset-[-50%] bg-[linear-gradient(to_right,rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px] animate-grid-flow opacity-30"
                    style={{
                        maskImage: 'radial-gradient(ellipse at center, black 40%, transparent 80%)',
                        WebkitMaskImage: 'radial-gradient(ellipse at center, black 40%, transparent 80%)',
                        transform: 'perspective(500px) rotateX(20deg)'
                    }}
                ></div>
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
                        {t('home.solutions.title_prefix')} <br />
                        <span className="text-primary">{t('home.solutions.title_highlight')}</span>
                        {/* Assuming title suffix logic or direct string concatenation */}
                    </h2>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
                    {solutions.map((item, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.05 }}
                            className="group relative p-4 sm:p-5 md:p-8 rounded-xl md:rounded-2xl bg-white/5 border border-white/5 hover:border-primary/50 hover:bg-white/10 transition-all duration-300 overflow-hidden flex flex-col h-full"
                        >
                            <div className="relative z-10 flex flex-col items-center text-center md:items-start md:text-left">
                                <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/5 flex items-center justify-center text-primary mb-3 md:mb-6 group-hover:scale-110 transition-transform duration-300">
                                    <div className="scale-75 md:scale-100 flex items-center justify-center">
                                        {item.icon}
                                    </div>
                                </div>
                                <h3 className="text-sm sm:text-base md:text-xl font-bold text-white mb-1 md:mb-2">{item.title}</h3>
                                <p className="text-text-body text-[10px] sm:text-xs md:text-sm leading-relaxed line-clamp-3 md:line-clamp-none">{item.desc}</p>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default SolutionsGrid;
