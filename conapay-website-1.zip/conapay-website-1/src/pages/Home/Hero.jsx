import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, PlayCircle } from 'lucide-react';
import HeroParticles from './HeroParticles';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Hero = () => {
    const { t } = useTranslation();

    return (
        <section className="relative min-h-[85vh] flex items-center pt-28 pb-16 md:pt-20 md:pb-32 overflow-hidden">
            {/* Programmatic Background */}
            <HeroParticles />

            {/* Gradient Overlay for Depth */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent pointer-events-none"></div>
            {/* Radial Gradient for central depth */}
            <div
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[100%] h-[100%] pointer-events-none opacity-60"
                style={{ background: 'radial-gradient(circle at center, rgba(255, 153, 0, 0.15) 0%, rgba(0,0,0,0) 70%)' }}
            ></div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="flex flex-col lg:flex-row items-center gap-6 lg:gap-12">
                    {/* Left Column: Content */}
                    <div className="lg:w-1/2 text-left z-20">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.9, x: -20 }}
                            animate={{ opacity: 1, scale: 1, x: 0 }}
                            transition={{ duration: 0.5 }}
                            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md mb-6"
                        >
                            <span className="flex h-2 w-2 relative">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                            </span>
                            <span className="text-sm font-medium text-white tracking-wide">{t('home.hero.badge')}</span>
                        </motion.div>

                        <motion.h1
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.8 }}
                            className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight leading-[1.05]"
                        >
                            {t('home.hero.title_prefix')} <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/50">{t('home.hero.title_highlight')}</span> <br />
                            {t('home.hero.title_suffix')}
                        </motion.h1>

                        <motion.p
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.8, delay: 0.2 }}
                            className="text-xl text-text-body mb-10 max-w-xl leading-relaxed font-light"
                        >
                            {t('home.hero.subtitle')}
                        </motion.p>

                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.4 }}
                            className="flex flex-col sm:flex-row gap-4"
                        >
                            <a
                                href="/contact"
                                className="px-8 py-4 bg-primary text-white text-lg font-bold rounded-full hover:bg-primary-hover transition-all duration-300 shadow-[0_0_20px_rgba(255,153,0,0.3)] hover:shadow-[0_0_40px_rgba(255,153,0,0.5)] flex items-center justify-center gap-2"
                            >
                                {t('home.hero.cta')}
                                <ArrowRight size={20} />
                            </a>
                            <Link
                                to="/network"
                                className="px-8 py-4 rounded-full border border-white/20 text-white font-bold hover:bg-white/5 transition-all duration-300 backdrop-blur-sm"
                            >
                                {t('home.hero.coverage')}
                            </Link>
                        </motion.div>
                    </div>

                    {/* Right Column: 3D Floating Interface Visual */}
                    <div className="lg:w-1/2 relative h-[400px] md:h-[500px] w-full flex items-center justify-center perspective-[2000px] mt-8 lg:mt-0 scale-90 sm:scale-100 origin-center">
                        {/* Card Stack Container */}
                        <motion.div
                            initial={{ opacity: 0, rotateX: 20, rotateY: -20, scale: 0.8 }}
                            animate={{ opacity: 1, rotateX: 10, rotateY: -10, scale: 1 }}
                            transition={{ duration: 1, delay: 0.2 }}
                            className="relative w-full max-w-[340px] md:max-w-[380px] h-[480px] preserve-3d"
                            style={{ transformStyle: 'preserve-3d' }}
                        >
                            {/* Floating Elements Animation Wrapper */}
                            <motion.div
                                animate={{ y: [-10, 10, -10] }}
                                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                                className="relative w-full h-full"
                                style={{ transformStyle: 'preserve-3d' }}
                            >
                                {/* Main Dashboard Card */}
                                <div className="absolute inset-0 bg-[#0A0A0A]/90 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-6 flex flex-col justify-between z-20">
                                    {/* Header */}
                                    <div className="flex items-center justify-between border-b border-white/5 pb-4">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xs">CP</div>
                                            <div>
                                                <div className="text-sm font-bold text-white">{t('home.hero.dashboard.title')}</div>
                                                <div className="text-[10px] text-text-body">{t('home.hero.dashboard.feed')}</div>
                                            </div>
                                        </div>
                                        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div>
                                    </div>

                                    {/* Chart Visual (CSS) */}
                                    <div className="flex-1 py-6 flex items-end justify-between gap-2">
                                        {[40, 65, 45, 80, 55, 90, 70].map((h, i) => (
                                            <div key={i} className="w-full bg-primary/10 rounded-t-sm relative group overflow-hidden" style={{ height: `${h}%` }}>
                                                <div className="absolute bottom-0 left-0 right-0 h-full bg-gradient-to-t from-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                                            </div>
                                        ))}
                                    </div>

                                    {/* Stats Row */}
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-white/5 rounded-xl p-4">
                                            <div className="text-xs text-text-body mb-1">{t('home.hero.dashboard.volume')}</div>
                                            <div className="text-lg font-bold text-white">$2.4M</div>
                                        </div>
                                        <div className="bg-white/5 rounded-xl p-4">
                                            <div className="text-xs text-text-body mb-1">{t('home.hero.dashboard.success')}</div>
                                            <div className="text-lg font-bold text-green-400">99.9%</div>
                                        </div>
                                    </div>
                                </div>

                                {/* Floating Payment Success Card (Front) */}
                                <motion.div
                                    animate={{ x: [0, 10, 0], y: [0, -10, 0] }}
                                    transition={{ duration: 4, repeat: Infinity, delay: 1 }}
                                    className="absolute -right-4 md:-right-12 top-24 md:top-20 w-56 md:w-64 bg-[#111] border border-white/10 rounded-xl p-3 md:p-4 shadow-2xl z-30"
                                    style={{ transform: 'translateZ(50px)' }}
                                >
                                    <div className="flex items-center gap-3 mb-3">
                                        <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center text-green-500">
                                            <svg className="svg-glow-strong svg-anim-draw" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                        </div>
                                        <div>
                                            <div className="text-sm text-white font-bold">{t('home.hero.dashboard.received')}</div>
                                            <div className="text-xs text-text-body">{t('home.hero.dashboard.justnow')}</div>
                                        </div>
                                    </div>
                                    <div className="text-lg font-mono text-white">1,250.00 <span className="text-xs text-text-body">USD</span></div>
                                </motion.div>

                                {/* Floating Background Glow */}
                                <div className="absolute -inset-10 bg-gradient-to-tr from-primary/20 to-purple-500/20 blur-[60px] rounded-full z-0 pointer-events-none"></div>
                            </motion.div>
                        </motion.div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
