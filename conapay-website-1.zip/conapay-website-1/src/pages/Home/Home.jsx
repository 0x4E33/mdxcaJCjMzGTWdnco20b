import React from 'react';
import Hero from './Hero';
import StatsCard from './StatsCard';
import SolutionsGrid from './SolutionsGrid';
import FeaturesGrid from './FeaturesGrid';
import TrustMarquee from './TrustMarquee';
import FAQ from './FAQ';

const Home = () => {
    return (
        <div className="flex flex-col">
            <Hero />
            <StatsCard />
            <SolutionsGrid />
            {/* FeaturesGrid can be kept as "Why Choose Us" or removed if redundant. Keeping as per plan. */}
            {/* FeaturesGrid can be kept as "Why Choose Us" or removed if redundant. Keeping as per plan. */}
            <FeaturesGrid />
            <FAQ />
            <TrustMarquee />
        </div>
    );
};

export default Home;
