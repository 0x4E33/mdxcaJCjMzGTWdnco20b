import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';

const FeaturesGrid = () => {
    const { t } = useTranslation();

    const features = [
        {
            title: t('home.features.items.reach.title'),
            desc: t('home.features.items.reach.desc'),
            icon: (
                <svg className="w-10 h-10 text-primary svg-glow svg-anim-draw" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M2 12H22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M12 2C14.5013 4.73835 15.9228 8.29203 16 12C15.9228 15.708 14.5013 19.2616 12 22C9.49872 19.2616 8.07725 15.708 8 12C8.07725 8.29203 9.49872 4.73835 12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            )
        },
        {
            title: t('home.features.items.settlement.title'),
            desc: t('home.features.items.settlement.desc'),
            icon: (
                <svg className="w-10 h-10 text-primary svg-glow svg-anim-draw" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            )
        },
        {
            title: t('home.features.items.compliance.title'),
            desc: t('home.features.items.compliance.desc'),
            icon: (
                <svg className="w-10 h-10 text-primary svg-glow svg-anim-draw" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 22C12 22 20 18 20 12V5L12 2L4 5V12C4 18 12 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M9 12L11 14L15 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            )
        },
        {
            title: t('home.features.items.developer.title'),
            desc: t('home.features.items.developer.desc'),
            icon: (
                <svg className="w-10 h-10 text-primary svg-glow svg-anim-draw" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16 18L22 12L16 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M8 6L2 12L8 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            )
        },
        {
            title: t('home.features.items.treasury.title'),
            desc: t('home.features.items.treasury.desc'),
            icon: (
                <svg className="w-10 h-10 text-primary svg-glow svg-anim-draw" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 1L22 6L12 11L2 6L12 1Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            )
        },
        {
            title: t('home.features.items.fraud.title'),
            desc: t('home.features.items.fraud.desc'),
            icon: (
                <svg className="w-10 h-10 text-primary svg-glow svg-anim-draw" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M9 9L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M15 9L9 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            )
        }
    ];

    return (
        <section className="py-24 relative bg-black overflow-hidden">
            {/* Energy Core: Quantum Pulse (Multi-layer Gradients) */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] pointer-events-none">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] mix-blend-screen animate-blob-bounce"></div>
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-600/20 rounded-full blur-[120px] mix-blend-screen animate-blob-bounce [animation-delay:2s]"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-[100px] mix-blend-screen animate-pulse-slow"></div>
            </div>

            <div className="container mx-auto px-6 mb-16 relative z-10">
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">{t('home.features.title')}</h2>
                <p className="text-xl text-text-body max-w-2xl">
                    {t('home.features.subtitle')}
                </p>
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
                    {features.map((feature, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            className="group relative bg-white/5 backdrop-blur-md border border-white/10 rounded-xl md:rounded-2xl p-4 md:p-8 hover:border-primary/50 transition-all duration-300 overflow-hidden"
                        >
                            {/* Hover Gradient Glow */}
                            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>

                            <div className="mb-3 md:mb-6 relative z-10 w-10 h-10 md:w-16 md:h-16 rounded-lg md:rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-primary/20 group-hover:animate-float transition-colors duration-300">
                                <div className="scale-75 md:scale-100 flex items-center justify-center">
                                    {feature.icon}
                                </div>
                            </div>

                            <h3 className="text-sm md:text-xl font-bold text-white mb-1 md:mb-3 relative z-10">{feature.title}</h3>
                            <p className="text-[10px] md:text-base text-text-body leading-relaxed md:leading-relaxed relative z-10 line-clamp-4 md:line-clamp-none">
                                {feature.desc}
                            </p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FeaturesGrid;
