import React from 'react';
import { motion } from 'framer-motion';

const stats = [
    { label: 'Daily Transactions', value: '$10M+', description: 'Processing volume at scale' },
    { label: 'Uptime Guarantee', value: '99.9%', description: 'Enterprise-grade reliability' },
    { label: 'Global Coverage', value: '50+', description: 'Native corridors supported' },
    { label: 'Settlement Time', value: '<24h', description: 'Faster than SWIFT' },
];

const Metrics = () => {
    return (
        <section className="py-24 bg-background">
            <div className="container mx-auto px-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {stats.map((stat, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            className="bg-surface/30 border border-white/5 p-8 rounded-xl hover:border-primary/30 transition-colors duration-300 group"
                        >
                            <h3 className="text-4xl font-extrabold text-white mb-2 group-hover:text-primary transition-colors">
                                {stat.value}
                            </h3>
                            <p className="text-white font-semibold mb-1">{stat.label}</p>
                            <p className="text-sm text-text-body">{stat.description}</p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Metrics;
