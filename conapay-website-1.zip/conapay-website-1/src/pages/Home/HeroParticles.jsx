import React, { useEffect, useRef } from 'react';

const HeroParticles = () => {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        let animationFrameId;
        let w = canvas.width = window.innerWidth;
        let h = canvas.height = window.innerHeight;

        const particles = [];
        const properties = {
            bgColor: 'rgba(5, 5, 5, 1)',
            particleColor: 'rgba(255, 153, 0, 0.5)',
            particleRadius: 2,
            particleCount: 80,
            lineLength: 150,
            lineWidth: 0.5
        };

        class Particle {
            constructor() {
                this.x = Math.random() * w;
                this.y = Math.random() * h;
                this.velocityX = Math.random() * 0.5 - 0.25;
                this.velocityY = Math.random() * 0.5 - 0.25;
            }

            position() {
                this.x += this.velocityX + (Math.random() - 0.5) * 0.05; // Add subtle jitter
                this.y += this.velocityY + (Math.random() - 0.5) * 0.05;

                if (this.x > w) this.x = 0;
                else if (this.x < 0) this.x = w;
                if (this.y > h) this.y = 0;
                else if (this.y < 0) this.y = h;
            }

            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, properties.particleRadius, 0, Math.PI * 2);
                ctx.closePath();
                ctx.fillStyle = properties.particleColor;
                ctx.fill();
            }
        }

        const reDrawParticles = () => {
            for (let i = 0; i < particles.length; i++) {
                particles[i].position();
                particles[i].draw();
            }
        };

        const drawLines = () => {
            for (let i = 0; i < particles.length; i++) {
                for (let j = 0; j < particles.length; j++) {
                    const distance = Math.sqrt(
                        Math.pow(particles[j].x - particles[i].x, 2) + Math.pow(particles[j].y - particles[i].y, 2)
                    );
                    if (distance < properties.lineLength) {
                        const opacity = 1 - distance / properties.lineLength;
                        ctx.lineWidth = properties.lineWidth;
                        ctx.strokeStyle = `rgba(255, 153, 0, ${opacity * 0.4})`; // Orange connections
                        ctx.beginPath();
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.stroke();
                    }
                }
            }
        };

        const loop = () => {
            ctx.fillStyle = properties.bgColor;
            ctx.clearRect(0, 0, w, h); // Clear but keep transparent for overlay effect if needed, though bgColor is set

            reDrawParticles();
            drawLines();
            animationFrameId = requestAnimationFrame(loop);
        };

        const init = () => {
            // Re-adjust count based on screen size
            properties.particleCount = w > 800 ? 80 : 40;
            for (let i = 0; i < properties.particleCount; i++) {
                particles.push(new Particle());
            }
            loop();
        };

        const handleResize = () => {
            w = canvas.width = window.innerWidth;
            h = canvas.height = window.innerHeight;
            particles.length = 0;
            init();
        };

        init();
        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
            cancelAnimationFrame(animationFrameId);
        };
    }, []);

    return (
        <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none opacity-60"
        />
    );
};

export default HeroParticles;
