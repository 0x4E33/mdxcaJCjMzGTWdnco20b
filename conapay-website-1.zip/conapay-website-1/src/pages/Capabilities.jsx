import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { ShieldCheck, Zap, Server, ArrowRight, Globe } from 'lucide-react';
import HeroParticles from './Home/HeroParticles';
import { useTranslation } from 'react-i18next';

// Main Component
const Capabilities = () => {
    const { t } = useTranslation();
    const { hash } = useLocation();

    // Auto-scroll logic
    useEffect(() => {
        if (hash) {
            const id = hash.replace('#', '');
            const element = document.getElementById(id);
            if (element) {
                setTimeout(() => {
                    const offset = 120;
                    const elementPosition = element.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - offset;
                    window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                }, 100);
            }
        }
    }, [hash]);

    return (
        <div className="min-h-screen pt-24 pb-20 md:pt-32 md:pb-32 bg-background relative overflow-hidden">
            {/* Dynamic Background */}
            <HeroParticles />
            {/* Overlay for depth */}
            <div className="absolute inset-0 pointer-events-none bg-black/60"></div>

            <div className="absolute inset-0 pointer-events-none">
                {/* Moving Light Beam */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[500px] bg-gradient-to-b from-primary/10 via-transparent to-transparent blur-[100px] opacity-40"></div>
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="text-center mb-24 relative">
                    {/* Decorative Header Code Elements */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] pointer-events-none opacity-10">
                        <div className="absolute top-0 left-10 w-2 h-2 bg-primary rounded-full animate-ping"></div>
                        <div className="absolute bottom-10 right-10 w-2 h-2 bg-white rounded-full animate-ping delay-700"></div>
                        <svg className="w-full h-full svg-anim-draw" viewBox="0 0 100 100" preserveAspectRatio="none">
                            <path d="M0,50 Q25,25 50,50 T100,50" stroke="currentColor" strokeWidth="0.1" fill="none" className="text-primary animate-pulse svg-glow-strong" />
                        </svg>
                    </div>

                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-5xl md:text-7xl font-bold text-white mb-8 tracking-tight"
                    >
                        {t('capabilities.titlePrefix')} <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-orange-300 to-primary bg-300% animate-gradient">{t('capabilities.titleHighlight')}</span>
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.3 }}
                        className="text-xl text-text-body max-w-2xl mx-auto leading-relaxed font-light border-l-2 border-primary/30 pl-6"
                    >
                        {t('capabilities.subtitle')}
                    </motion.p>
                </div>

                {/* Interactive Spotlight Grid */}
                <div className="flex overflow-x-auto pb-4 -mx-6 px-6 snap-x snap-mandatory [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] md:grid md:grid-cols-2 md:gap-8 relative z-20 md:overflow-visible md:pb-0 md:mx-0 md:px-0">
                    {/* Capability 1: Payment Processing (Acquiring) */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="group relative p-6 md:p-8 rounded-3xl bg-[#0D0D0D] border border-white/10 hover:border-orange-500/50 transition-all duration-300 overflow-hidden min-w-[280px] w-[85vw] sm:w-[320px] md:min-w-0 md:w-auto shrink-0 snap-center mr-4 md:mr-0 last:mr-0"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative z-10">
                            <div className="bg-orange-500/10 w-14 h-14 rounded-xl flex items-center justify-center text-orange-400 mb-6 group-hover:scale-110 group-hover:animate-float transition-all duration-300">
                                <Globe size={28} className="svg-glow-strong animate-glow-pulse" />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-orange-400 transition-colors">{t('capabilities.items.acquiring.title')}</h3>
                            <p className="text-gray-400 leading-relaxed">
                                {t('capabilities.items.acquiring.desc')}
                            </p>
                        </div>
                    </motion.div>

                    {/* Capability 2: Express Transfer (Payout) */}
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.1 }}
                        className="group relative p-6 md:p-8 rounded-3xl bg-[#0D0D0D] border border-white/10 hover:border-blue-500/50 transition-all duration-300 overflow-hidden min-w-[280px] w-[85vw] sm:w-[320px] md:min-w-0 md:w-auto shrink-0 snap-center mr-4 md:mr-0 last:mr-0"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative z-10">
                            <div className="bg-blue-500/10 w-14 h-14 rounded-xl flex items-center justify-center text-blue-400 mb-6 group-hover:scale-110 group-hover:animate-float transition-all duration-300">
                                <Zap size={28} className="svg-glow-strong animate-glow-pulse" />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors">{t('capabilities.items.transfer.title')}</h3>
                            <p className="text-gray-400 leading-relaxed">
                                {t('capabilities.items.transfer.desc')}
                            </p>
                        </div>
                    </motion.div>

                    {/* Capability 3: Smart Settlement (Fiat/USDT) */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.2 }}
                        className="group relative p-6 md:p-8 rounded-3xl bg-[#0D0D0D] border border-white/10 hover:border-purple-500/50 transition-all duration-300 overflow-hidden min-w-[280px] w-[85vw] sm:w-[320px] md:min-w-0 md:w-auto shrink-0 snap-center mr-4 md:mr-0 last:mr-0"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative z-10">
                            <div className="bg-purple-500/10 w-14 h-14 rounded-xl flex items-center justify-center text-purple-400 mb-6 group-hover:scale-110 group-hover:animate-float transition-all duration-300">
                                <Server size={28} className="svg-glow-strong animate-glow-pulse" />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-purple-400 transition-colors">{t('capabilities.items.settlement.title')}</h3>
                            <p className="text-gray-400 leading-relaxed">
                                {t('capabilities.items.settlement.desc')}
                            </p>
                        </div>
                    </motion.div>

                    {/* Capability 4: Bank-Grade Security */}
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.3 }}
                        className="group relative p-6 md:p-8 rounded-3xl bg-[#0D0D0D] border border-white/10 hover:border-green-500/50 transition-all duration-300 overflow-hidden min-w-[280px] w-[85vw] sm:w-[320px] md:min-w-0 md:w-auto shrink-0 snap-center mr-4 md:mr-0 last:mr-0"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="relative z-10">
                            <div className="bg-green-500/10 w-14 h-14 rounded-xl flex items-center justify-center text-green-400 mb-6 group-hover:scale-110 group-hover:animate-float transition-all duration-300">
                                <ShieldCheck size={28} className="svg-glow-strong animate-glow-pulse" />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-green-400 transition-colors">{t('capabilities.items.security.title')}</h3>
                            <p className="text-gray-400 leading-relaxed">
                                {t('capabilities.items.security.desc')}
                            </p>
                        </div>
                    </motion.div>
                </div>

                {/* Bottom CTA */}
                <div className="mt-24 flex justify-center">
                    <a
                        href="/contact"
                        className="group relative inline-flex items-center justify-center px-8 py-4 bg-white text-black font-bold rounded-full overflow-hidden transition-transform hover:scale-105"
                    >
                        <span className="relative flex items-center gap-2">
                            {t('capabilities.cta')} <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                        </span>
                    </a>
                </div>
            </div>
        </div>
    );
};

export default Capabilities;
