import React from 'react';
import LegalLayout from '../components/LegalLayout';
import { useTranslation } from 'react-i18next';

const Cookies = () => {
    const { t } = useTranslation();

    return (
        <LegalLayout title={t('cookies.title')}>
            <h3>{t('cookies.sections.scope.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('cookies.sections.scope.content')}
            </p>

            <h3>{t('cookies.sections.types.title')}</h3>
            <p className="mb-4">{t('cookies.sections.types.intro')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('cookies.sections.types.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h3>{t('cookies.sections.use.title')}</h3>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('cookies.sections.use.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>

            <h3>{t('cookies.sections.cookies.title')}</h3>
            <p className="mb-4">{t('cookies.sections.cookies.intro')}</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
                {t('cookies.sections.cookies.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>
            <p className="mb-8 leading-relaxed">{t('cookies.sections.cookies.footer')}</p>

            <h3>{t('cookies.sections.share.title')}</h3>
            <p className="mb-4">{t('cookies.sections.share.intro')}</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
                {t('cookies.sections.share.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>
            <p className="mb-8 leading-relaxed">{t('cookies.sections.share.footer')}</p>

            <h3>{t('cookies.sections.storage.title')}</h3>
            <p className="mb-4">{t('cookies.sections.storage.intro')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('cookies.sections.storage.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>

            <h3>{t('cookies.sections.rights.title')}</h3>
            <p className="mb-4">{t('cookies.sections.rights.intro')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('cookies.sections.rights.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>
            <p className="mb-8">
                {t('cookies.sections.rights.footer')} <a href="mailto:official@conapay.global">official@conapay.global</a>
            </p>

            <h3>{t('cookies.sections.minors.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('cookies.sections.minors.content')}
            </p>

            <h3>{t('cookies.sections.crossborder.title')}</h3>
            <p className="mb-4">{t('cookies.sections.crossborder.intro')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('cookies.sections.crossborder.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>

            <h3>{t('cookies.sections.changes.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('cookies.sections.changes.content')}
            </p>
        </LegalLayout>
    );
};

export default Cookies;
