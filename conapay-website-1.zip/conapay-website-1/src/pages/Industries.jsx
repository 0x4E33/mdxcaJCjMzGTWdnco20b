import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { ShoppingBag, Coins, Gamepad2, Globe2, Radio, Home, Plane, Stethoscope, Lightbulb, Truck, GraduationCap, Banknote, ArrowRight, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const Industries = () => {
    const { t } = useTranslation();
    const { hash } = useLocation();

    const industries = [
        {
            id: 'global-payroll',
            title: t('industries.items.global-payroll.title'),
            icon: <Banknote size={24} />,
            tagline: t('industries.items.global-payroll.tagline'),
            content: t('industries.items.global-payroll.content'),
            features: [
                t('industries.items.global-payroll.features.0'),
                t('industries.items.global-payroll.features.1'),
                t('industries.items.global-payroll.features.2'),
                t('industries.items.global-payroll.features.3')
            ],
            stat: t('industries.items.global-payroll.stat')
        },
        {
            id: 'live-streaming',
            title: t('industries.items.live-streaming.title'),
            icon: <Radio size={24} />,
            tagline: t('industries.items.live-streaming.tagline'),
            content: t('industries.items.live-streaming.content'),
            features: [
                t('industries.items.live-streaming.features.0'),
                t('industries.items.live-streaming.features.1'),
                t('industries.items.live-streaming.features.2'),
                t('industries.items.live-streaming.features.3')
            ],
            stat: t('industries.items.live-streaming.stat')
        },
        {
            id: 'e-commerce',
            title: t('industries.items.e-commerce.title'),
            icon: <ShoppingBag size={24} />,
            tagline: t('industries.items.e-commerce.tagline'),
            content: t('industries.items.e-commerce.content'),
            features: [
                t('industries.items.e-commerce.features.0'),
                t('industries.items.e-commerce.features.1'),
                t('industries.items.e-commerce.features.2'),
                t('industries.items.e-commerce.features.3')
            ],
            stat: t('industries.items.e-commerce.stat')
        },
        {
            id: 'gaming',
            title: t('industries.items.gaming.title'),
            icon: <Gamepad2 size={24} />,
            tagline: t('industries.items.gaming.tagline'),
            content: t('industries.items.gaming.content'),
            features: [
                t('industries.items.gaming.features.0'),
                t('industries.items.gaming.features.1'),
                t('industries.items.gaming.features.2'),
                t('industries.items.gaming.features.3')
            ],
            stat: t('industries.items.gaming.stat')
        },
        {
            id: 'real-estate',
            title: t('industries.items.real-estate.title'),
            icon: <Home size={24} />,
            tagline: t('industries.items.real-estate.tagline'),
            content: t('industries.items.real-estate.content'),
            features: [
                t('industries.items.real-estate.features.0'),
                t('industries.items.real-estate.features.1'),
                t('industries.items.real-estate.features.2'),
                t('industries.items.real-estate.features.3')
            ],
            stat: t('industries.items.real-estate.stat')
        },
        {
            id: 'travel',
            title: t('industries.items.travel.title'),
            icon: <Plane size={24} />,
            tagline: t('industries.items.travel.tagline'),
            content: t('industries.items.travel.content'),
            features: [
                t('industries.items.travel.features.0'),
                t('industries.items.travel.features.1'),
                t('industries.items.travel.features.2'),
                t('industries.items.travel.features.3')
            ],
            stat: t('industries.items.travel.stat')
        },
        {
            id: 'healthcare',
            title: t('industries.items.healthcare.title'),
            icon: <Stethoscope size={24} />,
            tagline: t('industries.items.healthcare.tagline'),
            content: t('industries.items.healthcare.content'),
            features: [
                t('industries.items.healthcare.features.0'),
                t('industries.items.healthcare.features.1'),
                t('industries.items.healthcare.features.2'),
                t('industries.items.healthcare.features.3')
            ],
            stat: t('industries.items.healthcare.stat')
        },
        {
            id: 'energy',
            title: t('industries.items.energy.title'),
            icon: <Lightbulb size={24} />,
            tagline: t('industries.items.energy.tagline'),
            content: t('industries.items.energy.content'),
            features: [
                t('industries.items.energy.features.0'),
                t('industries.items.energy.features.1'),
                t('industries.items.energy.features.2'),
                t('industries.items.energy.features.3')
            ],
            stat: t('industries.items.energy.stat')
        },
        {
            id: 'supply-chain',
            title: t('industries.items.supply-chain.title'),
            icon: <Truck size={24} />,
            tagline: t('industries.items.supply-chain.tagline'),
            content: t('industries.items.supply-chain.content'),
            features: [
                t('industries.items.supply-chain.features.0'),
                t('industries.items.supply-chain.features.1'),
                t('industries.items.supply-chain.features.2'),
                t('industries.items.supply-chain.features.3')
            ],
            stat: t('industries.items.supply-chain.stat')
        },
        {
            id: 'education',
            title: t('industries.items.education.title'),
            icon: <GraduationCap size={24} />,
            tagline: t('industries.items.education.tagline'),
            content: t('industries.items.education.content'),
            features: [
                t('industries.items.education.features.0'),
                t('industries.items.education.features.1'),
                t('industries.items.education.features.2'),
                t('industries.items.education.features.3')
            ],
            stat: t('industries.items.education.stat')
        }
    ];

    const [activeTab, setActiveTab] = useState(industries[0].id);

    // Deep linking logic
    useEffect(() => {
        if (hash) {
            const id = hash.replace('#', '');
            const found = industries.find(i => i.id === id);
            if (found) {
                setActiveTab(id);
            }
        }
    }, [hash]); // We can't easily rely on industries array as a dependency for this effect without creating loops or using memo, but since it's derived from 't', it should be stable enough per render cycle or we can just ignore it for the deep link effect which is mainly on mount.
    // Actually, if language changes, we might want to ensure activeTab is still valid, which it will be as IDs are constant.

    const activeContent = industries.find(i => i.id === activeTab) || industries[0];

    return (
        <div className="min-h-screen pt-24 pb-12 bg-background flex flex-col relative overflow-hidden">
            {/* Background Atmosphere */}
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[150px] opacity-40"></div>
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[150px] opacity-30"></div>
            </div>

            <div className="container mx-auto px-6 flex-1 flex flex-col relative z-10">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        {t('industries.titlePrefix')} <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-400">{t('industries.titleHighlight')}</span>
                    </h1>
                    <p className="text-text-body text-lg">{t('industries.subtitle')}</p>
                </div>

                {/* Dashboard Layout */}
                <div className="flex flex-col lg:flex-row gap-6 lg:h-[600px]">
                    {/* Left: Navigation Sidebar */}
                    <div className="lg:w-1/3 bg-[#080808] border border-white/10 rounded-3xl overflow-hidden flex flex-col h-auto lg:h-full">
                        <div className="p-4 border-b border-white/5 bg-white/5 flex items-center justify-between">
                            <h3 className="text-xs font-bold text-text-body uppercase tracking-wider">{t('industries.sidebarTitle')}</h3>
                            <ChevronRight className="lg:hidden text-white/20" size={16} />
                        </div>
                        <div className="flex lg:flex-col overflow-x-auto lg:overflow-y-auto p-2 gap-2 lg:gap-0 lg:space-y-1 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:'none'] [scrollbar-width:none]">
                            {industries.map((ind) => (
                                <button
                                    key={ind.id}
                                    onClick={() => setActiveTab(ind.id)}
                                    className={`flex-shrink-0 lg:flex-shrink w-auto lg:w-full text-left px-4 py-3 rounded-xl flex items-center justify-between transition-all duration-200 group border border-transparent ${activeTab === ind.id
                                        ? 'bg-primary/10 text-white shadow-lg shadow-black/20 border-primary/20'
                                        : 'text-text-body hover:bg-white/5 hover:text-white'
                                        }`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded-lg transition-colors ${activeTab === ind.id ? 'bg-primary text-white' : 'bg-white/5 text-white/50 group-hover:bg-white/10 group-hover:text-white'
                                            }`}>
                                            {React.cloneElement(ind.icon, { size: 18 })}
                                        </div>
                                        <span className="font-medium text-sm whitespace-nowrap lg:whitespace-normal">{ind.title.split('&')[0]}</span>
                                    </div>
                                    {activeTab === ind.id && <ChevronRight size={16} className="text-primary hidden lg:block" />}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Right: Active Content Panel */}
                    <div className="lg:w-2/3 relative perspective-[1000px] group">
                        <AnimatePresence mode="wait">
                            <motion.div
                                key={activeTab}
                                initial={{ opacity: 0, x: 20, scale: 0.98 }}
                                animate={{ opacity: 1, x: 0, scale: 1 }}
                                exit={{ opacity: 0, x: -20, scale: 0.98 }}
                                transition={{ duration: 0.3, ease: "easeOut" }}
                                className="relative lg:absolute lg:inset-0 bg-[#0A0A0A] border border-white/10 rounded-3xl p-6 md:p-12 flex flex-col justify-between shadow-2xl min-h-[500px] lg:min-h-0"
                            >
                                {/* Header */}
                                <div>
                                    <div className="flex items-start justify-between mb-6">
                                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-xs font-bold uppercase tracking-wider">
                                            {activeContent.id.replace('-', ' ')}
                                        </div>
                                        <div className="bg-white/5 px-4 py-2 rounded-lg border border-white/5">
                                            <span className="text-xs text-text-body block">{t('industries.metricLabel')}</span>
                                            <span className="text-lg font-bold text-white">{activeContent.stat}</span>
                                        </div>
                                    </div>

                                    <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">{activeContent.tagline}</h2>
                                    <p className="text-xl text-text-body leading-relaxed max-w-2xl">
                                        {activeContent.content}
                                    </p>
                                </div>

                                {/* Features Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                                    {activeContent.features.map((feat, i) => (
                                        <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/5 hover:border-white/10 transition-colors">
                                            <CheckCircle2 size={18} className="text-green-500" />
                                            <span className="text-sm font-medium text-white/90">{feat}</span>
                                        </div>
                                    ))}
                                </div>

                                {/* CTA */}
                                <div className="mt-8 flex items-center justify-end border-t border-white/10 pt-6">
                                    <a href="/contact" className="group inline-flex items-center gap-2 text-primary font-bold hover:text-white transition-colors">
                                        {t('industries.deployCta')} <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                                    </a>
                                </div>

                                {/* Decorative Glow */}
                                <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary/10 rounded-full blur-[80px] pointer-events-none"></div>
                            </motion.div>
                        </AnimatePresence>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Industries;
