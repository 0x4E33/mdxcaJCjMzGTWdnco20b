import React from 'react';
import LegalLayout from '../components/LegalLayout';
import { useTranslation } from 'react-i18next';

const Privacy = () => {
    const { t } = useTranslation();

    return (
        <LegalLayout title={t('privacy.title')}>
            <p className="mb-6 leading-relaxed">
                {t('privacy.preamble')}
            </p>
            <p className="mb-8 leading-relaxed">
                {t('privacy.contact')} <a href="mailto:official@conapay.global">official@conapay.global</a>
            </p>

            <h3>{t('privacy.sections.collect.title')}</h3>
            <p className="mb-6">{t('privacy.sections.collect.intro')}</p>

            <h4>{t('privacy.sections.collect.pii.title')}</h4>
            <p className="mb-4">{t('privacy.sections.collect.pii.content')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.collect.pii.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.collect.financial.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.collect.financial.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.collect.technical.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.collect.technical.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.collect.geo.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.collect.geo.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.collect.service.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.collect.service.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h3>{t('privacy.sections.use.title')}</h3>
            <p className="mb-6">{t('privacy.sections.use.intro')}</p>

            <h4>{t('privacy.sections.use.compliance.title')}</h4>
            <p className="mb-4">{t('privacy.sections.use.compliance.content')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.use.compliance.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>

            <h4>{t('privacy.sections.use.improve.title')}</h4>
            <p className="mb-4">{t('privacy.sections.use.improve.content')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.use.improve.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.use.fraud.title')}</h4>
            <p className="mb-4">{t('privacy.sections.use.fraud.content')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.use.fraud.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.use.marketing.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.use.marketing.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h3>{t('privacy.sections.share.title')}</h3>
            <p className="mb-6">{t('privacy.sections.share.intro')}</p>

            <h4>{t('privacy.sections.share.legal.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.share.legal.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>

            <h4>{t('privacy.sections.share.thirdParty.title')}</h4>
            <p className="mb-4">{t('privacy.sections.share.thirdParty.content')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.share.thirdParty.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.share.fraudShare.title')}</h4>
            <p className="mb-8 leading-relaxed">{t('privacy.sections.share.fraudShare.content')}</p>

            <h3>{t('privacy.sections.storage.title')}</h3>

            <h4>{t('privacy.sections.storage.security.title')}</h4>
            <p className="mb-4">{t('privacy.sections.storage.security.content')}</p>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.storage.security.list', { returnObjects: true }).map((item, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: item }}></li>
                ))}
            </ul>

            <h4>{t('privacy.sections.storage.retention.title')}</h4>
            <ul className="list-disc pl-6 mb-8 space-y-2">
                {t('privacy.sections.storage.retention.list', { returnObjects: true }).map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>

            <h3>{t('privacy.sections.rights.title')}</h3>
            <h4>{t('privacy.sections.rights.access.title')}</h4>
            <p className="mb-6">{t('privacy.sections.rights.access.content')}</p>

            <h4>{t('privacy.sections.rights.rect.title')}</h4>
            <p className="mb-6">{t('privacy.sections.rights.rect.content')}</p>

            <h4>{t('privacy.sections.rights.erasure.title')}</h4>
            <p className="mb-6">{t('privacy.sections.rights.erasure.content')}</p>

            <h4>{t('privacy.sections.rights.object.title')}</h4>
            <p className="mb-6">{t('privacy.sections.rights.object.content')}</p>

            <h4>{t('privacy.sections.rights.portability.title')}</h4>
            <p className="mb-8">{t('privacy.sections.rights.portability.content')}</p>

            <h3>{t('privacy.sections.children.title')}</h3>
            <p className="mb-8 leading-relaxed">{t('privacy.sections.children.content')}</p>

            <h3>{t('privacy.sections.international.title')}</h3>
            <p className="mb-8 leading-relaxed">{t('privacy.sections.international.content')}</p>

            <h3>{t('privacy.sections.changes.title')}</h3>
            <p className="mb-8 leading-relaxed">{t('privacy.sections.changes.content')}</p>

            <h3>{t('privacy.sections.contact.title')}</h3>
            <p className="mb-8 leading-relaxed">
                {t('privacy.sections.contact.content')} <a href="mailto:official@conapay.global">official@conapay.global</a>
            </p>
        </LegalLayout>
    );
};

export default Privacy;
