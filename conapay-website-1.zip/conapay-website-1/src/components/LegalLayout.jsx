import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, FileText, Cookie, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const LegalLayout = ({ children, title, lastUpdated }) => {
    const { pathname } = useLocation();

    const links = [
        { path: '/terms', label: 'Terms of Service', icon: <FileText size={18} /> },
        { path: '/privacy', label: 'Data Protection', icon: <Shield size={18} /> },
        { path: '/cookies', label: 'Tracking Preferences', icon: <Cookie size={18} /> },
    ];

    return (
        <div className="min-h-screen pt-32 pb-24 bg-background relative overflow-hidden">
            {/* Background Texture */}
            <div className="fixed inset-0 pointer-events-none opacity-20">
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="flex flex-col lg:flex-row gap-12">
                    {/* Sidebar Navigation */}
                    <div className="lg:w-1/4">
                        <div className="sticky top-32">
                            <h3 className="text-xs font-bold text-text-body uppercase tracking-wider mb-6 pl-4">Legal Center</h3>
                            <nav className="space-y-1">
                                {links.map((link) => (
                                    <Link
                                        key={link.path}
                                        to={link.path}
                                        className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group ${pathname === link.path
                                            ? 'bg-white/10 text-white shadow-lg border border-white/10'
                                            : 'text-text-body hover:bg-white/5 hover:text-white border border-transparent'
                                            }`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <span className={pathname === link.path ? 'text-primary' : 'text-text-body group-hover:text-white'}>
                                                {link.icon}
                                            </span>
                                            <span className="font-medium text-sm">{link.label}</span>
                                        </div>
                                        {pathname === link.path && <ChevronRight size={14} className="text-primary" />}
                                    </Link>
                                ))}
                            </nav>
                        </div>
                    </div>

                    {/* Content Area */}
                    <div className="lg:w-3/4">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="bg-[#080808] border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden"
                        >
                            {/* Top Glow */}
                            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>

                            <div className="mb-12 border-b border-white/5 pb-8">
                                <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">{title}</h1>
                                <p className="text-text-body">Last Updated: <span className="text-white">{lastUpdated || 'April 11, 2025'}</span></p>
                            </div>

                            <div className="prose prose-invert prose-lg max-w-none prose-headings:font-bold prose-headings:text-white prose-p:text-text-body prose-a:text-primary hover:prose-a:text-primary-hover prose-li:text-text-body prose-strong:text-white">
                                {children}
                            </div>
                        </motion.div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LegalLayout;
