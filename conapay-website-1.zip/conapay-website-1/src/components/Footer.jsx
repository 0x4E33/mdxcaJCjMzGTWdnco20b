import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import logo from '../assets/logo.png';

const Footer = () => {
    const { t } = useTranslation();

    return (
        <footer className="relative z-10 bg-[#050505] border-t border-white/5 pt-32 pb-16">
            <div className="container mx-auto px-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-24">
                    <div className="lg:col-span-2">
                        <Link to="/" className="flex items-center gap-2 mb-6">
                            <img src={logo} alt="ConaPay" className="h-20 md:h-40 w-auto object-contain" />
                        </Link>
                        <p className="text-text-body text-base leading-relaxed max-w-sm mb-8">
                            {t('footer.description')}
                        </p>
                    </div>

                    <div>
                        <h4 className="text-white font-bold mb-8">{t('footer.company')}</h4>
                        <ul className="space-y-4 text-text-body">
                            <li><Link to="/about" className="hover:text-primary transition-colors">{t('footer.about')}</Link></li>
                            <li><Link to="/roadmap" className="hover:text-primary transition-colors">{t('footer.roadmap')}</Link></li>
                            <li><Link to="/contact" className="hover:text-primary transition-colors">{t('footer.contact')}</Link></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-white font-bold mb-8">{t('footer.compliance')}</h4>
                        <ul className="space-y-4 text-text-body">
                            <li><Link to="/terms" className="hover:text-primary transition-colors">{t('footer.terms')}</Link></li>
                            <li><Link to="/privacy" className="hover:text-primary transition-colors">{t('footer.privacy')}</Link></li>
                            <li><Link to="/cookies" className="hover:text-primary transition-colors">{t('footer.cookies')}</Link></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-white font-bold mb-8">{t('footer.resources')}</h4>
                        <ul className="space-y-4 text-text-body">
                            <li><Link to="/developers" className="hover:text-primary transition-colors">{t('footer.api')}</Link></li>
                        </ul>
                    </div>
                </div>

                <div className="pt-8 border-t border-white/5 flex flex-col items-center justify-center text-sm text-text-body">
                    <p>{t('footer.copyright')}</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
