import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, ArrowRight, Shield, Globe, Zap, CreditCard, Building, ShoppingBag, Gamepad2, Home, Plane, Heart, Stethoscope, Lightbulb, Truck, GraduationCap, Banknote, Radio } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next'; // Import useTranslation
import logo from '../assets/logo.png';

const Navbar = () => {
    const { t, i18n } = useTranslation(); // Use hook
    const [scrolled, setScrolled] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [mobileLangOpen, setMobileLangOpen] = useState(false);
    const [hoveredLink, setHoveredLink] = useState(null);
    const { pathname } = useLocation();

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        setMobileMenuOpen(false);
        setHoveredLink(null);
    }, [pathname]);

    const changeLanguage = (lng) => {
        i18n.changeLanguage(lng);
        setMobileLangOpen(false);
        setMobileMenuOpen(false);
    };

    const currentLanguageLabel = i18n.language === 'zh' ? '简体中文' : 'English';

    const solutionsMenu = {
        industries: [
            { name: t('nav.solutionsMenu.gaming'), icon: <Gamepad2 size={16} />, id: 'gaming' },
            { name: t('nav.solutionsMenu.ecommerce'), icon: <ShoppingBag size={16} />, id: 'e-commerce' },
            { name: t('nav.solutionsMenu.livestreaming'), icon: <Radio size={16} />, id: 'live-streaming' },
            { name: t('nav.solutionsMenu.realestate'), icon: <Home size={16} />, id: 'real-estate' },
            { name: t('nav.solutionsMenu.travel'), icon: <Plane size={16} />, id: 'travel' },
            { name: t('nav.solutionsMenu.healthcare'), icon: <Stethoscope size={16} />, id: 'healthcare' },
            { name: t('nav.solutionsMenu.energy'), icon: <Lightbulb size={16} />, id: 'energy' },
            { name: t('nav.solutionsMenu.supplychain'), icon: <Truck size={16} />, id: 'supply-chain' },
            { name: t('nav.solutionsMenu.education'), icon: <GraduationCap size={16} />, id: 'education' },
            { name: t('nav.solutionsMenu.globalpayroll'), icon: <Banknote size={16} />, id: 'global-payroll' },
        ],
        capabilities: [
            { name: t('nav.solutionsMenu.acquiring'), icon: <Globe size={16} />, desc: t('nav.solutionsMenu.acquiringDesc'), id: 'acquiring' },
            { name: t('nav.solutionsMenu.transfer'), icon: <Zap size={16} />, desc: t('nav.solutionsMenu.transferDesc'), id: 'transfer' },
            { name: t('nav.solutionsMenu.settlement'), icon: <Banknote size={16} />, desc: t('nav.solutionsMenu.settlementDesc'), id: 'settlement' },
            { name: t('nav.solutionsMenu.security'), icon: <Shield size={16} />, desc: t('nav.solutionsMenu.securityDesc'), id: 'security' },
        ]
    };

    return (
        <nav
            onMouseLeave={() => setHoveredLink(null)}
            className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ease-in-out border-b ${scrolled || hoveredLink ? 'bg-[#050505]/95 backdrop-blur-md border-white/10 shadow-2xl' : 'bg-transparent border-transparent'
                }`}
        >
            <div className="container mx-auto px-6 h-24 flex items-center justify-between">
                {/* Logo */}
                <Link to="/" className="flex items-center gap-2">
                    <img src={logo} alt="ConaPay" className="h-16 md:h-24 w-auto object-contain" />
                </Link>

                {/* Desktop Nav */}
                <div className="hidden md:flex items-center gap-8 h-full">
                    <Link to="/network" className="text-base font-medium text-text-body hover:text-white transition-colors h-full flex items-center">
                        {t('nav.globalCoverage')}
                    </Link>

                    {/* Solutions Mega Menu Trigger */}
                    <div
                        className="relative h-full flex items-center"
                        onMouseEnter={() => setHoveredLink('solutions')}
                    >
                        <button className={`text-base font-medium flex items-center gap-1 transition-colors ${hoveredLink === 'solutions' ? 'text-white' : 'text-text-body hover:text-white'}`}>
                            {t('nav.solutions')} <ChevronDown size={14} className={`transition-transform duration-300 ${hoveredLink === 'solutions' ? 'rotate-180' : ''}`} />
                        </button>
                    </div>

                    <div
                        className="relative h-full flex items-center"
                        onMouseEnter={() => setHoveredLink('company')}
                    >
                        <button className={`text-base font-medium flex items-center gap-1 transition-colors ${hoveredLink === 'company' ? 'text-white' : 'text-text-body hover:text-white'}`}>
                            {t('nav.company')} <ChevronDown size={14} className={`transition-transform duration-300 ${hoveredLink === 'company' ? 'rotate-180' : ''}`} />
                        </button>
                    </div>

                    <div
                        className="relative h-full flex items-center"
                        onMouseEnter={() => setHoveredLink('resources')}
                    >
                        <button className={`text-base font-medium flex items-center gap-1 transition-colors ${hoveredLink === 'resources' ? 'text-white' : 'text-text-body hover:text-white'}`}>
                            {t('nav.resources')} <ChevronDown size={14} className={`transition-transform duration-300 ${hoveredLink === 'resources' ? 'rotate-180' : ''}`} />
                        </button>
                    </div>
                </div>

                {/* Actions */}
                <div className="hidden md:flex items-center gap-6">
                    <div className="relative group">
                        <button className="flex items-center gap-2 text-sm font-medium text-text-body hover:text-white transition-colors">
                            <Globe size={16} />
                            <span>{currentLanguageLabel}</span>
                            <ChevronDown size={12} className="group-hover:rotate-180 transition-transform" />
                        </button>
                        {/* Language Dropdown */}
                        <div className="absolute top-full right-0 pt-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                            <div className="bg-[#050505] border border-white/10 rounded-lg p-2 w-32 shadow-xl flex flex-col gap-1">
                                <button
                                    onClick={() => changeLanguage('en')}
                                    className={`text-left px-3 py-2 text-sm rounded-md transition-colors ${i18n.language !== 'zh' ? 'text-white bg-white/5' : 'text-text-body hover:text-white hover:bg-white/5'}`}
                                >
                                    English
                                </button>
                                <button
                                    onClick={() => changeLanguage('zh')}
                                    className={`text-left px-3 py-2 text-sm rounded-md transition-colors ${i18n.language === 'zh' ? 'text-white bg-white/5' : 'text-text-body hover:text-white hover:bg-white/5'}`}
                                >
                                    简体中文
                                </button>
                            </div>
                        </div>
                    </div>

                    <a
                        href="https://conapay.global"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-5 py-2.5 text-sm font-bold text-white bg-white/5 border border-white/10 rounded-full hover:bg-white/10 transition-all duration-300 backdrop-blur-sm"
                    >
                        {t('nav.portal')}
                    </a>

                    <Link
                        to="/contact"
                        className="group relative px-6 py-3 bg-primary/10 text-primary text-sm font-bold rounded-full overflow-hidden border border-primary/20 hover:border-primary/50 transition-all duration-300 shadow-[0_0_15px_rgba(255,153,0,0.1)] hover:shadow-[0_0_25px_rgba(255,153,0,0.3)]"
                    >
                        <div className="absolute inset-0 bg-primary/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                        <span className="relative flex items-center gap-2">{t('nav.contact')} <ArrowRight size={14} /></span>
                    </Link>
                </div>

                {/* Mobile Menu Toggle */}
                <button
                    className="md:hidden text-white p-2"
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                >
                    {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </div>

            {/* Mega Menu Dropdown */}
            <AnimatePresence>
                {hoveredLink === 'solutions' && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 right-0 bg-[#050505]/95 backdrop-blur-xl border-b border-white/10 shadow-2xl py-12"
                        onMouseEnter={() => setHoveredLink('solutions')}
                        onMouseLeave={() => setHoveredLink(null)}
                    >
                        <div className="container mx-auto px-6 grid grid-cols-12 gap-12">
                            {/* By Industry */}
                            <div className="col-span-6 border-r border-white/5 pr-8">
                                <h4 className="text-xs font-semibold text-text-body uppercase tracking-wider mb-6">{t('nav.solutionsMenu.byIndustry')}</h4>
                                <div className="grid grid-cols-2 gap-y-4 gap-x-8">
                                    {solutionsMenu.industries.map((item) => (
                                        <Link
                                            key={item.id}
                                            to={`/industries#${item.id}`}
                                            className="flex items-center gap-3 group"
                                        >
                                            <div className="text-text-body group-hover:text-primary transition-colors">
                                                {item.icon}
                                            </div>
                                            <span className="text-sm font-medium text-white group-hover:text-primary transition-colors">{item.name}</span>
                                        </Link>
                                    ))}
                                </div>
                            </div>

                            {/* Capabilities */}
                            <div className="col-span-6 pl-4">
                                <h4 className="text-xs font-semibold text-text-body uppercase tracking-wider mb-6">{t('nav.solutionsMenu.capabilities')}</h4>
                                <div className="grid grid-cols-2 gap-6">
                                    {solutionsMenu.capabilities.map((item) => (
                                        <Link
                                            key={item.id}
                                            to={`/capabilities#${item.id}`}
                                            className="group p-4 rounded-xl hover:bg-white/5 transition-colors cursor-pointer border border-transparent hover:border-white/5 block"
                                        >
                                            <div className="flex items-center gap-3 mb-2">
                                                <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                                                    {item.icon}
                                                </div>
                                                <h5 className="font-semibold text-white">{item.name}</h5>
                                            </div>
                                            <p className="text-sm text-text-body pl-[44px]">{item.desc}</p>
                                        </Link>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
                {/* Company Dropdown */}
                {hoveredLink === 'company' && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 right-0 bg-[#050505]/95 backdrop-blur-xl border-b border-white/10 shadow-2xl py-8"
                        onMouseEnter={() => setHoveredLink('company')}
                        onMouseLeave={() => setHoveredLink(null)}
                    >
                        <div className="container mx-auto px-6">
                            <div className="max-w-md">
                                <Link to="/about" className="block p-4 rounded-lg hover:bg-white/5 transition-colors">
                                    <h5 className="font-semibold text-white mb-1">{t('nav.companyMenu.about')}</h5>
                                    <p className="text-sm text-text-body">{t('nav.companyMenu.aboutDesc')}</p>
                                </Link>
                                <Link to="/roadmap" className="block p-4 rounded-lg hover:bg-white/5 transition-colors">
                                    <h5 className="font-semibold text-white mb-1">{t('nav.companyMenu.roadmap')}</h5>
                                    <p className="text-sm text-text-body">{t('nav.companyMenu.roadmapDesc')}</p>
                                </Link>
                                <Link to="/contact" className="block p-4 rounded-lg hover:bg-white/5 transition-colors">
                                    <h5 className="font-semibold text-white mb-1">{t('nav.companyMenu.contact')}</h5>
                                    <p className="text-sm text-text-body">{t('nav.companyMenu.contactDesc')}</p>
                                </Link>
                            </div>
                        </div>
                    </motion.div>
                )}
                {/* Resources Dropdown */}
                {hoveredLink === 'resources' && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 right-0 bg-[#050505]/95 backdrop-blur-xl border-b border-white/10 shadow-2xl py-8"
                        onMouseEnter={() => setHoveredLink('resources')}
                        onMouseLeave={() => setHoveredLink(null)}
                    >
                        <div className="container mx-auto px-6">
                            <div className="max-w-md">
                                <Link to="/developers" className="block p-4 rounded-lg hover:bg-white/5 transition-colors">
                                    <h5 className="font-semibold text-white mb-1 flex items-center gap-2">{t('nav.resourcesMenu.api')} <div className="text-[10px] px-1.5 py-0.5 rounded bg-primary/20 text-primary border border-primary/30">v2.1</div></h5>
                                    <p className="text-sm text-text-body">{t('nav.resourcesMenu.apiDesc')}</p>
                                </Link>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Mobile Menu Overlay */}
            <AnimatePresence>
                {mobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="absolute top-full left-0 right-0 bg-[#050505] border-b border-border p-6 md:hidden flex flex-col gap-6 shadow-2xl z-40 max-h-[80vh] overflow-y-auto"
                    >
                        <div className="flex flex-col gap-4">
                            <Link to="/network" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-text-body hover:text-white">{t('nav.globalCoverage')}</Link>
                            <Link to="/industries" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-text-body hover:text-white">{t('nav.solutions')}</Link>

                            {/* Company Group */}
                            <div className="flex flex-col gap-3 py-2">
                                <span className="text-xs font-bold text-white/40 uppercase tracking-wider">{t('nav.company')}</span>
                                <Link to="/about" onClick={() => setMobileMenuOpen(false)} className="pl-4 text-lg font-medium text-text-body hover:text-white border-l border-white/10 hover:border-primary transition-colors">{t('nav.companyMenu.about')}</Link>
                                <Link to="/roadmap" onClick={() => setMobileMenuOpen(false)} className="pl-4 text-lg font-medium text-text-body hover:text-white border-l border-white/10 hover:border-primary transition-colors">{t('nav.companyMenu.roadmap')}</Link>
                                <Link to="/contact" onClick={() => setMobileMenuOpen(false)} className="pl-4 text-lg font-medium text-text-body hover:text-white border-l border-white/10 hover:border-primary transition-colors">{t('nav.companyMenu.contact')}</Link>
                            </div>

                            <Link to="/developers" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-text-body hover:text-white">{t('nav.resources')}</Link>
                        </div>
                        <div className="h-px bg-white/10 w-full"></div>
                        <div className="flex flex-col gap-4">
                            {/* Mobile Language Switcher */}
                            <div className="relative">
                                <button className="flex items-center gap-2 text-sm text-text-body hover:text-white" onClick={() => setMobileLangOpen(!mobileLangOpen)}>
                                    <Globe size={16} />
                                    <span>{currentLanguageLabel}</span>
                                    <ChevronDown size={12} className={`transition-transform duration-200 ${mobileLangOpen ? 'rotate-180' : ''}`} />
                                </button>
                                <AnimatePresence>
                                    {mobileLangOpen && (
                                        <motion.div
                                            initial={{ opacity: 0, height: 0 }}
                                            animate={{ opacity: 1, height: 'auto' }}
                                            exit={{ opacity: 0, height: 0 }}
                                            className="overflow-hidden pl-7 pt-2 flex flex-col gap-2"
                                        >
                                            <button
                                                onClick={() => changeLanguage('en')}
                                                className={`text-left text-sm font-medium ${i18n.language !== 'zh' ? 'text-primary' : 'text-text-body hover:text-white transition-colors'}`}
                                            >
                                                English
                                            </button>
                                            <button
                                                onClick={() => changeLanguage('zh')}
                                                className={`text-left text-sm font-medium ${i18n.language === 'zh' ? 'text-primary' : 'text-text-body hover:text-white transition-colors'}`}
                                            >
                                                简体中文
                                            </button>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>

                            <a
                                href="https://conapay.global"
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={() => setMobileMenuOpen(false)}
                                className="w-full bg-white/5 border border-white/10 text-white px-5 py-3 rounded-md text-center text-sm font-semibold hover:bg-white/10 transition-colors"
                            >
                                {t('nav.portal')}
                            </a>

                            <Link
                                to="/contact"
                                onClick={() => setMobileMenuOpen(false)}
                                className="bg-primary text-white px-5 py-3 rounded-md text-center text-sm font-semibold"
                            >
                                {t('nav.contact')}
                            </Link>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </nav >
    );
};

export default Navbar;
