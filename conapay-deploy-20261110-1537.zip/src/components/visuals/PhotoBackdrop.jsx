import { useEffect, useRef, useState } from 'react';
import { m, useReducedMotion, useScroll, useTransform } from 'framer-motion';

/**
 * Real photography / footage behind a page header.
 * Graded dark so type stays readable; fades into the page at the bottom; drifts a little slower
 * than the scroll (desktop) so the header has depth without anything "animating".
 *
 * Video plays only while on screen, never for reduced-motion or Save-Data visitors (poster instead).
 *
 * side="right": the picture fills the right ~60% and dissolves toward the text column on the left,
 * so the subject stays visible instead of being darkened behind the copy.
 */
export const PhotoBackdrop = ({ src, video, poster, height = 640, position = 'center', strength = 0.62, side = 'full', className = '' }) => {
    const ref = useRef(null);
    const videoRef = useRef(null);
    const reduced = useReducedMotion();
    const [playVideo, setPlayVideo] = useState(false);
    const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
    const y = useTransform(scrollYProgress, [0, 1], ['0%', '18%']);

    useEffect(() => {
        if (!video || reduced || navigator.connection?.saveData) return undefined;
        const el = ref.current;
        const io = new IntersectionObserver(([e]) => {
            if (e.isIntersecting) setPlayVideo(true); // footage is only fetched once the header is on screen
            const v = videoRef.current;
            if (!v) return;
            if (e.isIntersecting) v.play().catch(() => {});
            else v.pause();
        });
        io.observe(el);
        return () => io.disconnect();
    }, [video, reduced]);

    const still = poster || src;
    return (
        <div ref={ref} className={`pointer-events-none absolute inset-x-0 top-0 overflow-hidden ${className}`} style={{ height }} aria-hidden="true">
            <m.div className={side === 'right'
                ? 'absolute inset-y-0 right-0 w-full [mask-image:linear-gradient(90deg,transparent_0%,rgba(0,0,0,0.25)_28%,black_58%)] lg:w-[68%]'
                : 'absolute inset-0'} style={reduced ? undefined : { y }}>
                {playVideo ? (
                    <video ref={videoRef} className="h-full w-full object-cover" poster={still} muted loop playsInline autoPlay preload="auto"
                        style={{ objectPosition: position }}>
                        {video.webm && <source src={video.webm} type="video/webm" />}
                        <source src={video.mp4} type="video/mp4" />
                    </video>
                ) : still ? (
                    <img src={still} alt="" decoding="async" fetchPriority="high" className="h-full w-full object-cover" style={{ objectPosition: position }} />
                ) : null}
            </m.div>
            {/* grade: dark base, warm lift from the brand colour, vignette, fade into the page */}
            <div className="absolute inset-0 bg-background" style={{ opacity: strength }} />
            {side === 'right' && <div className="absolute inset-0 bg-background/55 lg:hidden" />}
            <div className="absolute inset-0 bg-[linear-gradient(115deg,rgba(255,120,20,0.10),transparent_45%)] mix-blend-overlay" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_70%_at_50%_40%,transparent_30%,rgba(10,9,8,0.65)_100%)]" />
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-background via-background/70 to-transparent" />
        </div>
    );
};

export default PhotoBackdrop;
