import { useState } from 'react';
import { m as motion } from 'framer-motion';
import { Reveal } from '../components/motion/Reveal';
import { Mail, Send, ArrowRight, Copy, Check, ShieldCheck, Clock, UserRound, Receipt } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import PhotoBackdrop from '../components/visuals/PhotoBackdrop';
import { heroMedia } from '../data/media';

// An account manager on a video call in the evening (footage; its poster for reduced-motion / Save-Data).
const HERO = heroMedia('contact');
import TrustMarquee from './Home/TrustMarquee';

// Official contact channels.
const EMAIL = 'official@conapay.io';
const TG_USERNAME = 'ConaPayRicky';
const TELEGRAM = `https://t.me/${TG_USERNAME}`;

const CopyButton = ({ value }) => {
    const { t } = useTranslation();
    const [copied, setCopied] = useState(false);
    const copy = async () => {
        try { await navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch { /* clipboard unavailable */ }
    };
    return (
        <button type="button" onClick={copy} aria-label={`${t('contact.channels.copy')} ${value}`}
            className={`inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border px-3 text-xs font-semibold transition-colors ${copied ? 'border-payout/40 text-payout' : 'border-white/10 text-text-body hover:border-white/25 hover:text-white'}`}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? t('contact.channels.copied') : t('contact.channels.copy')}
        </button>
    );
};

/** A contact channel: who, the exact handle (with copy right beside it), one clear action. */
const ChannelCard = ({ icon: Icon, accent, label, desc, value, href, action, external, delay }) => (
    <motion.div
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay, ease: [0.16, 1, 0.3, 1] }}
        className="group relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-surface/85 p-7 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.9)] backdrop-blur-xl transition-colors hover:border-white/15 md:p-9"
    >
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px" style={{ background: `linear-gradient(90deg, transparent, ${accent}99, transparent)` }} />

        <div className="relative flex items-center gap-4">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl text-white shadow-lg" style={{ background: accent, boxShadow: `0 12px 30px -10px ${accent}` }}>
                <Icon size={26} />
            </span>
            <div>
                <p className="text-lg font-semibold text-white">{label}</p>
                <p className="text-sm text-text-muted">{desc}</p>
            </div>
        </div>

        <div className="relative mt-8 flex items-center gap-3 rounded-2xl border border-white/[0.08] bg-background/60 py-3 pl-4 pr-3 sm:pl-5">
            <span className="min-w-0 flex-1 break-all font-mono text-[15px] font-bold text-white sm:text-lg md:text-xl">{value}</span>
            <CopyButton value={value} />
        </div>

        <a href={href} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
            className="relative mt-5 flex w-full items-center justify-center gap-2 rounded-full px-6 py-4 text-base font-semibold text-white transition-all hover:-translate-y-px hover:brightness-110"
            style={{ background: accent, boxShadow: `0 16px 36px -14px ${accent}` }}>
            <Icon size={18} /> {action} <ArrowRight size={18} />
        </a>
    </motion.div>
);

const Contact = () => {
    const { t } = useTranslation();
    const steps = t('contact.next.steps', { returnObjects: true });
    const trust = t('contact.trust', { returnObjects: true });
    const TRUST_ICONS = [Clock, UserRound, Receipt];

    return (
        <div className="relative -mt-20 overflow-hidden pb-8 pt-20">
            <PhotoBackdrop {...HERO} height={860} strength={0.6} />

            {/* Heading */}
            <section className="container relative mx-auto px-5 pt-14 text-center md:pt-20">
                <span style={{ animationDelay: '0ms' }} className="eyebrow animate-rise">{t('contact.eyebrow')}</span>
                <h1 style={{ animationDelay: '60ms' }} className="animate-rise mx-auto mt-6 max-w-3xl text-4xl font-bold leading-[1.06] text-white md:text-7xl">
                    {t('contact.title')} <span className="text-ember">{t('contact.titleHighlight')}</span>
                </h1>
                <p style={{ animationDelay: '120ms' }} className="animate-rise mx-auto mt-6 max-w-2xl text-lg text-text-body">{t('contact.subtitle')}</p>

                {/* Trust signals */}
                <ul style={{ animationDelay: '180ms' }} className="animate-rise mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-text-heading/90">
                    {(Array.isArray(trust) ? trust : []).map((item, i) => {
                        const Icon = TRUST_ICONS[i] || Clock;
                        return <li key={item} className="inline-flex items-center gap-2"><Icon size={16} className="text-primary" /> {item}</li>;
                    })}
                </ul>
            </section>

            {/* Channels */}
            <section className="container relative mx-auto mt-14 max-w-5xl px-5">
                <div className="grid gap-5 md:grid-cols-2">
                    <ChannelCard icon={Send} accent="#229ED9" delay={0.2}
                        label={t('contact.channels.telegram.label')} desc={t('contact.channels.telegram.desc')}
                        value={`@${TG_USERNAME}`} href={TELEGRAM} action={t('contact.channels.telegram.action')} external />
                    <ChannelCard icon={Mail} accent="#F08A0A" delay={0.3}
                        label={t('contact.channels.email.label')} desc={t('contact.channels.email.desc')}
                        value={EMAIL} href={`mailto:${EMAIL}`} action={t('contact.channels.email.action')} />
                </div>
                <p className="mx-auto mt-6 flex max-w-3xl items-start justify-center gap-2 text-center text-xs leading-relaxed text-text-muted">
                    <ShieldCheck size={14} className="mt-0.5 shrink-0 text-payout" /> {t('contact.safety')}
                </p>
            </section>

            {/* What happens next */}
            <section className="container relative mx-auto mt-24 max-w-5xl px-5">
                <h2 className="text-center font-sans text-sm font-semibold uppercase tracking-[0.16em] text-text-muted">{t('contact.next.title')}</h2>
                <ol className="relative mt-10 grid gap-8 md:grid-cols-3 md:gap-6">
                    <span className="absolute left-[16.6%] right-[16.6%] top-5 hidden h-px bg-gradient-to-r from-primary/60 via-white/10 to-white/5 md:block" aria-hidden="true" />
                    {(Array.isArray(steps) ? steps : []).map((s, i) => (
                        <Reveal as="li" key={s.title} index={i}
                            className="relative flex gap-4 md:flex-col md:items-center md:text-center">
                            <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-primary/50 bg-background font-mono text-sm font-bold text-primary shadow-[0_0_0_4px_rgba(255,153,0,0.08)]">{i + 1}</span>
                            <div>
                                <p className="font-semibold text-white md:mt-2">{s.title}</p>
                                <p className="mt-1 text-sm leading-relaxed text-text-body md:mx-auto md:max-w-[240px]">{s.desc}</p>
                            </div>
                        </Reveal>
                    ))}
                </ol>
            </section>

            {/* Partners */}
            <div className="mt-24">
                <TrustMarquee className="border-t border-white/[0.06] py-12" />
            </div>
        </div>
    );
};

export default Contact;
