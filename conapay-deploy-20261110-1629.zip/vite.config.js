import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import viteCompression from 'vite-plugin-compression';
import { ViteImageOptimizer } from 'vite-plugin-image-optimizer';

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    viteCompression({
        algorithm: 'gzip',
        ext: '.gz',
    }),
    viteCompression({
        algorithm: 'brotliCompress',
        ext: '.br',
    }),
    ViteImageOptimizer({
        png: {
            quality: 80,
        },
        jpeg: {
            quality: 80,
        },
        jpg: {
            quality: 80,
        },
    }),
  ],
})
