#!/bin/bash
# ==========================================
# ConaPay 官网 上传包打包脚本（在本地 Mac/Linux 执行）
#
# 用法：./pack.sh
# 产物：项目上一级目录下的 conapay-deploy-<时间>.zip，上传到服务器解压后执行 ./deploy.sh
#
# 自动排除：依赖与构建产物、服务器生成的文件、本地备份、竞品代码目录、系统垃圾文件，
# 只保留服务器构建所需的源码与配置，避免上传包动辄几百 MB。
# ==========================================
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

OUT="$(dirname "$PROJECT_DIR")/conapay-deploy-$(date +%Y%m%d-%H%M).zip"

zip -rq "$OUT" . \
    -x "node_modules/*" "dist/*" "dist-ssr/*" "site/*" \
    -x "conf/*" "docker-compose.yml" \
    -x ".backup/*" ".claude/*" ".vite/*" \
    -x "epay-website-code/*" "kaazpay-website-code/*" \
    -x "*.zip" "*.DS_Store" "*.log"

# 打包后自检：构建必需文件都在、没有混入不该上传的目录
for f in package.json package-lock.json deploy.sh index.html vite.config.js scripts/prerender.mjs src/main.jsx; do
    unzip -l "$OUT" "$f" >/dev/null || { echo "✗ 打包缺少 $f"; exit 1; }
done
if unzip -l "$OUT" | grep -qE ' (node_modules|\.backup|epay-website-code|kaazpay-website-code)/'; then
    echo "✗ 打包混入了不该上传的目录，请检查排除规则"; exit 1
fi

echo "✅ 打包完成：$OUT ($(du -h "$OUT" | cut -f1))"
echo "   上传到服务器后：unzip -o $(basename "$OUT") -d <项目目录> && cd <项目目录> && chmod +x deploy.sh && ./deploy.sh"
