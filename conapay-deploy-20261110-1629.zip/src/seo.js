import {
    SITE_URL, MARKETS, REGIONS, COVERAGE_STATS, getMarket, hasPayout,
    marketName, regionName, methodType, methodTypeName,
} from './data/channels';
import en from './locales/en.json';
import zhLocale from './locales/zh.json';

const isZh = (l) => !!l && l.startsWith('zh');

const STATIC = {
    '/': {
        en: [`ConaPay | Local Payment Methods & Payouts in ${COVERAGE_STATS.markets}+ Markets`,
            `Local pay-in and payouts across Africa, Latin America, Asia and Europe: ${COVERAGE_STATS.payinMethods}+ payment methods including M-Pesa, Pix, SPEI, PSE, GCash, QRIS, FPX and mobile money. USDT settlement, D+0 on supported channels.`],
        zh: [`ConaPay | 覆盖 ${COVERAGE_STATS.markets}+ 市场的本地支付代收代付通道`,
            `在非洲、拉美、亚太和欧洲开通本地代收与代付，支持 M-Pesa、Pix、SPEI、PSE、GCash、QRIS、FPX、移动钱包等 ${COVERAGE_STATS.payinMethods}+ 种支付方式。USDT 结算，支持通道 D+0 到账。`],
    },
    '/industries': { en: ['Industry Payment Solutions | ConaPay', 'Local pay-in and payouts for iGaming, e-commerce, live streaming, Web3, AI short dramas and digital content, travel, education and global payroll.'], zh: ['行业支付解决方案 | ConaPay', '为游戏娱乐、跨境电商、直播、Web3、AI 短剧与数字内容、旅游、教育与全球薪酬提供本地代收与代付方案。'] },
    '/capabilities': { en: ['Capabilities: Acquiring, Payout & Settlement | ConaPay', 'Local acquiring, payouts, USDT settlement, smart routing and risk controls in one merchant account.'], zh: ['产品能力：收单、代付与结算 | ConaPay', '本地收单、代付、USDT 结算、合规与智能路由一站式平台。'] },
    '/developers': { en: ['Developers: Integrate in 4 Steps | ConaPay', 'How to integrate ConaPay in 4 steps: open an account, get your API keys, integrate with engineer support and go live.'], zh: ['开发者：4 步完成接入 | ConaPay', 'ConaPay 4 步接入：开通账户、获取 API 密钥、在工程师协助下完成对接、正式上线。'] },
    '/contact': { en: ['Contact Sales | ConaPay', 'Tell us your markets and volumes — we reply within one business day with a channel plan, settlement cycles and pricing.'], zh: ['联系我们 | ConaPay', '告诉我们您的目标市场与交易规模，1 个工作日内为您提供通道方案、结算周期与费率。'] },
    '/roadmap': { en: ['Roadmap | ConaPay', "ConaPay's product timeline, upcoming features and market expansion plans."], zh: ['发展路线 | ConaPay', 'ConaPay 产品规划、新功能及市场拓展计划。'] },
    '/about': { en: ['About ConaPay | Local Payments for Emerging Markets', 'ConaPay connects businesses to local pay-in and payout methods across Africa, the Americas, Asia Pacific and Europe, settled in USDT.'], zh: ['关于 ConaPay | 新兴市场本地支付', 'ConaPay 为企业接入非洲、美洲、亚太与欧洲的本地代收与代付方式，统一以 USDT 结算。'] },
};

const joinList = (arr, zh) => {
    if (zh) return arr.join('、');
    if (arr.length <= 1) return arr.join('');
    return `${arr.slice(0, -1).join(', ')} and ${arr[arr.length - 1]}`;
};

const ALIASES = { 'cote-d-ivoire': ['Ivory Coast'] };
/** "Nigeria Bank Transfer" -> "Bank Transfer" (for titles, where the country is already named). */
const shortMethod = (method, market) => {
    for (const prefix of [market.name.en, ...(ALIASES[market.slug] || [])]) {
        if (method.startsWith(`${prefix} `)) return method.slice(prefix.length + 1);
    }
    return method;
};
const titleMethods = (market, sep) => [...new Set(market.payin.map((m) => shortMethod(m, market)))].slice(0, 3).join(sep);

/** Plain-language facts about one market — reused by the page body, FAQ and JSON-LD. */
export const marketCopy = (market, l) => {
    const zh = isZh(l);
    const name = marketName(market, l);
    const methods = joinList(market.payin, zh);
    const payout = hasPayout(market);
    const types = [...new Set(market.payin.map(methodType))].map((t) => methodTypeName(t, l).toLowerCase());
    const isGlobal = market.region === 'global';
    const networks = joinList(market.networks || [], zh);

    if (zh) {
        return {
            title: isGlobal ? 'USDT 代收代付通道 | ConaPay' : `${name}支付通道：${titleMethods(market, '、')} 代收${payout ? '代付' : ''} | ConaPay`,
            h1: isGlobal ? 'USDT 全球代收与代付' : `${name}本地支付通道`,
            description: isGlobal
                ? `ConaPay 支持 ${networks} 网络的 USDT 代收与代付，面向全球商户，快速开通。`
                : `ConaPay 在${name}支持 ${methods} 代收（${market.currency}）${payout ? '，并支持本地代付' : ''}。快速开通，USDT 结算。`,
            intro: isGlobal
                ? `ConaPay 支持在 ${networks} 网络上进行 USDT 代收与代付，面向全球商户开放，资金以 USDT 结算。`
                : `通过 ConaPay，商户可在${name}使用 ${methods} 向本地用户收款，币种为 ${market.currency}${payout ? '；同时支持向本地账户代付' : '；该市场目前仅开通代收'}。资金以 USDT 结算。`,
            faq: [
                isGlobal
                    ? { q: 'ConaPay 的 USDT 支持哪些网络？', a: `目前支持 ${market.networks.length} 个网络：${networks}。` }
                    : { q: `ConaPay 在${name}支持哪些支付方式？`, a: `目前支持 ${market.payin.length} 种代收方式：${methods}。` },
                { q: `ConaPay 支持${name}代付吗？`, a: payout ? `支持。ConaPay 支持${name}本地代付（${market.currency}）。具体可用的代付方式与限额请联系我们的商务团队。` : `${name}目前仅开通代收，代付正在规划中，如有需求请联系我们。` },
                { q: `如何开通${name}的支付通道？`, a: '提交联系表单后，商务团队会在 1 个工作日内与您对接，开通账户后即可开始接入并上线。' },
            ],
        };
    }
    return {
        title: isGlobal ? 'USDT Payment Gateway: Pay-in & Payout | ConaPay' : `${name} Payment Gateway: ${titleMethods(market, ', ')}${payout ? ' & Payouts' : ''} | ConaPay`,
        h1: isGlobal ? 'Global USDT pay-in & payouts' : `Accept payments in ${name}`,
        description: isGlobal
            ? `Accept and pay out USDT on ${networks} with ConaPay. Available to merchants worldwide, with fast onboarding.`
            : `Accept ${market.currency} payments in ${name} with ${methods}${payout ? ', and send local payouts' : ''}. Fast onboarding and USDT settlement with ConaPay.`,
        intro: isGlobal
            ? `ConaPay supports USDT pay-in and payouts on ${networks}, available to merchants worldwide. Settlement is made in USDT.`
            : `ConaPay lets merchants collect ${market.currency} from customers in ${name} through ${methods} (${joinList(types, false)})${payout ? ', and send payouts to local accounts' : '. Pay-in is available today; payouts are not yet offered in this market'}. Funds are settled in USDT.`,
        faq: [
            isGlobal
                ? { q: 'Which networks does ConaPay support for USDT?', a: `ConaPay supports USDT on ${market.networks.length} networks: ${networks}.` }
                : { q: `Which payment methods does ConaPay support in ${name}?`, a: `ConaPay supports ${market.payin.length} pay-in method${market.payin.length > 1 ? 's' : ''} in ${name}: ${methods}.` },
            { q: `Does ConaPay support payouts in ${name}?`, a: payout ? `Yes. ConaPay supports local ${market.currency} payouts in ${name}. Contact our sales team for available payout rails and limits.` : `Not yet. ${name} is currently pay-in only. Contact us if you need payouts in this market.` },
            { q: `How do I start accepting payments in ${name}?`, a: 'Submit the contact form and our team will reach out within one business day. Once your account is open you can integrate and go live.' },
        ],
    };
};

const ORG = {
    '@type': 'Organization',
    '@id': `${SITE_URL}/#org`,
    name: 'ConaPay',
    url: SITE_URL,
    logo: `${SITE_URL}/icon-512.png`,
    description: 'ConaPay is a payment gateway providing local pay-in (collection) and payout channels across Africa, Latin America, Asia Pacific, Europe and the Middle East, with USDT settlement.',
};

const fill = (str) => str.replace('{{markets}}', COVERAGE_STATS.markets).replace('{{payout}}', COVERAGE_STATS.payoutMarkets);

const homeJsonLd = (l) => [{
    '@context': 'https://schema.org',
    '@graph': [
        ORG,
        {
            '@type': 'FAQPage',
            mainEntity: ['countries', 'payout', 'settlement', 'highrisk', 'conversion', 'liquidity']
                .map((k) => (isZh(l) ? zhLocale : en).home.faq.questions[k])
                .filter(Boolean)
                .map((f) => ({ '@type': 'Question', name: fill(f.q), acceptedAnswer: { '@type': 'Answer', text: fill(f.a) } })),
        },
        { '@type': 'WebSite', '@id': `${SITE_URL}/#website`, url: SITE_URL, name: 'ConaPay', publisher: { '@id': `${SITE_URL}/#org` } },
        {
            '@type': 'Service',
            name: 'ConaPay local payment methods and payouts',
            serviceType: 'Payment gateway',
            provider: { '@id': `${SITE_URL}/#org` },
            areaServed: MARKETS.filter((m) => m.iso && m.iso !== 'eu').map((m) => ({ '@type': 'Country', name: m.name.en })),
            hasOfferCatalog: {
                '@type': 'OfferCatalog',
                name: 'Payment channels by region',
                itemListElement: REGIONS.map((r) => ({
                    '@type': 'OfferCatalog',
                    name: regionName(r.key, l),
                    itemListElement: MARKETS.filter((m) => m.region === r.key).map((m) => ({
                        '@type': 'Offer',
                        url: `${SITE_URL}/payment-methods/${m.slug}`,
                        itemOffered: { '@type': 'Service', name: `${m.name.en} payments: ${m.payin.join(', ')}` },
                    })),
                })),
            },
        },
    ],
}];

const marketJsonLd = (market, l) => {
    const copy = marketCopy(market, l);
    const url = `${SITE_URL}/payment-methods/${market.slug}`;
    return [{
        '@context': 'https://schema.org',
        '@graph': [
            ORG,
            {
                '@type': 'Service',
                name: copy.h1,
                url,
                serviceType: 'Payment gateway',
                provider: { '@id': `${SITE_URL}/#org` },
                ...(market.iso && market.iso !== 'eu' ? { areaServed: { '@type': 'Country', name: market.name.en } } : {}),
                description: copy.description,
                availableChannel: market.payin.map((p) => ({ '@type': 'ServiceChannel', name: p })),
            },
            {
                '@type': 'FAQPage',
                mainEntity: copy.faq.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
            },
            {
                '@type': 'BreadcrumbList',
                itemListElement: [
                    { '@type': 'ListItem', position: 1, name: 'ConaPay', item: `${SITE_URL}/` },
                    { '@type': 'ListItem', position: 2, name: isZh(l) ? '支付通道' : 'Payment coverage', item: `${SITE_URL}/#coverage` },
                    { '@type': 'ListItem', position: 3, name: marketName(market, l), item: url },
                ],
            },
        ],
    }];
};

/** SEO data for a route. Returns { title, description, canonical, jsonLd } */
export const getSeo = (pathname, l = 'en') => {
    const zh = isZh(l);
    const path = pathname.length > 1 ? pathname.replace(/\/+$/, '') : pathname;
    const m = path.match(/^\/payment-methods\/([^/]+)$/);
    if (m) {
        const market = getMarket(m[1]);
        if (market) {
            const copy = marketCopy(market, l);
            return { title: copy.title, description: copy.description, canonical: `${SITE_URL}${path}`, jsonLd: marketJsonLd(market, l) };
        }
    }
    const entry = STATIC[path] || STATIC['/'];
    const [title, description] = entry[zh ? 'zh' : 'en'];
    return {
        title,
        description,
        canonical: `${SITE_URL}${STATIC[path] ? (path === '/' ? '/' : path) : '/'}`,
        jsonLd: path === '/' ? homeJsonLd(l) : [{ '@context': 'https://schema.org', ...ORG }],
    };
};

export const PRERENDER_ROUTES = [
    ...Object.keys(STATIC),
    ...MARKETS.map((m) => `/payment-methods/${m.slug}`),
];

/** Apply SEO data to document.head on the client. */
export const applySeo = (seo) => {
    if (typeof document === 'undefined') return;
    document.title = seo.title;
    const set = (selector, attr, value, create) => {
        let el = document.head.querySelector(selector);
        if (!el && create) { el = create(); document.head.appendChild(el); }
        if (el) el.setAttribute(attr, value);
    };
    const meta = (key, isProp) => () => { const e = document.createElement('meta'); e.setAttribute(isProp ? 'property' : 'name', key); return e; };
    set('meta[name="description"]', 'content', seo.description, meta('description'));
    set('meta[property="og:title"]', 'content', seo.title, meta('og:title', true));
    set('meta[property="og:description"]', 'content', seo.description, meta('og:description', true));
    set('meta[property="og:url"]', 'content', seo.canonical, meta('og:url', true));
    set('meta[name="twitter:title"]', 'content', seo.title, meta('twitter:title'));
    set('meta[name="twitter:description"]', 'content', seo.description, meta('twitter:description'));
    set('link[rel="canonical"]', 'href', seo.canonical, () => { const e = document.createElement('link'); e.setAttribute('rel', 'canonical'); return e; });
};
