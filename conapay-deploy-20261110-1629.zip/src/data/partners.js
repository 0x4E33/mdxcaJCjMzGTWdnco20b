/**
 * Partners shown in the home page strip.
 * ⚠️ Only list companies ConaPay actually works with — edit this list before going live.
 * `logo`: file in src/assets/partners/ (rendered white). Optional `scale` evens out logos with lots of padding.
 */
export const PARTNERS = [
    { name: 'PG Soft', logo: 'pg-soft.png' },
    { name: 'Pragmatic Play', logo: 'pragmatic-play.svg', scale: 1.6 },
    { name: 'JILI Games', logo: 'jili.png' },
    { name: 'Evolution', logo: 'evolution.svg' },
    { name: 'Habanero', logo: 'habanero.svg' },
    { name: 'CQ9 Gaming', logo: 'cq9.png' },
    { name: 'Spribe', logo: 'spribe.svg' },
    { name: 'Hacksaw Gaming', logo: 'hacksaw.svg' },
];
