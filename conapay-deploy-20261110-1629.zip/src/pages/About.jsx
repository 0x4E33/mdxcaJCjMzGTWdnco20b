import { Link } from 'react-router-dom';
import { ArrowRight, ArrowDownLeft, ArrowUpRight, Coins, MapPin, MessageSquareText, Activity, Compass, Headset, ChevronDown } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import PhotoBackdrop from '../components/visuals/PhotoBackdrop';
import { Reveal, ParallaxImage } from '../components/motion/Reveal';
import { asset, heroMedia } from '../data/media';
import { Flag, MethodIcon, CountUp } from '../components/coverage/shared';
import { COVERAGE_STATS, REGIONS, marketsByRegion, regionName, getMarket } from '../data/channels';

// Real footage/photography (see src/assets/about/credits.json).
const BRAND = heroMedia('about', 'brand');
const media = (name) => asset(`about/${name}`);
// Priority corridors: US wallets, European/Gulf bank transfers, Mexico SPEI.
const STORY_PHOTOS = ['us', 'europe', 'mexico'];

/** Region rows with stacked flags — real coverage data. */
const RegionsPanel = () => {
    const { t, i18n } = useTranslation();
    const regions = REGIONS.filter((r) => r.key !== 'global');
    return (
        <div className="relative overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-b from-surface-2/90 to-surface/90 p-6 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.9)]">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-text-muted"><MapPin size={13} className="text-primary" /> {t('about.regionsTitle')}</p>
            <ul className="mt-5 divide-y divide-white/[0.06]">
                {regions.map((r) => {
                    const ms = marketsByRegion(r.key);
                    return (
                        <li key={r.key} className="flex items-center gap-4 py-4">
                            <div className="w-36 shrink-0">
                                <p className="font-semibold text-white">{regionName(r.key, i18n.language)}</p>
                                <p className="text-xs text-text-muted">{t('about.regionMarkets', { count: ms.length })}</p>
                            </div>
                            <div className="flex min-w-0 flex-1 items-center justify-end">
                                <div className="flex -space-x-2">
                                    {ms.slice(0, 7).map((m) => (
                                        <span key={m.slug} className="rounded-full ring-2 ring-surface-2"><Flag market={m} className="h-7 w-7 rounded-full" /></span>
                                    ))}
                                </div>
                                {ms.length > 7 && <span className="ml-2 font-mono text-xs text-text-muted">+{ms.length - 7}</span>}
                            </div>
                        </li>
                    );
                })}
                <li className="flex items-center gap-4 pt-4">
                    <div className="w-36 shrink-0">
                        <p className="font-semibold text-white">{regionName('global', i18n.language)}</p>
                        <p className="text-xs text-text-muted">USDT</p>
                    </div>
                    <div className="flex flex-1 justify-end"><Flag market={getMarket('usdt')} className="h-7 w-7 rounded-full" /></div>
                </li>
            </ul>
        </div>
    );
};

const PILLARS = [
    { k: 'payin', icon: ArrowDownLeft, color: 'text-primary', to: '/capabilities#acquiring', logos: ['Pix', 'M-Pesa', 'GCash', 'Apple Pay'] },
    { k: 'payout', icon: ArrowUpRight, color: 'text-payout', to: '/capabilities#transfer', logos: ['PayPal', 'Cash App', 'Chime'] },
    { k: 'settlement', icon: Coins, color: 'text-[#34D399]', to: '/capabilities#settlement', logos: ['USDT'] },
];
const VALUES = [
    { k: 'local', icon: Compass },
    { k: 'transparent', icon: MessageSquareText },
    { k: 'reliable', icon: Activity },
    { k: 'responsive', icon: Headset },
];

const About = () => {
    const { t } = useTranslation();
    const stats = [
        [COVERAGE_STATS.markets, '', t('about.stats.markets')],
        [COVERAGE_STATS.payinMethods, '+', t('about.stats.methods')],
        [COVERAGE_STATS.payoutMarkets, '', t('about.stats.payout')],
        [COVERAGE_STATS.currencies, '', t('about.stats.currencies')],
    ];

    return (
        <div className="relative -mt-20 overflow-hidden pb-24">
            {/* Hero: real street-commerce footage, type set on the quiet side */}
            <section className="relative flex min-h-[min(88svh,900px)] items-end pb-14 pt-32 md:pb-20">
                <PhotoBackdrop height="100%" strength={0.5} poster={BRAND.poster} video={BRAND.video} />
                <div className="container relative mx-auto px-5">
                    <span style={{ animationDelay: '0ms' }} className="eyebrow fade-in">{t('about.eyebrow')}</span>
                    <h1 className="mt-6 max-w-4xl text-4xl font-bold leading-[1.06] text-white md:text-7xl">
                        <span className="line-mask"><span style={{ animationDelay: '100ms' }}>{t('about.titlePrefix')}</span></span>
                        <span className="line-mask"><span style={{ animationDelay: '220ms' }} className="text-ember">{t('about.titleHighlight')}</span></span>
                    </h1>
                    <p style={{ animationDelay: '380ms' }} className="fade-in mt-6 max-w-2xl text-lg text-text-heading/80">{t('about.subtitle')}</p>
                </div>
            </section>

            <section className="container relative mx-auto px-5">
                <dl className="grid grid-cols-2 overflow-hidden rounded-2xl border border-white/[0.07] bg-background/60 backdrop-blur-md md:grid-cols-4">
                    {stats.map(([v, suf, label], i) => (
                        <div key={label} className={`flex flex-col-reverse px-5 py-6 ${i % 2 === 0 ? 'border-r border-white/[0.07]' : ''} ${i < 2 ? 'border-b border-white/[0.07] md:border-b-0' : ''} md:border-r md:last:border-r-0`}>
                            <dt className="mt-1 text-xs font-medium uppercase tracking-[0.12em] text-text-muted">{label}</dt>
                            <dd className="font-display text-3xl font-bold text-white md:text-4xl"><CountUp value={v} suffix={suf} /></dd>
                        </div>
                    ))}
                </dl>
            </section>

            {/* Story + regions */}
            <section className="container relative mx-auto mt-28 grid items-center gap-12 px-5 md:mt-36 lg:grid-cols-2 lg:gap-16">
                <Reveal>
                    <p className="text-sm font-semibold text-primary">{t('about.story.eyebrow')}</p>
                    <h2 className="mt-4 text-3xl font-bold leading-tight text-white md:text-[2.75rem]">{t('about.story.title')}</h2>
                    <p className="mt-6 text-lg leading-relaxed text-text-body">{t('about.story.p1')}</p>
                    <p className="mt-4 text-lg leading-relaxed text-text-body">{t('about.story.p2')}</p>
                </Reveal>
                <Reveal index={1} className="relative">
                    <RegionsPanel />
                </Reveal>
            </section>

            {/* How people actually pay: three real scenes, staggered like a contact sheet */}
            <section className="container relative mx-auto mt-20 px-5 md:mt-28">
                <div className="grid gap-4 sm:grid-cols-3 md:gap-6">
                    {STORY_PHOTOS.map((k, i) => media(`story-${k}.jpg`) && (
                        <Reveal key={k} index={i} className={i === 1 ? 'sm:mt-16' : ''}>
                            <figure>
                                <ParallaxImage src={media(`story-${k}.jpg`)} alt={t(`about.story.photos.${k}.alt`)} zoom={0.1}
                                    className="aspect-[4/5] rounded-3xl border border-white/[0.07] bg-surface-2">
                                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
                                </ParallaxImage>
                                <figcaption className="mt-4 flex items-baseline justify-between gap-3 border-t border-white/[0.08] pt-3">
                                    <span className="text-sm font-semibold text-white">{t(`about.story.photos.${k}.title`)}</span>
                                    <span className="font-mono text-xs text-text-muted">{t(`about.story.photos.${k}.methods`)}</span>
                                </figcaption>
                            </figure>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* What we do */}
            <section className="container relative mx-auto mt-28 px-5 md:mt-36">
                <Reveal as="h2" className="text-3xl font-bold text-white md:text-4xl">{t('about.pillarsTitle')}</Reveal>
                <div className="mt-10 grid gap-4 md:grid-cols-3">
                    {PILLARS.map(({ k, icon: Icon, color, to, logos }, i) => (
                        <Reveal key={k} index={i}>
                            <Link to={to} className="group flex h-full flex-col rounded-3xl border border-white/[0.07] bg-surface/70 p-7 transition-colors hover:border-white/15 hover:bg-surface-2">
                                <div className="flex items-center justify-between">
                                    <span className={`flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] ${color}`}><Icon size={20} /></span>
                                    <ArrowUpRight size={18} className="text-text-muted transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-white" />
                                </div>
                                <h3 className="mt-6 text-xl font-semibold text-white">{t(`about.pillars.${k}.title`)}</h3>
                                <p className="mt-2 flex-1 leading-relaxed text-text-body">{t(`about.pillars.${k}.desc`)}</p>
                                <div className="mt-6 flex gap-1.5">
                                    {logos.map((m) => <MethodIcon key={m} method={m} size={22} />)}
                                </div>
                            </Link>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* How we work */}
            <section className="container relative mx-auto mt-28 px-5 md:mt-36">
                <div className="grid gap-12 lg:grid-cols-[1fr_2fr]">
                    <Reveal as="h2" className="text-3xl font-bold text-white md:text-4xl">{t('about.valuesTitle')}</Reveal>
                    <div className="grid gap-px overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.07] sm:grid-cols-2">
                        {VALUES.map(({ k, icon: Icon }, i) => (
                            <Reveal key={k} index={i} className="bg-background p-7">
                                <div className="flex items-center gap-3">
                                    <span className="font-mono text-xs text-primary">0{i + 1}</span>
                                    <Icon size={16} className="text-text-muted" />
                                </div>
                                <h3 className="mt-4 text-lg font-semibold text-white">{t(`about.values.${k}.title`)}</h3>
                                <p className="mt-2 leading-relaxed text-text-body">{t(`about.values.${k}.desc`)}</p>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="container relative mx-auto mt-28 px-5">
                <div className="border-conic relative overflow-hidden rounded-3xl">
                    <div className="relative flex flex-col items-start justify-between gap-8 rounded-3xl border border-white/[0.06] bg-gradient-to-br from-surface-2 to-surface p-8 md:flex-row md:items-center md:p-12">
                        <div className="relative max-w-xl">
                            <h2 className="text-2xl font-bold text-white md:text-3xl">{t('about.cta.title')}</h2>
                            <p className="mt-3 text-text-body">{t('about.cta.subtitle')}</p>
                        </div>
                        <div className="relative flex shrink-0 max-sm:w-full flex-col gap-3 sm:flex-row">
                            <Link to="/#coverage" className="btn-ghost max-sm:w-full">{t('about.cta.secondary')} <ChevronDown size={16} /></Link>
                            <Link to="/contact" className="btn-primary max-sm:w-full">{t('about.cta.button')} <ArrowRight size={18} /></Link>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default About;
