import { useEffect, useRef, useState } from 'react';
import { m as motion, useInView } from 'framer-motion';
import { Reveal } from '../components/motion/Reveal';
import { Link } from 'react-router-dom';
import {
    ArrowDownLeft, ArrowUpRight, ArrowRight, GitBranch, Coins, ShieldCheck, Check, Loader2,
    ListChecks, FileSpreadsheet, Wallet, Send, ChevronDown,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import PhotoBackdrop from '../components/visuals/PhotoBackdrop';
import { heroMedia } from '../data/media';
import { MethodIcon, Flag, TYPE_COLORS, methodLogo } from '../components/coverage/shared';
import { MARKETS, COVERAGE_STATS, METHOD_TYPES, getMarket, methodType, methodTypeName } from '../data/channels';

const VARS = { markets: COVERAGE_STATS.markets, methods: COVERAGE_STATS.payinMethods, payout: COVERAGE_STATS.payoutMarkets, currencies: COVERAGE_STATS.currencies };

/** Runs `fn` every `ms` while the element is on screen. */
const useTicker = (ref, ms, fn) => {
    const inView = useInView(ref, { margin: '-60px' });
    const fnRef = useRef(fn);
    fnRef.current = fn;
    useEffect(() => {
        if (!inView || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
        const id = setInterval(() => fnRef.current(), ms);
        return () => clearInterval(id);
    }, [inView, ms]);
};

const Panel = ({ children, className = '' }) => (
    <div className={`relative overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-b from-surface-2/90 to-surface/90 p-5 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.9)] backdrop-blur-xl sm:p-6 ${className}`}>
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        {children}
    </div>
);

/* ---------- Visual 1: pay-in methods (real logos + counts by type) ---------- */
const BRANDED = [...new Set(MARKETS.filter((m) => m.region !== 'global').flatMap((m) => m.payin))].filter((m) => methodLogo(m));
const TYPE_COUNTS = Object.keys(METHOD_TYPES)
    .filter((k) => k !== 'crypto')
    .map((k) => [k, MARKETS.filter((m) => m.region !== 'global').flatMap((m) => m.payin).filter((p) => methodType(p) === k).length])
    .filter(([, n]) => n > 0)
    .sort((a, b) => b[1] - a[1]);
const MAX_TYPE = Math.max(...TYPE_COUNTS.map(([, n]) => n));

const AcquiringVisual = () => {
    const { t, i18n } = useTranslation();
    const rows = [BRANDED.slice(0, Math.ceil(BRANDED.length / 2)), BRANDED.slice(Math.ceil(BRANDED.length / 2))];
    return (
        <Panel>
            <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">{t('capabilities.visual.methodsTitle')}</p>
            <div className="marquee-mask mt-4 space-y-2.5 overflow-hidden">
                {rows.map((row, r) => (
                    <div key={r} className="flex w-max gap-2.5" style={{ animation: `marquee ${38 + r * 8}s linear infinite ${r ? 'reverse' : ''}` }}>
                        {[...row, ...row, ...row, ...row].map((m, i) => (
                            <span key={`${m}-${i}`} className="inline-flex items-center gap-2 rounded-xl border border-white/[0.07] bg-white/[0.03] py-1.5 pl-1.5 pr-3 text-sm text-text-heading/90">
                                <MethodIcon method={m} size={22} /> {m}
                            </span>
                        ))}
                    </div>
                ))}
            </div>
            <p className="mt-6 text-xs font-semibold uppercase tracking-wider text-text-muted">{t('capabilities.visual.byType')}</p>
            <ul className="mt-3 space-y-2.5">
                {TYPE_COUNTS.map(([k, n], i) => (
                    <li key={k} className="grid grid-cols-[minmax(0,9.5rem)_1fr_2rem] items-center gap-3 text-xs sm:grid-cols-[11rem_1fr_2rem]">
                        <span className="truncate text-text-body">{methodTypeName(k, i18n.language)}</span>
                        <span className="h-1.5 overflow-hidden rounded-full bg-white/[0.05]">
                            <motion.span className="block h-full rounded-full" style={{ background: TYPE_COLORS[k] }}
                                initial={{ width: 0 }} whileInView={{ width: `${(n / MAX_TYPE) * 100}%` }} viewport={{ once: true }}
                                transition={{ duration: 1, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }} />
                        </span>
                        <span className="text-right font-mono text-text-heading">{n}</span>
                    </li>
                ))}
            </ul>
        </Panel>
    );
};

/* ---------- Visual 2: payout batch ---------- */
const BATCH = [
    { slug: 'united-states', method: 'Cash App', amount: '$ 420.00' },
    { slug: 'kenya', method: 'Mobile Money', amount: 'KSh 18,500' },
    { slug: 'brazil', method: 'Bank Transfer', amount: 'R$ 2,300.00' },
    { slug: 'united-kingdom', method: 'Bank Transfer', amount: '£ 960.00' },
    { slug: 'usdt', method: 'USDT', amount: '1,500.00 USDT' },
];
const PayoutVisual = () => {
    const { t } = useTranslation();
    const ref = useRef(null);
    const [done, setDone] = useState(2);
    useTicker(ref, 900, () => setDone((d) => (d >= BATCH.length + 2 ? 0 : d + 1)));
    return (
        <Panel>
            <div ref={ref} className="flex items-center justify-between">
                <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">{t('capabilities.visual.payoutTitle')}</p>
                <span className="font-mono text-xs text-text-muted">{Math.min(done, BATCH.length)}/{BATCH.length}</span>
            </div>
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/[0.05]">
                <div className="h-full rounded-full bg-gradient-to-r from-payout/60 to-payout transition-[width] duration-700" style={{ width: `${(Math.min(done, BATCH.length) / BATCH.length) * 100}%` }} />
            </div>
            <ul className="mt-4 divide-y divide-white/[0.05]">
                {BATCH.map((row, i) => {
                    const market = getMarket(row.slug);
                    const paid = i < done;
                    return (
                        <li key={row.slug} className="flex items-center gap-3 py-3">
                            <Flag market={market} className="h-6 w-8" />
                            <MethodIcon method={row.method} size={18} />
                            <span className="min-w-0 flex-1 truncate text-sm text-text-heading">{row.method}</span>
                            <span className="hidden font-mono text-sm text-white sm:block">{row.amount}</span>
                            <span className={`inline-flex w-[92px] items-center justify-end gap-1 text-xs font-semibold transition-colors ${paid ? 'text-payout' : 'text-text-muted'}`}>
                                {paid ? <Check size={13} /> : <Loader2 size={13} className="animate-spin" />}
                                {paid ? t('capabilities.visual.paid') : t('capabilities.visual.processing')}
                            </span>
                        </li>
                    );
                })}
            </ul>
        </Panel>
    );
};

/* ---------- Visual 3: settlement (local collections -> equivalent USDT) ---------- */
const CURRENCIES = ['USD', 'EUR', 'GBP', 'BRL', 'MXN', 'COP', 'NGN', 'KES', 'PHP', 'IDR', 'MYR', 'ZAR'];
// Illustrative statement lines; amounts are examples only.
const STATEMENT = [
    { slug: 'brazil', local: 'R$ 12,480.00', usdt: '2,296.40' },
    { slug: 'mexico', local: 'MX$ 38,200.00', usdt: '2,081.90' },
    { slug: 'nigeria', local: '₦ 3,150,000', usdt: '2,034.70' },
    { slug: 'philippines', local: '₱ 96,500.00', usdt: '1,668.30' },
];
const SettlementVisual = () => {
    const { t } = useTranslation();
    const ref = useRef(null);
    const [row, setRow] = useState(0);
    useTicker(ref, 1600, () => setRow((r) => (r + 1) % STATEMENT.length));
    return (
        <Panel>
            <div ref={ref} className="grid items-center gap-5 sm:grid-cols-[1fr_auto]">
                <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">{t('capabilities.visual.settleFrom')}</p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                        {CURRENCIES.map((c) => (
                            <span key={c} className="rounded-md border border-white/[0.07] bg-white/[0.04] px-2 py-1 font-mono text-[11px] text-text-heading">
                                {c}
                            </span>
                        ))}
                    </div>
                </div>
                <div className="relative mx-auto flex h-24 w-24 items-center justify-center">
                    <div className="absolute inset-0 rounded-full border border-[#26A17B]/25" />
                    <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-white shadow-[0_16px_40px_-12px_rgba(38,161,123,0.6)]">
                        {methodLogo('USDT') ? <img src={methodLogo('USDT')} alt="USDT" className="h-10 w-10" /> : <Coins className="text-[#26A17B]" size={30} />}
                    </div>
                </div>
            </div>
            <p className="mt-6 text-xs font-semibold uppercase tracking-wider text-text-muted">{t('capabilities.visual.statement')}</p>
            <ul className="mt-3 space-y-1.5">
                {STATEMENT.map((r, i) => {
                    const m = getMarket(r.slug);
                    const on = i === row;
                    return (
                        <li key={r.slug} className={`grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all duration-300 ${on ? 'bg-[#26A17B]/10 ring-1 ring-[#26A17B]/40' : ''}`}>
                            <Flag market={m} className="h-5 w-7" />
                            <span className="truncate font-mono text-xs text-text-body sm:text-sm">{r.local} <ArrowRight size={12} className="mx-1 inline text-text-muted" /> <span className="text-white">{r.usdt} USDT</span></span>
                            <span className={`inline-flex items-center gap-1 text-xs font-semibold ${on ? 'text-[#34D399]' : 'text-text-muted'}`}><Check size={12} /> <span className="max-sm:hidden">{t('capabilities.visual.settled')}</span></span>
                        </li>
                    );
                })}
            </ul>
        </Panel>
    );
};

/* ---------- Visual 4: routing ---------- */
const RoutingVisual = () => {
    const { t } = useTranslation();
    const ref = useRef(null);
    const [s, setS] = useState({ a: 74.6, b: 81.2, n: 0 });
    useTicker(ref, 2400, () => setS((p) => ({ a: 70 + Math.random() * 14, b: 70 + Math.random() * 14, n: p.n + 1 })));
    const best = s.b >= s.a ? 'b' : 'a';
    const market = getMarket('united-states');
    return (
        <Panel>
            <div ref={ref} className="flex items-center gap-3">
                <Flag market={market} className="h-7 w-10" />
                <MethodIcon method="Cash App" size={22} />
                <div>
                    <p className="text-sm font-semibold text-white">Cash App · USD</p>
                    <p className="text-xs text-text-muted">{t('capabilities.visual.successRate')}</p>
                </div>
            </div>
            <div className="relative mt-6 space-y-4">
                {[['a', t('capabilities.visual.routeA'), s.a], ['b', t('capabilities.visual.routeB'), s.b]].map(([k, label, v]) => (
                    <div key={k} className={`rounded-2xl border p-4 transition-colors duration-500 ${k === best ? 'border-primary/40 bg-primary/[0.06]' : 'border-white/[0.07] bg-white/[0.02]'}`}>
                        <div className="flex items-center justify-between text-sm">
                            <span className={`inline-flex items-center gap-2 ${k === best ? 'font-semibold text-white' : 'text-text-muted'}`}>
                                <GitBranch size={14} className={k === best ? 'text-primary' : ''} /> {label}
                            </span>
                            <span className={`inline-flex items-center gap-1.5 font-mono ${k === best ? 'text-primary' : 'text-text-muted'}`}>
                                {k === best && <span className="rounded bg-primary px-1.5 py-0.5 font-sans text-[10px] font-bold text-black">{t('capabilities.visual.selected')}</span>}
                                {v.toFixed(1)}%
                            </span>
                        </div>
                        <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                            <div className={`h-full rounded-full transition-[width] duration-700 ${k === best ? 'bg-gradient-to-r from-primary-soft to-primary' : 'bg-white/20'}`} style={{ width: `${v}%` }} />
                        </div>
                    </div>
                ))}
            </div>
        </Panel>
    );
};

/* ---------- Visual 5: security checks ---------- */
const SecurityVisual = () => {
    const { t } = useTranslation();
    const checks = t('capabilities.visual.checks', { returnObjects: true });
    const list = Array.isArray(checks) ? checks : [];
    const ref = useRef(null);
    const [n, setN] = useState(list.length);
    useTicker(ref, 700, () => setN((x) => (x >= list.length + 3 ? 0 : x + 1)));
    return (
        <Panel>
            <div ref={ref} className="rounded-xl border border-white/[0.07] bg-background/60 p-3 font-mono text-[11px] leading-relaxed text-text-muted">
                <span className="text-payout">POST</span> /order · <span className="text-text-heading">sign=</span>9f3c…a1e2 · <span className="text-text-heading">ip=</span>203.0.113.24
            </div>
            <ul className="mt-4 space-y-2">
                {list.map((c, i) => {
                    const ok = i < n;
                    return (
                        <li key={c} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all duration-300 ${ok ? 'bg-payout/[0.06] text-white' : 'text-text-muted'}`}>
                            <span className={`flex h-6 w-6 items-center justify-center rounded-full transition-colors ${ok ? 'bg-payout text-black' : 'bg-white/[0.06]'}`}>
                                {ok ? <Check size={13} strokeWidth={3} /> : <Loader2 size={12} className="animate-spin" />}
                            </span>
                            {c}
                        </li>
                    );
                })}
            </ul>
        </Panel>
    );
};

const SECTIONS = [
    { id: 'acquiring', icon: ArrowDownLeft, Visual: AcquiringVisual, accent: 'text-primary' },
    { id: 'transfer', icon: ArrowUpRight, Visual: PayoutVisual, accent: 'text-payout' },
    { id: 'settlement', icon: Coins, Visual: SettlementVisual, accent: 'text-[#34D399]' },
    { id: 'routing', icon: GitBranch, Visual: RoutingVisual, accent: 'text-primary' },
    { id: 'security', icon: ShieldCheck, Visual: SecurityVisual, accent: 'text-payout' },
];

const FLOW = [
    { k: 'collect', icon: ArrowDownLeft },
    { k: 'route', icon: GitBranch },
    { k: 'settle', icon: Coins },
    { k: 'payout', icon: ArrowUpRight },
];

const DASH_ICONS = [ListChecks, FileSpreadsheet, Wallet, Send];

const Capabilities = () => {
    const { t } = useTranslation();
    const dash = t('capabilities.dashboard.items', { returnObjects: true });

    return (
        <div className="relative -mt-20 overflow-hidden pb-24 pt-20">
            <PhotoBackdrop {...heroMedia('capabilities')} height={860} strength={0.58} />

            {/* Hero */}
            <section className="container relative mx-auto px-5 pt-14 text-center md:pt-24">
                <span style={{ animationDelay: '0ms' }} className="eyebrow animate-rise">{t('capabilities.eyebrow')}</span>
                <h1 style={{ animationDelay: '60ms' }} className="animate-rise mx-auto mt-6 max-w-4xl text-4xl font-bold leading-[1.06] text-white md:text-7xl">
                    {t('capabilities.titlePrefix')} <span className="text-ember">{t('capabilities.titleHighlight')}</span>
                </h1>
                <p style={{ animationDelay: '120ms' }} className="animate-rise mx-auto mt-6 max-w-2xl text-lg text-text-body">{t('capabilities.subtitle')}</p>
                <div style={{ animationDelay: '180ms' }} className="animate-rise mt-9 flex flex-col justify-center gap-3 sm:flex-row">
                    <Link to="/contact" className="btn-primary">{t('capabilities.cta')} <ArrowRight size={18} /></Link>
                    <Link to="/#coverage" className="btn-ghost">{t('capabilities.ctaSecondary')} <ChevronDown size={18} /></Link>
                </div>

                {/* Money flow */}
                <ol style={{ animationDelay: '260ms' }} className="animate-rise relative mx-auto mt-16 grid max-w-4xl grid-cols-2 gap-3 md:grid-cols-4 md:gap-0">
                    <div className="absolute left-[12.5%] right-[12.5%] top-7 hidden h-px overflow-hidden bg-white/[0.08] md:block" aria-hidden="true">
                        <span className="absolute inset-y-0 w-24 animate-[flow-x_3.2s_linear_infinite] bg-gradient-to-r from-transparent via-primary to-transparent" />
                    </div>
                    {FLOW.map(({ k, icon: Icon }, i) => (
                        <li key={k} className="relative flex flex-col items-center">
                            <span className={`relative flex h-14 w-14 items-center justify-center rounded-2xl border bg-surface ${i === 2 ? 'border-[#26A17B]/50 text-[#34D399]' : 'border-white/10 text-primary'}`}>
                                <Icon size={22} />
                            </span>
                            <span className="mt-3 text-sm font-semibold text-white">{t(`capabilities.flow.${k}`)}</span>
                            <span className="text-xs text-text-muted">{t(`capabilities.flow.${k}Desc`)}</span>
                        </li>
                    ))}
                </ol>
            </section>

            {/* Capabilities */}
            <div className="container relative mx-auto mt-24 space-y-24 px-5 md:mt-32 md:space-y-32">
                {SECTIONS.map(({ id, icon: Icon, Visual, accent }, i) => {
                    const points = t(`capabilities.items.${id}.points`, { returnObjects: true, ...VARS });
                    return (
                        <section key={id} id={id} className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16 [&>*]:min-w-0">
                            <Reveal className={i % 2 ? 'lg:order-2' : ''}>
                                <div className="flex items-center gap-3">
                                    <span className={`flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] ${accent}`}><Icon size={18} /></span>
                                    <span className="font-mono text-xs text-text-muted">0{i + 1}</span>
                                    <span className="h-px w-10 bg-white/10" />
                                    <span className={`text-sm font-semibold ${accent}`}>{t(`capabilities.items.${id}.title`)}</span>
                                </div>
                                <h2 className="mt-6 text-3xl font-bold leading-tight text-white md:text-[2.6rem]">{t(`capabilities.items.${id}.lead`)}</h2>
                                <p className="mt-5 text-lg leading-relaxed text-text-body">{t(`capabilities.items.${id}.desc`, VARS)}</p>
                                <ul className="mt-7 space-y-3">
                                    {(Array.isArray(points) ? points : []).map((p) => (
                                        <li key={p} className="flex items-start gap-3 text-text-heading/90">
                                            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary"><Check size={12} strokeWidth={3} /></span>
                                            {p}
                                        </li>
                                    ))}
                                </ul>
                            </Reveal>
                            <Reveal index={1} className={`relative ${i % 2 ? 'lg:order-1' : ''}`}>
                                <Visual />
                            </Reveal>
                        </section>
                    );
                })}
            </div>

            {/* Dashboard */}
            <section className="container relative mx-auto mt-28 px-5">
                <h2 className="text-center text-2xl font-bold text-white md:text-3xl">{t('capabilities.dashboard.title')}</h2>
                <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
                    {(Array.isArray(dash) ? dash : []).map((d, i) => {
                        const Icon = DASH_ICONS[i] || ListChecks;
                        return (
                            <div key={d} className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-surface/70 p-4 md:p-5">
                                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><Icon size={18} /></span>
                                <span className="text-sm font-medium text-text-heading">{d}</span>
                            </div>
                        );
                    })}
                </div>
            </section>

            {/* CTA band */}
            <section className="container relative mx-auto mt-20 px-5">
                <div className="border-conic relative overflow-hidden rounded-3xl">
                    <div className="relative flex flex-col items-start justify-between gap-8 rounded-3xl border border-white/[0.06] bg-gradient-to-br from-surface-2 to-surface p-8 md:flex-row md:items-center md:p-12">
                        <div className="relative max-w-xl">
                            <h2 className="text-2xl font-bold text-white md:text-3xl">{t('capabilities.ctaBand.title')}</h2>
                            <p className="mt-3 text-text-body">{t('capabilities.ctaBand.desc')}</p>
                        </div>
                        <Link to="/contact" className="btn-primary relative shrink-0 max-sm:w-full">{t('nav.contact')} <ArrowRight size={18} /></Link>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Capabilities;
