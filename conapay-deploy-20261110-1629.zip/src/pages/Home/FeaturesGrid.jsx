import { Globe2, Zap, ShieldCheck, Code2, Layers, ScanSearch } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { COVERAGE_STATS } from '../../data/channels';
import { Reveal } from '../../components/motion/Reveal';
import nightLights from '../../assets/home/night-lights.jpg';

const ITEMS = [
    { k: 'reach', icon: Globe2 },
    { k: 'settlement', icon: Zap },
    { k: 'compliance', icon: ShieldCheck },
    { k: 'developer', icon: Code2 },
    { k: 'treasury', icon: Layers },
    { k: 'fraud', icon: ScanSearch },
];

/** Why ConaPay: a still, editorial hairline grid — the copy does the work, nothing loops. */
const FeaturesGrid = () => {
    const { t } = useTranslation();
    const vars = { markets: COVERAGE_STATS.markets, payout: COVERAGE_STATS.payoutMarkets };

    return (
        <section className="relative overflow-hidden py-24 md:py-32">
            {/* a city's lights seen from the air: the people behind every payment, at global scale */}
            <div className="pointer-events-none absolute inset-0 [mask-image:linear-gradient(180deg,transparent_0%,black_16%,black_84%,transparent_100%)]" aria-hidden="true">
                <img src={nightLights} alt="" loading="lazy" decoding="async" className="absolute inset-x-0 bottom-0 h-[80%] w-full object-cover object-[center_70%] opacity-70" />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(10,9,8,0.9)_0%,rgba(10,9,8,0.3)_55%,rgba(10,9,8,0.55)_100%)]" />
                <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(10,9,8,0.85)_0%,rgba(10,9,8,0.15)_55%,rgba(10,9,8,0.5)_100%)]" />
            </div>
            <div className="container relative mx-auto px-5">
                <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,2fr)] lg:gap-16">
                    <Reveal className="lg:sticky lg:top-32 lg:self-start">
                        <h2 className="text-3xl font-bold text-white sm:text-4xl md:text-5xl">{t('home.features.title')}</h2>
                        <p className="mt-6 max-w-md text-lg text-text-body">{t('home.features.subtitle')}</p>
                    </Reveal>

                    <div className="grid gap-px overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.08] sm:grid-cols-2">
                        {ITEMS.map(({ k, icon: Icon }, i) => (
                            <Reveal key={k} index={i % 2} className="group bg-background/[0.88] p-7 transition-colors duration-300 hover:bg-surface/95 md:p-9">
                                <div className="flex items-center justify-between">
                                    <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-primary transition-colors duration-300 group-hover:border-primary/30">
                                        <Icon size={18} strokeWidth={1.75} />
                                    </span>
                                    <span className="font-mono text-xs text-text-muted">0{i + 1}</span>
                                </div>
                                <h3 className="mt-6 text-lg font-semibold text-white md:text-xl">{t(`home.features.items.${k}.title`)}</h3>
                                <p className="mt-2 leading-relaxed text-text-body">{t(`home.features.items.${k}.desc`, vars)}</p>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default FeaturesGrid;
