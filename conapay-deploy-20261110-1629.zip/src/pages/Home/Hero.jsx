import { useCallback, useEffect, useRef, useState } from 'react';
import { m as motion, AnimatePresence, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, ChevronDown, Zap, Activity, GitBranch, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getMarket, marketName } from '../../data/channels';
import { Flag } from '../../components/coverage/shared';
import HeroGlobe from '../../components/visuals/HeroGlobe';

const POPULAR = ['united-states', 'eurozone', 'united-kingdom', 'united-arab-emirates', 'mexico', 'colombia', 'zambia'];

// Deterministic first state so server HTML and the first client render match.
const INITIAL_ROUTE = { market: getMarket('brazil'), method: 'Pix', a: 74.2, b: 81.6, n: 0 };

const short = (method, market) => (method.startsWith(`${market.name.en} `) ? method.slice(market.name.en.length + 1) : method);

/** Smart-routing card: which route the last payment took and why. Success rates kept realistic (~75–86%). */
const RoutingCard = ({ route }) => {
    const { t, i18n } = useTranslation();
    const best = route.b >= route.a ? 'b' : 'a';
    const rows = [['a', t('home.hero.hud.routeA'), route.a], ['b', t('home.hero.hud.routeB'), route.b]];
    return (
        <div className="w-[230px] rounded-2xl border border-white/10 bg-surface/80 p-4 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)] backdrop-blur-xl sm:w-[260px]">
            <div className="flex items-center">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-text-muted">
                    <GitBranch size={12} className="text-primary" /> {t('home.hero.hud.routing')}
                </span>
            </div>
            <AnimatePresence mode="wait" initial={false}>
                <motion.div key={route.n} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.25 }}
                    className="mt-3 flex items-center gap-2.5">
                    <Flag market={route.market} className="h-6 w-8" />
                    <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-white">{short(route.method, route.market)}</p>
                        <p className="truncate text-[11px] text-text-muted">{marketName(route.market, i18n.language)} · {route.market.currency}</p>
                    </div>
                </motion.div>
            </AnimatePresence>
            <div className="mt-3 space-y-2">
                {rows.map(([k, label, v]) => (
                    <div key={k}>
                        <div className="flex items-center justify-between text-[11px]">
                            <span className={k === best ? 'font-semibold text-white' : 'text-text-muted'}>{label}</span>
                            <span className={`inline-flex items-center gap-1 font-mono ${k === best ? 'text-primary' : 'text-text-muted'}`}>
                                {k === best && <Check size={11} />}{v.toFixed(1)}%
                            </span>
                        </div>
                        <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/[0.06]">
                            <div className={`h-full rounded-full transition-[width] duration-700 ease-out ${k === best ? 'bg-gradient-to-r from-primary-soft to-primary' : 'bg-white/20'}`}
                                style={{ width: `${v}%` }} />
                        </div>
                    </div>
                ))}
            </div>
            <p className="mt-3 text-[10px] text-text-muted">{t('home.hero.hud.success')}</p>
        </div>
    );
};

/** Settlement card: each collected payment lands as equivalent USDT. */
const SettlementCard = ({ settled }) => {
    const { t } = useTranslation();
    return (
        <div className="w-[248px] rounded-2xl border border-white/10 bg-surface/80 p-4 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)] backdrop-blur-xl">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-text-muted">{t('home.hero.hud.settlement')}</p>
            <div className="mt-2 flex items-baseline gap-2">
                <span className="font-display text-2xl font-bold text-white">USDT</span>
                <span className="text-xs font-semibold text-[#34D399]">{t('home.hero.hud.settledIn')}</span>
            </div>
            <p className="mt-0.5 text-[10px] text-text-muted">{t('home.hero.hud.d0')}</p>
            <AnimatePresence mode="wait" initial={false}>
                <motion.div key={settled.n} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.25 }}
                    className="mt-3 flex items-center gap-2 rounded-lg bg-white/[0.04] px-2.5 py-2 font-mono text-[11px]">
                    <span className="text-text-heading">{settled.currency}</span>
                    <ArrowRight size={11} className="text-text-muted" />
                    <span className="font-semibold text-[#6EE7B7]">USDT</span>
                    <Check size={12} className="ml-auto text-[#34D399]" />
                </motion.div>
            </AnimatePresence>
        </div>
    );
};

const Hero = () => {
    const { t, i18n } = useTranslation();
    const [route, setRoute] = useState(INITIAL_ROUTE);
    const [settled, setSettled] = useState({ n: 0, currency: 'BRL' });
    const globeRef = useRef(null);
    const reduced = useReducedMotion();
    const [desktop, setDesktop] = useState(false);
    useEffect(() => {
        const mq = window.matchMedia('(min-width: 1024px)');
        const on = () => setDesktop(mq.matches);
        on();
        mq.addEventListener('change', on);
        return () => mq.removeEventListener('change', on);
    }, []);

    // As the hero scrolls away the globe drifts slower than the page and recedes, handing focus to coverage.
    const { scrollY } = useScroll();
    const globeY = useTransform(scrollY, [0, 800], [0, 160]);
    const globeOpacity = useTransform(scrollY, [0, 700], [1, 0.2]);
    const globeScale = useTransform(scrollY, [0, 800], [1, 0.94]);

    const onLaunch = useCallback(({ market, method }) => {
        setRoute((r) => {
            const a = 72 + Math.random() * 8;
            const b = 72 + Math.random() * 13;
            return { market, method, a, b, n: r.n + 1 };
        });
    }, []);
    const onSettle = useCallback(({ market }) => setSettled((s) => ({ n: s.n + 1, currency: market.currency })), []);

    const d = (ms) => ({ animationDelay: `${ms}ms` });

    return (
        <section className="relative overflow-hidden">
            {/* one quiet, static light pool behind the globe; everything else is the page colour */}
            <div className="pointer-events-none absolute inset-0" aria-hidden="true">
                <div className="absolute right-[-20%] top-[-10%] h-[1100px] w-[1100px] rounded-full bg-[radial-gradient(circle,rgba(255,138,40,0.075),transparent_60%)] max-lg:right-[-60%] max-lg:top-[30%]" />
                <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />
            </div>

            <div className="container relative mx-auto px-5">
                <div className="relative z-10 flex max-w-[640px] flex-col justify-center pb-16 pt-10 lg:min-h-[min(calc(100svh-5rem),860px)] lg:pb-16 lg:pt-8 xl:max-w-[680px]">
                    <h1 className="text-[2.75rem] font-bold leading-[1.04] text-white sm:text-6xl xl:text-[4.5rem]">
                        <span className="line-mask"><span style={d(120)}>{t('home.hero.title_prefix')}</span></span>
                        <span className="line-mask"><span style={d(240)} className="text-ember">{t('home.hero.title_highlight')}</span></span>
                    </h1>

                    <p style={d(420)} className="fade-in mt-6 max-w-xl text-lg leading-relaxed text-text-body">
                        {t('home.hero.subtitle')}
                    </p>

                    <div style={d(520)} className="fade-in mt-9 flex flex-col gap-3 sm:flex-row">
                        <Link to="/contact" className="btn-primary text-base">
                            {t('home.hero.cta')} <ArrowRight size={18} />
                        </Link>
                        <Link to="/#coverage" className="btn-ghost text-base">
                            {t('home.hero.coverage')} <ChevronDown size={18} />
                        </Link>
                    </div>

                    {/* hovering a market turns the globe to it and sends a payment from there */}
                    <div style={d(620)} className="fade-in mt-8 flex flex-wrap items-center gap-2">
                        <span className="mr-1 text-sm text-text-muted">{t('home.hero.popular')}</span>
                        {POPULAR.map((slug) => {
                            const m = getMarket(slug);
                            const focus = () => globeRef.current?.focus(slug);
                            return (
                                <Link key={slug} to={`/payment-methods/${slug}`} onMouseEnter={focus} onFocus={focus}
                                    className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] py-1 pl-1 pr-3 text-xs text-text-body transition-colors duration-200 hover:border-primary/40 hover:bg-white/[0.06] hover:text-white">
                                    <Flag market={m} className="h-4 w-4 rounded-full" />
                                    {marketName(m, i18n.language)}
                                </Link>
                            );
                        })}
                    </div>

                    <ul style={d(720)} className="fade-in mt-9 flex flex-wrap gap-x-7 gap-y-3 text-sm text-text-body">
                        <li className="inline-flex items-center gap-2"><Zap size={16} className="text-primary" /> {t('home.hero.stats.settlement')}</li>
                        <li className="inline-flex items-center gap-2"><GitBranch size={16} className="text-primary" /> {t('home.hero.stats.routing')}</li>
                        <li className="inline-flex items-center gap-2"><Activity size={16} className="text-primary" /> {t('home.hero.stats.monitoring')}</li>
                    </ul>
                </div>

                {/* Globe: desktop only (phones read straight through the copy, and never download three.js); anchored to the content column */}
                {desktop && (
                <div className="absolute left-[52%] top-1/2 aspect-square w-[min(46vw,780px)] -translate-y-1/2">
                    <motion.div className="h-full w-full" style={reduced ? undefined : { y: globeY, opacity: globeOpacity, scale: globeScale }}>
                        <HeroGlobe ref={globeRef} className="h-full w-full" onLaunch={onLaunch} onSettle={onSettle} nodeLabel="USDT" />

                        <div style={d(1500)} className="fade-in absolute right-[8%] top-[6%] hidden sm:block lg:right-[15%] lg:top-[7%]">
                            <RoutingCard route={route} />
                        </div>
                        <div style={d(1700)} className="fade-in absolute bottom-[10%] left-[6%] hidden sm:block lg:bottom-[9%] lg:left-auto lg:right-[7%]">
                            <SettlementCard settled={settled} />
                        </div>
                    </motion.div>
                </div>
                )}
            </div>
        </section>
    );
};

export default Hero;
