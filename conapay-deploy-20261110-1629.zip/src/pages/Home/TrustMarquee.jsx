import { useTranslation } from 'react-i18next';
import { PARTNERS } from '../../data/partners';

const LOGOS = import.meta.glob('../../assets/partners/*.{svg,png}', { eager: true, query: '?url', import: 'default' });
const logoUrl = (file) => (file ? LOGOS[`../../assets/partners/${file}`] : null);

const Row = ({ ariaHidden }) => (
    <ul className="flex shrink-0 items-center gap-16 pr-16" aria-hidden={ariaHidden}>
        {PARTNERS.map((p) => {
            const src = logoUrl(p.logo);
            return (
                <li key={p.name} className="flex h-10 shrink-0 items-center opacity-60 transition-opacity duration-300 hover:opacity-100">
                    {src
                        ? <img src={src} alt={p.name} style={{ height: 32 * (p.scale || 1) }} className="w-auto max-w-[170px] object-contain [filter:brightness(0)_invert(1)]" loading="lazy" decoding="async" />
                        : <span className="whitespace-nowrap font-display text-xl font-bold uppercase tracking-[0.08em] text-white">{p.name}</span>}
                </li>
            );
        })}
    </ul>
);

/** Partner strip (data in src/data/partners.js). */
const TrustMarquee = ({ className = 'relative py-12' }) => {
    const { t } = useTranslation();
    return (
        <section className={className}>
            <p className="container mx-auto mb-8 px-5 text-center text-xs font-semibold uppercase tracking-[0.2em] text-text-muted">
                {t('home.trust.title')}
            </p>
            <div className="marquee-mask group flex overflow-hidden">
                <div className="flex animate-marquee group-hover:[animation-play-state:paused]">
                    <Row />
                    <Row ariaHidden />
                </div>
            </div>
        </section>
    );
};

export default TrustMarquee;
