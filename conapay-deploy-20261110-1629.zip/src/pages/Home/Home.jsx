import React from 'react';
import Hero from './Hero';
import Coverage from './Coverage';
import TrustMarquee from './TrustMarquee';
import SolutionsGrid from './SolutionsGrid';
import FeaturesGrid from './FeaturesGrid';
import FAQ from './FAQ';

// Coverage sits right under the hero so visitors see supported channels after one scroll.
const Home = () => {
    return (
        <div className="flex flex-col">
            <Hero />
            <Coverage />
            <TrustMarquee />
            <SolutionsGrid />
            <FeaturesGrid />
            <FAQ />
        </div>
    );
};

export default Home;
