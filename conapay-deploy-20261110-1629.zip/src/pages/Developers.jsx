import { useEffect, useRef, useState } from 'react';
import { m as motion, useInView } from 'framer-motion';
import { Reveal } from '../components/motion/Reveal';
import { Link } from 'react-router-dom';
import { UserPlus, KeyRound, Code2, Rocket, Headset, BellRing, LayoutDashboard, Lock, Send, ArrowRight } from 'lucide-react';
import PhotoBackdrop from '../components/visuals/PhotoBackdrop';
import { heroMedia } from '../data/media';
import { useTranslation } from 'react-i18next';
import { handleSpotlight } from '../components/coverage/shared';

const STEP_ICONS = [UserPlus, KeyRound, Code2, Rocket];
const FEATURES = [
    ['support', Headset],
    ['webhooks', BellRing],
    ['dashboard', LayoutDashboard],
    ['security', Lock],
];

/**
 * Simplified developer page: the integration path and what you get, no API reference.
 */
const Developers = () => {
    const { t } = useTranslation();
    const stepsRef = useRef(null);
    const inView = useInView(stepsRef, { once: true, margin: '-80px' });
    const [active, setActive] = useState(0);

    // Light the steps up one by one when they scroll into view
    useEffect(() => {
        if (!inView || active >= 4) return;
        const id = setTimeout(() => setActive((n) => n + 1), active === 0 ? 150 : 450);
        return () => clearTimeout(id);
    }, [inView, active]);

    return (
        <div className="relative -mt-20 overflow-hidden pb-24 pt-20">
            <PhotoBackdrop {...heroMedia('developers')} height={820} strength={0.8} />

            <section className="container relative mx-auto px-5 pt-14 text-center md:pt-24">
                <span style={{ animationDelay: '0ms' }} className="eyebrow animate-rise">{t('developers.badge')}</span>
                <h1 style={{ animationDelay: '60ms' }} className="animate-rise mx-auto mt-6 max-w-4xl text-4xl font-bold leading-[1.08] text-white md:text-6xl">
                    {t('developers.titlePrefix')} <span className="text-ember">{t('developers.titleHighlight')}</span>
                </h1>
                <p style={{ animationDelay: '120ms' }} className="animate-rise mx-auto mt-6 max-w-2xl text-lg text-text-body">
                    {t('developers.description')}
                </p>

                {/* Steps */}
                <ol ref={stepsRef} className="relative mx-auto mt-20 grid max-w-6xl gap-10 max-sm:mt-12 max-sm:gap-6 md:grid-cols-2 lg:grid-cols-4 lg:gap-6">
                    <div className="absolute left-[12.5%] right-[12.5%] top-[52px] hidden h-px bg-white/[0.06] lg:block" aria-hidden="true">
                        <div className="h-full origin-left bg-gradient-to-r from-primary/0 via-primary to-primary/0 transition-transform duration-[1600ms] ease-out"
                            style={{ transform: `scaleX(${active / 4})` }} />
                    </div>
                    {[0, 1, 2, 3].map((i) => {
                        const Icon = STEP_ICONS[i];
                        const on = active > i;
                        return (
                            <li key={i} className="relative flex flex-col items-center max-sm:flex-row max-sm:items-start max-sm:gap-5 max-sm:text-left">
                                <div className={`relative flex h-[104px] w-[104px] shrink-0 items-center justify-center rounded-[28px] border bg-surface transition-all duration-500 max-sm:h-16 max-sm:w-16 max-sm:rounded-2xl ${on ? 'border-primary/50 text-white shadow-[0_0_40px_-8px_rgba(255,153,0,0.5)]' : 'border-white/10 text-text-muted'}`}>
                                    <Icon size={34} strokeWidth={1.6} className="max-sm:h-6 max-sm:w-6" />
                                    <span className={`absolute -right-2 -top-2 flex h-8 w-8 max-sm:h-6 max-sm:w-6 max-sm:text-[10px] items-center justify-center rounded-full border text-xs font-bold transition-colors duration-500 ${on ? 'border-white/20 bg-primary text-black' : 'border-white/10 bg-surface-3 text-text-muted'}`}>
                                        {i + 1}
                                    </span>
                                </div>
                                <div>
                                <h2 className={`mt-7 max-sm:mt-1 font-sans text-lg font-semibold transition-colors duration-500 ${on ? 'text-white' : 'text-text-heading/70'}`}>{t(`developers.steps.${i}.title`)}</h2>
                                <p className="mt-2 max-w-[240px] text-sm leading-relaxed text-text-body max-sm:mt-1 max-sm:max-w-none">{t(`developers.steps.${i}.desc`)}</p>
                                </div>
                            </li>
                        );
                    })}
                </ol>

                <div className="mt-14">
                    <Link to="/contact" className="btn-primary">{t('developers.cta')} <ArrowRight size={18} /></Link>
                </div>
            </section>

            {/* What you get */}
            <section className="container relative mx-auto mt-28 px-5">
                <div onMouseMove={handleSpotlight} className="spotlight-group grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {FEATURES.map(([key, Icon], i) => (
                        <Reveal key={key} index={i}
                            className="spotlight rounded-2xl border border-white/[0.07] bg-surface/70 p-6">
                            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary"><Icon size={20} /></div>
                            <h3 className="mt-5 text-base font-semibold text-white">{t(`developers.features.${key}.title`)}</h3>
                            <p className="mt-2 text-sm leading-relaxed text-text-body">{t(`developers.features.${key}.desc`)}</p>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* Support */}
            <section className="container relative mx-auto mt-16 px-5">
                <div className="border-conic relative overflow-hidden rounded-3xl">
                    <div className="relative flex flex-col items-start justify-between gap-8 rounded-3xl border border-white/[0.06] bg-gradient-to-br from-surface-2 to-surface p-8 md:flex-row md:items-center md:p-12">
                        <div className="relative max-w-xl">
                            <h2 className="text-2xl font-bold text-white md:text-3xl">{t('developers.support.title')}</h2>
                            <p className="mt-3 text-text-body">{t('developers.support.desc')}</p>
                        </div>
                        <Link to="/contact" className="btn-ghost relative shrink-0 max-sm:w-full"><Send size={16} /> {t('developers.support.button')}</Link>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Developers;
