// framer-motion feature bundle, loaded after first paint by <LazyMotion> (layout animations need domMax).
import { domMax } from 'framer-motion';

export default domMax;
