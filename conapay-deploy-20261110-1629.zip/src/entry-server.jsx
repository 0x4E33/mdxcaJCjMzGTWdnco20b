/* global Buffer */
// Build-time prerender entry (see scripts/prerender.mjs). Not shipped to the browser.
import { StaticRouter } from 'react-router-dom';
import { prerenderToNodeStream } from 'react-dom/static';
import i18n from './i18n';
import { AppShell } from './App.jsx';

export { getSeo, PRERENDER_ROUTES } from './seo';
export { MARKETS, REGIONS, COVERAGE_STATS, SITE_URL, hasPayout } from './data/channels';

const streamToString = async (stream) => {
    const chunks = [];
    for await (const chunk of stream) chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
    return Buffer.concat(chunks).toString('utf8');
};

export async function render(url) {
    await i18n.changeLanguage('en');
    const { prelude } = await prerenderToNodeStream(
        <StaticRouter location={url}>
            <AppShell />
        </StaticRouter>
    );
    return streamToString(prelude);
}
