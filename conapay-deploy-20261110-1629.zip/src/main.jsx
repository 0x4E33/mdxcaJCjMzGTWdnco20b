import { StrictMode } from 'react'
import { createRoot, hydrateRoot } from 'react-dom/client'
import './index.css'
import i18n from './i18n'; // Initialize i18n
import App from './App.jsx'

const container = document.getElementById('root');
const app = (
  <StrictMode>
    <App />
  </StrictMode>
);

// Pages are prerendered in English at build time (for SEO). Hydrate only when the
// HTML was rendered for this exact route (a server may fall back to the home page's
// HTML for unknown paths) and the visitor uses English; otherwise render fresh.
const path = window.location.pathname.replace(/\/+$/, '') || '/';
const canHydrate = container.hasChildNodes()
  && container.dataset.route === path
  && !i18n.language?.startsWith('zh');

if (canHydrate) {
  hydrateRoot(container, app);
} else {
  container.textContent = '';
  createRoot(container).render(app);
}
