import * as THREE from 'three';
import { Line2 } from 'three/addons/lines/Line2.js';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineGeometry } from 'three/addons/lines/LineGeometry.js';
import { LAND_HD_MASK, LAND_HD_W, LAND_HD_H } from '../../../data/landmask-hd';
import { MARKETS, MARKET_GEO, hasPayout } from '../../../data/channels';

/**
 * Hero payment globe (three.js, loaded on demand).
 *
 * Story, and nothing else: real land (Natural Earth, 0.5°) as a lit dot matrix; every live market
 * pinned where it is (teal ring = payouts available); a local payment leaves a market — labelled
 * with one of that market's real pay-in methods — and arcs into the USDT settlement ring.
 *
 * Light discipline: one key light from the upper left, a thin warm rim on the limb, no bloom.
 * The only bright things on screen are payments in motion.
 *
 * Colours are written in display (sRGB) values and the renderer outputs them untouched.
 */

const DEG = Math.PI / 180;
const FEATURED = new Set(['united-states', 'eurozone', 'united-kingdom', 'brazil', 'mexico', 'colombia', 'kenya', 'nigeria', 'philippines', 'malaysia', 'indonesia', 'south-africa', 'ghana', 'egypt', 'peru']);
const REST_YAW = 25 * DEG; // Atlantic-centred: Americas, Europe and Africa in view
const BASE_TILT = 0.3;
const ORBIT_R = 1.3;
const CAM_Z = 5.9;
const LIGHT = new THREE.Vector3(-0.55, 0.5, 0.67).normalize(); // view space

const ORANGE = [1.0, 0.6, 0.0];
const AMBER = [1.0, 0.77, 0.42];
const MINT = [0.43, 0.91, 0.72];

const toVec = (lat, lon, r = 1) => {
    const la = lat * DEG, lo = lon * DEG;
    return new THREE.Vector3(Math.cos(la) * Math.sin(lo) * r, Math.sin(la) * r, Math.cos(la) * Math.cos(lo) * r);
};
const easeOutExpo = (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const clamp01 = (v) => Math.min(1, Math.max(0, v));
const shortMethod = (method, market) => (method.startsWith(`${market.name.en} `) ? method.slice(market.name.en.length + 1) : method);

let maskBits = null;
function landAt(lat, lon) {
    if (!maskBits) {
        const bin = atob(LAND_HD_MASK);
        maskBits = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) maskBits[i] = bin.charCodeAt(i);
    }
    const r = Math.min(LAND_HD_H - 1, Math.floor(((90 - lat) / 180) * LAND_HD_H));
    const c = Math.min(LAND_HD_W - 1, Math.floor(((lon + 180) / 360) * LAND_HD_W));
    const i = r * LAND_HD_W + c;
    return (maskBits[i >> 3] >> (i & 7)) & 1;
}

// ---------------------------------------------------------------- shaders
const BODY_VS = /* glsl */`
varying vec3 vN;
void main() {
    vN = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;
const BODY_FS = /* glsl */`
uniform vec3 uLight;
varying vec3 vN;
void main() {
    vec3 n = normalize(vN);
    float diff = clamp(dot(n, uLight), 0.0, 1.0);
    vec3 base = mix(vec3(0.027, 0.026, 0.033), vec3(0.098, 0.078, 0.060), pow(diff, 1.6));
    float fres = pow(1.0 - clamp(n.z, 0.0, 1.0), 3.0);
    vec3 rim = vec3(1.0, 0.62, 0.28) * fres * (0.06 + 0.42 * diff);
    gl_FragColor = vec4(base + rim, 1.0);
}`;

const HALO_VS = BODY_VS;
const HALO_FS = /* glsl */`
uniform vec3 uLight;
uniform float uStrength;
varying vec3 vN;
void main() {
    vec3 n = normalize(vN);
    float i = pow(clamp(0.72 + n.z, 0.0, 1.0), 5.0); // back faces: brightest just outside the limb
    float lit = clamp(dot(-n, uLight) * 0.5 + 0.5, 0.0, 1.0);
    gl_FragColor = vec4(vec3(1.0, 0.58, 0.22) * i * uStrength * (0.25 + 0.75 * lit), 1.0);
}`;

const DOT_VS = /* glsl */`
uniform float uSize;
uniform float uReveal;
uniform vec3 uLight;
attribute float aRand;
varying float vAlpha;
varying float vLit;
void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vec3 n = normalize(normalMatrix * position);
    float facing = n.z;
    vLit = clamp(dot(n, uLight) * 0.5 + 0.5, 0.0, 1.0);
    float rev = smoothstep(aRand, aRand + 0.18, uReveal * 1.18);
    vAlpha = smoothstep(0.02, 0.5, facing) * rev;
    gl_PointSize = uSize * (0.7 + 0.3 * facing);
    gl_Position = projectionMatrix * mv;
}`;
const DOT_FS = /* glsl */`
varying float vAlpha;
varying float vLit;
void main() {
    float d = length(gl_PointCoord - 0.5);
    float a = smoothstep(0.5, 0.28, d);
    vec3 dark = vec3(0.20, 0.18, 0.17);
    vec3 lit = vec3(0.86, 0.80, 0.72);
    vec3 col = mix(dark, lit, pow(vLit, 1.7));
    gl_FragColor = vec4(col, a * vAlpha * (0.55 + 0.45 * vLit));
}`;

// Generic sprite: soft disc or thin ring, per-point colour/size/alpha (pins, beads, node, packet heads).
const SPRITE_VS = /* glsl */`
uniform float uDpr;
attribute vec3 aColor;
attribute float aSize;
attribute float aAlpha;
attribute float aRing;
varying vec3 vColor;
varying float vAlpha;
varying float vRing;
void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vColor = aColor; vAlpha = aAlpha; vRing = aRing;
    gl_PointSize = aSize * uDpr;
    gl_Position = projectionMatrix * mv;
}`;
const SPRITE_FS = /* glsl */`
varying vec3 vColor;
varying float vAlpha;
varying float vRing;
void main() {
    float d = length(gl_PointCoord - 0.5) * 2.0;
    float disc = smoothstep(1.0, 0.55, d);
    float ring = smoothstep(1.0, 0.86, d) - smoothstep(0.78, 0.64, d);
    float a = mix(disc, ring, vRing) * vAlpha;
    if (a < 0.003) discard;
    gl_FragColor = vec4(vColor, a);
}`;

/**
 * Light that adds onto whatever is behind the (transparent) canvas without writing alpha —
 * plain AdditiveBlending would also accumulate alpha and punch dark holes into the page.
 */
function addLight(mat) {
    Object.assign(mat, {
        blending: THREE.CustomBlending, blendEquation: THREE.AddEquation,
        blendSrc: THREE.SrcAlphaFactor, blendDst: THREE.OneFactor,
        blendSrcAlpha: THREE.ZeroFactor, blendDstAlpha: THREE.OneFactor,
    });
    return mat;
}

/** Points whose per-point attributes are rewritten every frame. */
function spriteLayer(count, dpr, { additive = false } = {}) {
    const geo = new THREE.BufferGeometry();
    const attrs = {
        position: new Float32Array(count * 3),
        aColor: new Float32Array(count * 3),
        aSize: new Float32Array(count),
        aAlpha: new Float32Array(count),
        aRing: new Float32Array(count),
    };
    for (const [k, arr] of Object.entries(attrs)) {
        const attr = new THREE.BufferAttribute(arr, k === 'position' || k === 'aColor' ? 3 : 1);
        attr.setUsage(THREE.DynamicDrawUsage);
        geo.setAttribute(k, attr);
    }
    const mat = new THREE.ShaderMaterial({
        vertexShader: SPRITE_VS, fragmentShader: SPRITE_FS,
        uniforms: { uDpr: { value: dpr } },
        transparent: true, depthWrite: false,
    });
    if (additive) addLight(mat);
    const points = new THREE.Points(geo, mat);
    points.frustumCulled = false;
    const set = (i, pos, color, size, alpha, ring = 0) => {
        attrs.position[i * 3] = pos.x; attrs.position[i * 3 + 1] = pos.y; attrs.position[i * 3 + 2] = pos.z;
        attrs.aColor[i * 3] = color[0]; attrs.aColor[i * 3 + 1] = color[1]; attrs.aColor[i * 3 + 2] = color[2];
        attrs.aSize[i] = size; attrs.aAlpha[i] = alpha; attrs.aRing[i] = ring;
    };
    const commit = () => { for (const k of Object.keys(attrs)) geo.attributes[k].needsUpdate = true; };
    const hideFrom = (i) => { for (let j = i; j < count; j++) attrs.aAlpha[j] = 0; };
    return { points, set, commit, hideFrom, mat, geo };
}

// ---------------------------------------------------------------- scene
export function createGlobeScene({ canvas, container, labelLayer, callbacks, nodeLabel = 'USDT' }) {
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const coarse = window.matchMedia?.('(pointer: coarse)').matches;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(dpr);
    renderer.outputColorSpace = THREE.LinearSRGBColorSpace; // colours below are already display values
    renderer.setClearColor(0x000000, 0);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 50);
    camera.position.set(0, 0, CAM_Z);

    // tilt (pitch) wraps yaw so the axis leans toward the viewer
    const tiltGroup = new THREE.Group();
    const globe = new THREE.Group();
    tiltGroup.add(globe);
    scene.add(tiltGroup);

    const disposables = [];
    const track = (...xs) => { disposables.push(...xs); return xs[0]; };

    // body
    const bodyGeo = track(new THREE.SphereGeometry(1, 128, 96));
    const bodyMat = track(new THREE.ShaderMaterial({ vertexShader: BODY_VS, fragmentShader: BODY_FS, uniforms: { uLight: { value: LIGHT } } }));
    globe.add(new THREE.Mesh(bodyGeo, bodyMat));

    // faint halo just outside the limb (separates the dark sphere from the dark page; not a glow)
    const haloMat = track(new THREE.ShaderMaterial({
        vertexShader: HALO_VS, fragmentShader: HALO_FS,
        uniforms: { uLight: { value: LIGHT }, uStrength: { value: 0.0 } },
        side: THREE.BackSide, transparent: true, depthWrite: false,
    }));
    addLight(haloMat);
    const halo = new THREE.Mesh(track(new THREE.SphereGeometry(1.09, 96, 64)), haloMat);
    tiltGroup.add(halo);

    // land dots
    const step = coarse ? 1.1 : 0.86;
    const pos = [];
    const rand = [];
    for (let lat = -57; lat <= 82; lat += step) {
        const n = Math.max(1, Math.round((360 * Math.cos(lat * DEG)) / step));
        for (let i = 0; i < n; i++) {
            const lon = -180 + ((i + 0.5) * 360) / n;
            if (!landAt(lat, lon)) continue;
            const v = toVec(lat, lon, 1.002);
            pos.push(v.x, v.y, v.z);
            // reveal sweeps west→east with a little noise: the network "comes online"
            rand.push(clamp01(((lon + 180) / 360) * 0.75 + Math.random() * 0.25));
        }
    }
    const dotGeo = track(new THREE.BufferGeometry());
    dotGeo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    dotGeo.setAttribute('aRand', new THREE.Float32BufferAttribute(rand, 1));
    const dotMat = track(new THREE.ShaderMaterial({
        vertexShader: DOT_VS, fragmentShader: DOT_FS,
        uniforms: { uSize: { value: (coarse ? 2.3 : 2.1) * dpr }, uReveal: { value: reduced ? 1 : 0 }, uLight: { value: LIGHT } },
        transparent: true, depthWrite: false,
    }));
    globe.add(new THREE.Points(dotGeo, dotMat));

    // market pins
    const PINS = MARKETS.filter((m) => MARKET_GEO[m.slug]).map((m) => {
        const [lat, lon] = MARKET_GEO[m.slug];
        return { market: m, lat, lon, local: toVec(lat, lon, 1.006), world: new THREE.Vector3(), facing: 0, payout: hasPayout(m), pulse: -1 };
    });
    const pinLayer = spriteLayer(PINS.length * 2, dpr);
    track(pinLayer.geo, pinLayer.mat);
    globe.add(pinLayer.points);

    // settlement orbit (fixed in world space; the globe turns inside it)
    const orbit = new THREE.Group();
    orbit.rotation.set(1.22, 0, -0.26);
    scene.add(orbit);
    const ORBIT_SEG = 160;
    const orbitPts = [];
    for (let i = 0; i <= ORBIT_SEG; i++) {
        const a = (i / ORBIT_SEG) * Math.PI * 2;
        orbitPts.push(Math.cos(a) * ORBIT_R, Math.sin(a) * ORBIT_R, 0);
    }
    const orbitGeo = track(new LineGeometry());
    orbitGeo.setPositions(orbitPts);
    const orbitMat = track(new LineMaterial({ linewidth: 1, transparent: true, opacity: 0, dashed: true, dashSize: 0.018, gapSize: 0.045, depthWrite: false }));
    orbitMat.color.setRGB(...AMBER);
    const orbitLine = new Line2(orbitGeo, orbitMat);
    orbitLine.computeLineDistances();
    orbit.add(orbitLine);
    scene.updateMatrixWorld(true);

    const orbitWorld = (a, out = new THREE.Vector3()) => out.set(Math.cos(a) * ORBIT_R, Math.sin(a) * ORBIT_R, 0).applyMatrix4(orbit.matrixWorld);
    // settlement node: the front-right point of the ring
    let NODE_A = 0, best = -Infinity;
    for (let i = 0; i < 360; i++) {
        const a = (i / 360) * Math.PI * 2;
        const p = orbitWorld(a);
        const score = p.z - 0.85 * p.x - 0.25 * p.y; // front-left, slightly low: stays on screen while the globe bleeds off the right edge
        if (score > best) { best = score; NODE_A = a; }
    }
    const NODE = orbitWorld(NODE_A);
    const fxLayer = spriteLayer(16, dpr, { additive: true });
    track(fxLayer.geo, fxLayer.mat);
    scene.add(fxLayer.points);

    // payment arcs
    const ARC_N = 56;
    const packets = [];
    const makeArc = () => {
        const geo = new LineGeometry();
        geo.setPositions(new Float32Array(ARC_N * 3));
        geo.setColors(new Float32Array(ARC_N * 3));
        const mat = addLight(new LineMaterial({ linewidth: coarse ? 1.6 : 1.8, vertexColors: true, transparent: true, depthWrite: false }));
        const line = new Line2(geo, mat);
        line.frustumCulled = false;
        return { geo, mat, line };
    };
    const arcPool = [makeArc(), makeArc(), makeArc()];
    arcPool.forEach((a) => { track(a.geo, a.mat); a.line.visible = false; scene.add(a.line); });
    const lineMats = [orbitMat, ...arcPool.map((a) => a.mat)];

    // ------------------------------------------------------------ labels (DOM overlay)
    const mkLabel = (cls) => { const el = document.createElement('div'); el.className = cls; labelLayer.appendChild(el); return el; };
    const nodeEl = mkLabel('absolute left-0 top-0 whitespace-nowrap rounded-md border border-[#6EE7B7]/25 bg-background/70 px-2 py-1 font-mono text-[10px] font-semibold tracking-wider text-[#6EE7B7] opacity-0 backdrop-blur-sm transition-opacity duration-700');
    nodeEl.textContent = nodeLabel;
    const labelPool = [0, 1, 2].map(() => mkLabel('absolute left-0 top-0 whitespace-nowrap rounded-full border border-white/10 bg-background/75 px-2.5 py-1 text-[11px] font-medium text-text-heading opacity-0 shadow-[0_8px_24px_-8px_rgba(0,0,0,0.9)] backdrop-blur-md transition-opacity duration-500'));

    // ------------------------------------------------------------ state
    let W = 1, H = 1;
    let yaw = REST_YAW;
    let pitch = 0;
    let yawVel = 0;
    let targetYaw = null, targetUntil = 0, pendingPin = null;
    let dragging = false, lastX = 0, lastY = 0, lastMoveT = 0;
    const pointer = { x: 0, y: 0, sx: 0, sy: 0 };
    const t0 = performance.now();
    let lastSpawn = t0 + 1400, lastPick = null;
    let nodePulse = -10;
    let running = false, inView = true, raf = 0, prev = t0;
    let needsRender = true;

    const project = (v) => {
        const p = v.clone().project(camera);
        return [(p.x * 0.5 + 0.5) * W, (-p.y * 0.5 + 0.5) * H];
    };
    const viewFacing = (worldPos) => {
        // >0 when the surface point faces the camera
        const toCam = camera.position.clone().sub(worldPos).normalize();
        return worldPos.clone().normalize().dot(toCam);
    };

    const launch = (pin, now) => {
        const arc = arcPool.find((a) => !a.line.visible);
        if (!arc) return;
        const list = pin.market.payin;
        const method = pin === pendingPin || Math.random() < 0.6 ? list[0] : list[Math.floor(Math.random() * list.length)];
        const evt = { market: pin.market, method };
        const label = labelPool.find((l) => !l.dataset.busy);
        if (label) { label.dataset.busy = '1'; label.textContent = `${shortMethod(method, pin.market)} · ${pin.market.currency}`; }
        arc.line.visible = true;
        packets.push({ pin, arc, label, t0: now, dur: 1900 + Math.random() * 500, evt, settled: false });
        pin.pulse = 0;
        lastPick = pin;
        callbacks.current?.onLaunch?.(evt);
    };

    // only markets whose label will be fully on screen (the globe bleeds off the right edge on desktop)
    const onScreen = (p) => {
        const [x] = project(p.world);
        const left = container.getBoundingClientRect().left;
        return left + x > 90 && left + x < window.innerWidth - 150;
    };
    const spawn = (now) => {
        const front = PINS.filter((p) => p.facing > 0.4 && p !== lastPick && onScreen(p));
        if (!front.length) return;
        const weighted = front.flatMap((p) => (FEATURED.has(p.market.slug) ? [p, p, p] : [p]));
        launch(weighted[Math.floor(Math.random() * weighted.length)], now);
    };

    const tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3(), tmpC = new THREE.Vector3(), tmpP = new THREE.Vector3();
    const updateArc = (pk, head) => {
        const start = tmpA.copy(pk.pin.world).multiplyScalar(1.004);
        const end = tmpB.copy(NODE);
        const dist = start.distanceTo(end);
        const mid = tmpC.copy(start).add(end).multiplyScalar(0.5);
        const ctrl = mid.normalize().multiplyScalar(Math.max(1.0, tmpP.copy(start).add(end).multiplyScalar(0.5).length()) + 0.22 + dist * 0.28);
        const posArr = pk.arc.geo.attributes.instanceStart.data.array;
        const colArr = pk.arc.geo.attributes.instanceColorStart.data.array;
        const tail = 0.42;
        let prevX = 0, prevY = 0, prevZ = 0, prevI = 0;
        for (let i = 0; i < ARC_N; i++) {
            const t = i / (ARC_N - 1), u = 1 - t;
            const x = u * u * start.x + 2 * u * t * ctrl.x + t * t * end.x;
            const y = u * u * start.y + 2 * u * t * ctrl.y + t * t * end.y;
            const z = u * u * start.z + 2 * u * t * ctrl.z + t * t * end.z;
            const inten = t <= head ? Math.pow(clamp01(1 - (head - t) / tail), 1.6) : 0;
            if (i > 0) {
                const k = (i - 1) * 6;
                posArr[k] = prevX; posArr[k + 1] = prevY; posArr[k + 2] = prevZ;
                posArr[k + 3] = x; posArr[k + 4] = y; posArr[k + 5] = z;
                colArr[k] = ORANGE[0] * prevI; colArr[k + 1] = ORANGE[1] * prevI; colArr[k + 2] = ORANGE[2] * prevI;
                colArr[k + 3] = ORANGE[0] * inten; colArr[k + 4] = ORANGE[1] * inten; colArr[k + 5] = ORANGE[2] * inten;
            }
            prevX = x; prevY = y; prevZ = z; prevI = inten;
            if (i === Math.min(ARC_N - 1, Math.round(clamp01(head) * (ARC_N - 1)))) pk.headPos = (pk.headPos || new THREE.Vector3()).set(x, y, z);
        }
        pk.arc.geo.attributes.instanceStart.data.needsUpdate = true;
        pk.arc.geo.attributes.instanceColorStart.data.needsUpdate = true;
    };

    // ------------------------------------------------------------ frame
    const frame = (now) => {
        const dt = Math.min(0.05, (now - prev) / 1000);
        prev = now;
        const intro = reduced ? 1 : easeOutExpo(clamp01((now - t0) / 2600));

        // rotation: intro spin-in → focus target → drag inertia → slow drift
        if (dragging) {
            // yaw follows the pointer directly
        } else if (targetYaw !== null) {
            yaw += (targetYaw - yaw) * (1 - Math.exp(-dt * 3.2));
            if (now > targetUntil) targetYaw = null;
        } else if (Math.abs(yawVel) > 0.0005) {
            yaw += yawVel * dt;
            yawVel *= Math.exp(-dt * 2.4);
        } else if (!reduced) {
            yaw += (coarse ? 0.035 : 0.045) * dt * intro;
        }
        const introYaw = reduced ? 0 : -1.25 * (1 - intro);
        if (!dragging) pitch *= Math.exp(-dt * 1.5);

        pointer.sx += (pointer.x - pointer.sx) * (1 - Math.exp(-dt * 2.5));
        pointer.sy += (pointer.y - pointer.sy) * (1 - Math.exp(-dt * 2.5));

        globe.rotation.y = yaw + introYaw; // spins in from the west and settles on the Atlantic
        tiltGroup.rotation.x = BASE_TILT + pitch + pointer.sy * 0.05;
        tiltGroup.rotation.y = pointer.sx * 0.06;
        camera.position.z = CAM_Z + (reduced ? 0 : 1.6 * (1 - intro));
        camera.position.x = pointer.sx * 0.08;
        camera.position.y = -pointer.sy * 0.06;
        camera.lookAt(0, 0, 0);
        scene.updateMatrixWorld();

        dotMat.uniforms.uReveal.value = reduced ? 1 : clamp01((now - t0 - 200) / 1900);
        haloMat.uniforms.uStrength.value = 0.3 * clamp01((now - t0 - 300) / 1500);
        orbitMat.opacity = 0.34 * (reduced ? 1 : clamp01((now - t0 - 1100) / 900));
        if (!reduced) orbitMat.dashOffset -= dt * 0.05;

        // pins
        for (let i = 0; i < PINS.length; i++) {
            const p = PINS[i];
            p.world.copy(p.local).applyMatrix4(globe.matrixWorld);
            p.facing = viewFacing(p.world);
        }
        const pinReveal = reduced ? 1 : clamp01((now - t0 - 1000) / 900);
        PINS.forEach((p, i) => {
            const vis = clamp01((p.facing - 0.05) / 0.35) * pinReveal;
            const lp = p.local;
            if (p.pulse >= 0) { p.pulse += dt / 1.3; if (p.pulse > 1) p.pulse = -1; }
            pinLayer.set(i * 2, lp, ORANGE, 5.5, vis);
            if (p.pulse >= 0) pinLayer.set(i * 2 + 1, lp, AMBER, 8 + p.pulse * 30, vis * (1 - p.pulse) * 0.9, 1);
            else pinLayer.set(i * 2 + 1, lp, [0.18, 0.83, 0.75], 11, p.payout ? vis * 0.85 : 0, 1);
        });
        pinLayer.commit();

        // focus: launch once the market has turned to face us
        if (pendingPin && pendingPin.facing > 0.75) { launch(pendingPin, now); pendingPin = null; }

        // packets
        if (!reduced && !dragging && now - lastSpawn > (coarse ? 3200 : 2600) && now - t0 > 2200) {
            lastSpawn = now + Math.random() * 600;
            spawn(now);
        }
        let fx = 0;
        for (let i = packets.length - 1; i >= 0; i--) {
            const pk = packets[i];
            const t = (now - pk.t0) / pk.dur;
            const head = easeInOut(clamp01(t)) + Math.max(0, t - 1) * 0.9; // after arrival the tail drains into the node
            updateArc(pk, head);
            if (t <= 1 && pk.headPos) fxLayer.set(fx++, pk.headPos, [1.0, 0.86, 0.62], 6, 0.95);
            if (pk.label) {
                const show = t < 0.85 && pk.pin.facing > 0.15;
                const [x, y] = project(pk.pin.world);
                pk.label.style.transform = `translate3d(${x}px, ${y - 30}px, 0) translateX(-50%)`;
                pk.label.style.opacity = show ? '1' : '0';
            }
            if (t >= 1 && !pk.settled) {
                pk.settled = true;
                nodePulse = now;
                callbacks.current?.onSettle?.(pk.evt);
            }
            if (head >= 1 + 0.45) {
                pk.arc.line.visible = false;
                if (pk.label) { pk.label.style.opacity = '0'; delete pk.label.dataset.busy; }
                packets.splice(i, 1);
            }
        }

        // settlement beads riding the ring + node
        const orbitIn = reduced ? 1 : clamp01((now - t0 - 1100) / 900);
        for (let k = 0; k < 4; k++) {
            const a = (reduced ? 0 : now * 0.00022) + (k * Math.PI) / 2;
            fxLayer.set(fx++, orbitWorld(a, tmpP), AMBER, 4, 0.75 * orbitIn);
        }
        const np = clamp01((now - nodePulse) / 900);
        fxLayer.set(fx++, NODE, MINT, 6.5, orbitIn);
        if (np < 1) fxLayer.set(fx++, NODE, MINT, 8 + np * 26, (1 - np) * 0.8, 1);
        fxLayer.hideFrom(fx);
        fxLayer.commit();

        const [nx, ny] = project(NODE);
        nodeEl.style.transform = `translate3d(${nx + 12}px, ${ny - 10}px, 0)`;
        nodeEl.style.opacity = orbitIn > 0.5 ? '1' : '0';

        renderer.render(scene, camera);
        needsRender = false;
    };

    const loop = (now) => {
        raf = requestAnimationFrame(loop);
        if (reduced && !needsRender && !dragging && Math.abs(yawVel) < 0.0005 && targetYaw === null) return;
        frame(now);
    };
    const start = () => {
        if (running || !inView || document.hidden) return;
        running = true;
        prev = performance.now();
        raf = requestAnimationFrame(loop);
    };
    const stop = () => { running = false; cancelAnimationFrame(raf); };

    // ------------------------------------------------------------ sizing & visibility
    const resize = () => {
        const r = container.getBoundingClientRect();
        W = Math.max(1, r.width); H = Math.max(1, r.height);
        renderer.setSize(W, H, false);
        camera.aspect = W / H;
        camera.updateProjectionMatrix();
        lineMats.forEach((mtl) => mtl.resolution.set(W, H));
        needsRender = true;
        if (!running) frame(performance.now());
    };
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    const io = new IntersectionObserver(([e]) => { inView = e.isIntersecting; inView ? start() : stop(); }, { rootMargin: '80px' });
    io.observe(container);
    const onVis = () => (document.hidden ? stop() : start());
    document.addEventListener('visibilitychange', onVis);

    // ------------------------------------------------------------ input
    const onDown = (e) => {
        dragging = true; targetYaw = null; pendingPin = null;
        lastX = e.clientX; lastY = e.clientY; lastMoveT = performance.now(); yawVel = 0;
        canvas.setPointerCapture?.(e.pointerId);
    };
    const onMove = (e) => {
        if (e.pointerType === 'mouse') {
            const r = container.getBoundingClientRect();
            pointer.x = ((e.clientX - r.left) / r.width - 0.5) * 2;
            pointer.y = ((e.clientY - r.top) / r.height - 0.5) * 2;
        }
        if (!dragging) return;
        const now = performance.now();
        const dx = e.clientX - lastX, dy = e.clientY - lastY;
        const k = 2.6 / Math.max(240, W);
        yaw += dx * k;
        pitch = Math.max(-0.35, Math.min(0.35, pitch + dy * k * 0.6));
        const dtm = Math.max(1, now - lastMoveT) / 1000;
        yawVel = (dx * k) / dtm * 0.5 + yawVel * 0.5;
        lastX = e.clientX; lastY = e.clientY; lastMoveT = now;
        needsRender = true;
    };
    const onUp = () => { dragging = false; if (performance.now() - lastMoveT > 80) yawVel = 0; };
    const onLeave = () => { pointer.x = 0; pointer.y = 0; };
    canvas.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerup', onUp);
    container.addEventListener('pointerleave', onLeave);

    resize();
    start();

    return {
        /** Turn a market to face the viewer, then send a payment from it. */
        focus(slug) {
            const pin = PINS.find((p) => p.market.slug === slug);
            if (!pin) return;
            let ty = -pin.lon * DEG;
            ty += Math.round((yaw - ty) / (Math.PI * 2)) * Math.PI * 2; // shortest way round
            targetYaw = ty;
            targetUntil = performance.now() + 4500;
            yawVel = 0;
            pendingPin = packets.some((pk) => pk.pin === pin) ? null : pin;
            needsRender = true;
        },
        dispose() {
            stop();
            ro.disconnect(); io.disconnect();
            document.removeEventListener('visibilitychange', onVis);
            canvas.removeEventListener('pointerdown', onDown);
            window.removeEventListener('pointermove', onMove);
            window.removeEventListener('pointerup', onUp);
            container.removeEventListener('pointerleave', onLeave);
            disposables.forEach((d) => d.dispose?.());
            [nodeEl, ...labelPool].forEach((el) => el.remove());
            renderer.dispose();
        },
    };
}
