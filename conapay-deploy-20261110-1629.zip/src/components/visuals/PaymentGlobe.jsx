import { useEffect, useRef } from 'react';
import { LAND_MASK, LAND_W, LAND_H } from '../../data/landmask';
import { MARKETS, MARKET_GEO, hasPayout } from '../../data/channels';

/**
 * ConaPay payment globe (canvas 2D, no dependencies).
 *
 *  - Land is drawn as a dot matrix from a Natural Earth bitmask.
 *  - Every live market is pinned at its real location (teal ring = payouts available).
 *  - A payment "packet" launches from a front-facing market, labelled with one of its real
 *    pay-in methods, and flies into the USDT settlement orbit — local collection → USDT settlement.
 *  - Drag to spin (inertia), otherwise slow auto-rotation. Pauses off-screen / in background tabs.
 *    prefers-reduced-motion renders one static frame.
 *
 * Props: onLaunch({ market, method }), onSettle({ market, method }) — used by the hero HUD cards.
 */

const DEG = Math.PI / 180;
const PINS = MARKETS.filter((m) => MARKET_GEO[m.slug]).map((m) => {
    const [lat, lon] = MARKET_GEO[m.slug];
    return { market: m, v: toVec(lat, lon), payout: hasPayout(m), phase: Math.random() * Math.PI * 2 };
});
// Markets whose first method is a recognisable brand get picked more often.
const FEATURED = new Set(['united-states', 'eurozone', 'united-kingdom', 'brazil', 'mexico', 'colombia', 'kenya', 'nigeria', 'philippines', 'malaysia', 'indonesia', 'south-africa', 'ghana', 'egypt', 'peru', 'united-states', 'united-kingdom']);

function toVec(lat, lon) {
    const la = lat * DEG;
    const lo = lon * DEG;
    return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
}

let maskBits = null;
function landAt(lat, lon) {
    if (!maskBits) {
        const bin = atob(LAND_MASK);
        maskBits = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) maskBits[i] = bin.charCodeAt(i);
    }
    const r = Math.min(LAND_H - 1, Math.floor(((90 - lat) / 180) * LAND_H));
    const c = Math.min(LAND_W - 1, Math.floor(((lon + 180) / 360) * LAND_W));
    const i = r * LAND_W + c;
    return (maskBits[i >> 3] >> (i & 7)) & 1;
}

function buildDots(step) {
    const out = [];
    for (let lat = -56; lat <= 80; lat += step) {
        const n = Math.max(1, Math.round((360 * Math.cos(lat * DEG)) / step));
        for (let i = 0; i < n; i++) {
            const lon = -180 + ((i + 0.5) * 360) / n;
            if (landAt(lat, lon)) out.push(...toVec(lat, lon));
        }
    }
    return new Float32Array(out);
}

/** "Nigeria Bank Transfer" -> "Bank Transfer" (the label already shows the currency). */
const shortMethod = (method, market) => {
    const prefix = `${market.name.en} `;
    return method.startsWith(prefix) ? method.slice(prefix.length) : method;
};

const PaymentGlobe = ({ className = '', onLaunch, onSettle }) => {
    const wrapRef = useRef(null);
    const canvasRef = useRef(null);
    const cbRef = useRef({ onLaunch, onSettle });
    cbRef.current = { onLaunch, onSettle };

    useEffect(() => {
        const wrap = wrapRef.current;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        const coarse = window.matchMedia?.('(pointer: coarse)').matches;

        let W = 0, H = 0, R = 0, cx = 0, cy = 0, dpr = 1;
        let dots = new Float32Array();
        let yaw = 25 * DEG; // Atlantic-centred: Americas + Africa + Europe in view
        let vel = 0;
        const tilt = 0.18;
        const AUTO = coarse ? -0.07 : -0.09; // rad/s
        let dragging = false, lastX = 0, lastT = 0;
        const packets = [];
        const labels = [];
        let nodePulse = -10;
        let lastSpawn = 0;
        let lastPick = null;
        let raf = 0, running = false, prev = 0;

        const resize = () => {
            const rect = wrap.getBoundingClientRect();
            W = rect.width; H = rect.height;
            dpr = Math.min(window.devicePixelRatio || 1, 2);
            canvas.width = Math.round(W * dpr);
            canvas.height = Math.round(H * dpr);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            R = Math.min(W, H) * 0.39;
            cx = W / 2; cy = H * 0.47;
            const step = W < 420 ? 2.3 : W < 600 ? 1.8 : 1.45;
            dots = buildDots(step);
            if (reduced || !running) draw(performance.now());
        };

        // rotate (yaw about Y, then tilt about X) and project orthographically
        const project = (x, y, z) => {
            const cs = Math.cos(yaw), sn = Math.sin(yaw);
            const x1 = x * cs + z * sn;
            const z1 = -x * sn + z * cs;
            const ct = Math.cos(tilt), st = Math.sin(tilt);
            const y2 = y * ct - z1 * st;
            const z2 = y * st + z1 * ct;
            return [cx + x1 * R, cy - y2 * R, z2];
        };

        // settlement orbit (screen-space ellipse around the globe)
        const ORX = () => R * 1.24, ORY = () => R * 0.3, OROT = -0.3;
        const orbitPt = (th) => {
            const ex = ORX() * Math.cos(th), ey = ORY() * Math.sin(th);
            const c = Math.cos(OROT), s = Math.sin(OROT);
            return [cx + ex * c - ey * s, cy + R * 0.12 + ex * s + ey * c];
        };
        const NODE_TH = 0.55;

        const spawn = (now) => {
            const front = PINS.filter((p) => project(...p.v)[2] > 0.35 && p !== lastPick);
            if (!front.length) return;
            const weighted = front.flatMap((p) => (FEATURED.has(p.market.slug) ? [p, p, p] : [p]));
            const pin = weighted[Math.floor(Math.random() * weighted.length)];
            lastPick = pin;
            const list = pin.market.payin;
            const method = Math.random() < 0.6 ? list[0] : list[Math.floor(Math.random() * list.length)];
            const evt = { market: pin.market, method };
            packets.push({ pin, t0: now, dur: 1700 + Math.random() * 500, evt, done: false });
            labels.push({ pin, t0: now, text: `${shortMethod(method, pin.market)} · ${pin.market.currency}` });
            cbRef.current.onLaunch?.(evt);
        };

        const drawOrbit = (now, front) => {
            ctx.save();
            ctx.beginPath();
            ctx.ellipse(cx, cy + R * 0.12, ORX(), ORY(), OROT, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2);
            ctx.strokeStyle = front ? 'rgba(255,170,60,0.55)' : 'rgba(255,170,60,0.16)';
            ctx.lineWidth = 1;
            ctx.setLineDash([2, 7]);
            ctx.lineDashOffset = reduced ? 0 : -now * 0.012;
            ctx.stroke();
            ctx.restore();
            // continuous settlement flow beads
            for (let k = 0; k < 4; k++) {
                const th = (reduced ? 0 : now * 0.00035) + (k * Math.PI) / 2;
                const isFront = Math.sin(th % (Math.PI * 2)) > 0;
                if (isFront !== front) continue;
                const [x, y] = orbitPt(th);
                ctx.beginPath();
                ctx.arc(x, y, front ? 2 : 1.4, 0, Math.PI * 2);
                ctx.fillStyle = front ? 'rgba(255,197,107,0.95)' : 'rgba(255,197,107,0.3)';
                ctx.fill();
            }
        };

        const draw = (now) => {
            ctx.clearRect(0, 0, W, H);
            if (!R) return;

            // back half of the orbit
            drawOrbit(now, false);

            // atmosphere glow + sphere body
            let g = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.25);
            g.addColorStop(0, 'rgba(255,140,0,0.16)');
            g.addColorStop(1, 'rgba(255,140,0,0)');
            ctx.fillStyle = g;
            ctx.beginPath(); ctx.arc(cx, cy, R * 1.25, 0, Math.PI * 2); ctx.fill();

            g = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
            g.addColorStop(0, '#1A1410');
            g.addColorStop(1, '#09090C');
            ctx.fillStyle = g;
            ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = 'rgba(255,153,0,0.28)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // land dots, bucketed by depth so we only switch fillStyle a few times
            const BUCKETS = 6;
            const paths = Array.from({ length: BUCKETS }, () => new Path2D());
            const back = new Path2D();
            const sz = W < 420 ? 1.6 : 1.9;
            const cs = Math.cos(yaw), sn = Math.sin(yaw), ct = Math.cos(tilt), st = Math.sin(tilt);
            for (let i = 0; i < dots.length; i += 3) {
                const x = dots[i], y = dots[i + 1], z = dots[i + 2];
                const x1 = x * cs + z * sn;
                const z1 = -x * sn + z * cs;
                const y2 = y * ct - z1 * st;
                const z2 = y * st + z1 * ct;
                const px = cx + x1 * R, py = cy - y2 * R;
                if (z2 > 0) {
                    paths[Math.min(BUCKETS - 1, Math.floor(z2 * BUCKETS))].rect(px - sz / 2, py - sz / 2, sz, sz);
                } else if (z2 > -0.55) {
                    back.rect(px - 0.5, py - 0.5, 1, 1);
                }
            }
            ctx.fillStyle = 'rgba(255,190,120,0.07)';
            ctx.fill(back);
            for (let b = 0; b < BUCKETS; b++) {
                ctx.fillStyle = `rgba(255,${180 + b * 6},${110 + b * 12},${0.2 + (b / (BUCKETS - 1)) * 0.7})`;
                ctx.fill(paths[b]);
            }

            // market pins
            const t = now / 1000;
            for (const p of PINS) {
                const [x, y, z] = project(...p.v);
                p.sx = x; p.sy = y; p.z = z;
                if (z <= 0.05) continue;
                const a = Math.min(1, z * 1.6);
                if (!reduced) {
                    const ph = ((t * 0.6 + p.phase) % 1.6) / 1.6;
                    ctx.beginPath();
                    ctx.arc(x, y, 3 + ph * 11, 0, Math.PI * 2);
                    ctx.strokeStyle = `rgba(255,153,0,${(1 - ph) * 0.45 * a})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
                if (p.payout) {
                    ctx.beginPath();
                    ctx.arc(x, y, 4.6, 0, Math.PI * 2);
                    ctx.strokeStyle = `rgba(45,212,191,${0.85 * a})`;
                    ctx.lineWidth = 1.2;
                    ctx.stroke();
                }
                ctx.beginPath();
                ctx.arc(x, y, 2.4, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(255,170,40,${a})`;
                ctx.fill();
            }

            // packets: pin -> USDT node
            const [nx, ny] = orbitPt(NODE_TH);
            for (let i = packets.length - 1; i >= 0; i--) {
                const pk = packets[i];
                const k = (now - pk.t0) / pk.dur;
                if (k >= 1) {
                    if (!pk.done) { pk.done = true; nodePulse = now; cbRef.current.onSettle?.(pk.evt); }
                    packets.splice(i, 1);
                    continue;
                }
                const sx = pk.pin.sx, sy = pk.pin.sy;
                // control point: lift outward from the globe centre
                const dx = sx - cx, dy = sy - cy;
                const len = Math.hypot(dx, dy) || 1;
                const qx = (sx + nx) / 2 + (dx / len) * R * 0.55;
                const qy = (sy + ny) / 2 + (dy / len) * R * 0.55 - R * 0.25;
                const pt = (u) => [(1 - u) * (1 - u) * sx + 2 * (1 - u) * u * qx + u * u * nx, (1 - u) * (1 - u) * sy + 2 * (1 - u) * u * qy + u * u * ny];
                const e = 1 - Math.pow(1 - k, 2.2); // ease-out
                const tail = Math.max(0, e - 0.32);
                const SEG = 16;
                for (let s = 0; s < SEG; s++) {
                    const u0 = tail + ((e - tail) * s) / SEG;
                    const u1 = tail + ((e - tail) * (s + 1)) / SEG;
                    const [x0, y0] = pt(u0); const [x1, y1] = pt(u1);
                    ctx.beginPath();
                    ctx.moveTo(x0, y0); ctx.lineTo(x1, y1);
                    ctx.strokeStyle = `rgba(255,${150 + s * 4},${40 + s * 5},${(s / SEG) * 0.9})`;
                    ctx.lineWidth = 0.6 + (s / SEG) * 1.6;
                    ctx.stroke();
                }
                const [hx, hy] = pt(e);
                const hg = ctx.createRadialGradient(hx, hy, 0, hx, hy, 9);
                hg.addColorStop(0, 'rgba(255,230,180,1)');
                hg.addColorStop(0.35, 'rgba(255,153,0,0.6)');
                hg.addColorStop(1, 'rgba(255,153,0,0)');
                ctx.fillStyle = hg;
                ctx.beginPath(); ctx.arc(hx, hy, 9, 0, Math.PI * 2); ctx.fill();
            }

            // front half of the orbit (over the globe)
            drawOrbit(now, true);

            // USDT settlement node
            const pulse = Math.max(0, 1 - (now - nodePulse) / 700);
            const ng = ctx.createRadialGradient(nx, ny, 0, nx, ny, 30 + pulse * 18);
            ng.addColorStop(0, `rgba(38,161,123,${0.35 + pulse * 0.4})`);
            ng.addColorStop(1, 'rgba(38,161,123,0)');
            ctx.fillStyle = ng;
            ctx.beginPath(); ctx.arc(nx, ny, 30 + pulse * 18, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath();
            for (let s = 0; s < 6; s++) {
                const a = Math.PI / 6 + (s * Math.PI) / 3;
                const hr = 15 + pulse * 2;
                ctx[s ? 'lineTo' : 'moveTo'](nx + hr * Math.cos(a), ny + hr * Math.sin(a));
            }
            ctx.closePath();
            ctx.fillStyle = '#0B1A15';
            ctx.fill();
            ctx.strokeStyle = `rgba(52,211,153,${0.7 + pulse * 0.3})`;
            ctx.lineWidth = 1.3;
            ctx.stroke();
            ctx.fillStyle = '#E8FFF6';
            ctx.font = '700 8.5px Inter, system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('USDT', nx, ny + 0.5);

            // method labels next to launching pins
            ctx.font = '600 11px Inter, system-ui, sans-serif';
            ctx.textAlign = 'left';
            for (let i = labels.length - 1; i >= 0; i--) {
                const lb = labels[i];
                const age = (now - lb.t0) / 2200;
                if (age >= 1 || lb.pin.z < 0.05) { labels.splice(i, 1); continue; }
                const alpha = Math.min(1, age * 6) * Math.min(1, (1 - age) * 4);
                const tw = ctx.measureText(lb.text).width;
                const bw = tw + 16;
                const flip = lb.pin.sx + 10 + bw > W - 4; // keep the pill inside the canvas
                const lx = flip ? lb.pin.sx - 10 - bw : lb.pin.sx + 10, ly = lb.pin.sy - 24 - age * 6;
                ctx.globalAlpha = alpha;
                ctx.beginPath();
                ctx.roundRect ? ctx.roundRect(lx, ly, bw, 20, 10) : ctx.rect(lx, ly, bw, 20);
                ctx.fillStyle = 'rgba(14,14,19,0.92)';
                ctx.fill();
                ctx.strokeStyle = 'rgba(255,153,0,0.55)';
                ctx.lineWidth = 1;
                ctx.stroke();
                ctx.beginPath(); ctx.moveTo(lb.pin.sx + (flip ? -2 : 2), lb.pin.sy - 2); ctx.lineTo(flip ? lx + bw - 6 : lx + 6, ly + 20);
                ctx.stroke();
                ctx.fillStyle = '#FFE2B8';
                ctx.textBaseline = 'middle';
                ctx.fillText(lb.text, lx + 8, ly + 10.5);
                ctx.globalAlpha = 1;
            }
        };

        const frame = (now) => {
            const dt = Math.min(0.05, (now - (prev || now)) / 1000);
            prev = now;
            if (!dragging) {
                vel *= Math.pow(0.04, dt); // inertia decay
                yaw += (AUTO + vel) * dt;
            }
            if (now - lastSpawn > 1500) { lastSpawn = now; spawn(now); }
            draw(now);
            if (running) raf = requestAnimationFrame(frame);
        };

        const start = () => { if (running || reduced) return; running = true; prev = 0; raf = requestAnimationFrame(frame); };
        const stop = () => { running = false; cancelAnimationFrame(raf); };

        // drag to spin (horizontal only, so vertical page scroll still works on touch)
        const onDown = (e) => { dragging = true; lastX = e.clientX; lastT = performance.now(); vel = 0; canvas.setPointerCapture?.(e.pointerId); };
        const onMove = (e) => {
            if (!dragging) return;
            const now = performance.now();
            const d = ((e.clientX - lastX) / R) * 0.9;
            yaw += d;
            vel = (d / Math.max(16, now - lastT)) * 1000 - AUTO;
            lastX = e.clientX; lastT = now;
            if (reduced) draw(now);
        };
        const onUp = () => { dragging = false; };
        canvas.addEventListener('pointerdown', onDown);
        canvas.addEventListener('pointermove', onMove);
        canvas.addEventListener('pointerup', onUp);
        canvas.addEventListener('pointercancel', onUp);

        const ro = new ResizeObserver(resize);
        ro.observe(wrap);
        resize();

        const io = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting && document.visibilityState === 'visible') start(); else stop();
        }, { threshold: 0.05 });
        io.observe(wrap);
        const onVis = () => (document.visibilityState === 'visible' ? start() : stop());
        document.addEventListener('visibilitychange', onVis);

        return () => {
            stop();
            ro.disconnect();
            io.disconnect();
            document.removeEventListener('visibilitychange', onVis);
            canvas.removeEventListener('pointerdown', onDown);
            canvas.removeEventListener('pointermove', onMove);
            canvas.removeEventListener('pointerup', onUp);
            canvas.removeEventListener('pointercancel', onUp);
        };
    }, []);

    return (
        <div ref={wrapRef} className={`relative ${className}`}>
            <canvas ref={canvasRef} aria-hidden="true" className="absolute inset-0 h-full w-full cursor-grab touch-pan-y active:cursor-grabbing" />
        </div>
    );
};

export default PaymentGlobe;
