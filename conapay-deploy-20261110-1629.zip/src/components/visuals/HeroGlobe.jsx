import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import PaymentGlobe from './PaymentGlobe';

const hasWebGL = () => {
    try {
        const c = document.createElement('canvas');
        return !!(c.getContext('webgl2') || c.getContext('webgl'));
    } catch {
        return false;
    }
};

/**
 * Hero globe: three.js scene, code-split and loaded after first paint (the H1 is the LCP, not this).
 * Falls back to the dependency-free canvas globe when WebGL is unavailable or the chunk fails.
 * ref.focus(slug) turns a market toward the viewer and sends a payment from it.
 */
const HeroGlobe = forwardRef(({ className = '', onLaunch, onSettle, nodeLabel }, ref) => {
    const wrapRef = useRef(null);
    const canvasRef = useRef(null);
    const labelRef = useRef(null);
    const apiRef = useRef(null);
    const cbRef = useRef({ onLaunch, onSettle });
    useEffect(() => { cbRef.current = { onLaunch, onSettle }; }, [onLaunch, onSettle]);
    const [mode, setMode] = useState('webgl');
    const [ready, setReady] = useState(false);

    useImperativeHandle(ref, () => ({ focus: (slug) => apiRef.current?.focus(slug) }), []);

    useEffect(() => {
        if (!hasWebGL()) { setMode('fallback'); return undefined; }
        let disposed = false;
        import('./globe3d/createGlobeScene')
            .then(({ createGlobeScene }) => {
                if (disposed || !canvasRef.current) return;
                apiRef.current = createGlobeScene({
                    canvas: canvasRef.current, container: wrapRef.current, labelLayer: labelRef.current, callbacks: cbRef, nodeLabel,
                });
                requestAnimationFrame(() => !disposed && setReady(true));
            })
            .catch((err) => {
                console.warn('[HeroGlobe] falling back to 2D', err);
                if (!disposed) setMode('fallback');
            });
        return () => {
            disposed = true;
            apiRef.current?.dispose();
            apiRef.current = null;
        };
    }, [nodeLabel]);

    if (mode === 'fallback') return <PaymentGlobe className={className} onLaunch={onLaunch} onSettle={onSettle} />;

    return (
        <div ref={wrapRef} className={`relative ${className}`}>
            <canvas ref={canvasRef} aria-hidden="true"
                className={`absolute inset-0 h-full w-full cursor-grab touch-pan-y transition-opacity duration-[1400ms] ease-out active:cursor-grabbing ${ready ? 'opacity-100' : 'opacity-0'}`} />
            <div ref={labelRef} className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true" />
        </div>
    );
});

HeroGlobe.displayName = 'HeroGlobe';
export default HeroGlobe;
