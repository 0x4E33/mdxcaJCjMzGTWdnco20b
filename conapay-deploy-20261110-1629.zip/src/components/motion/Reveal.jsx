import { useRef } from 'react';
import { m, useReducedMotion, useScroll, useTransform } from 'framer-motion';

/**
 * Site-wide motion vocabulary.
 *
 *  <Reveal>           – fades/rises in once, the first time it enters the viewport (IntersectionObserver,
 *                       so it never waits for a scroll event: content visible on load simply settles in).
 *  <Reveal index={i}> – siblings follow a beat later (max 3 steps), so a row reads as one gesture.
 *  <ParallaxImage>    – photo settles from a slight zoom while it crosses the viewport.
 *
 * Tokens live here so every page moves the same way.
 */
const EASE_OUT = [0.22, 1, 0.36, 1];

export const Reveal = ({ as = 'div', index = 0, y = 14, className, children, ...rest }) => {
    const reduced = useReducedMotion();
    const Tag = m[as];
    if (reduced) return <Tag className={className} {...rest}>{children}</Tag>;
    return (
        <Tag
            className={className}
            initial={{ opacity: 0, y }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.12 }}
            transition={{ duration: 0.8, delay: Math.min(index, 3) * 0.07, ease: EASE_OUT }}
            {...rest}
        >
            {children}
        </Tag>
    );
};

export const ParallaxImage = ({ src, alt = '', className = '', imgClassName = '', zoom = 0.08, children }) => {
    const ref = useRef(null);
    const reduced = useReducedMotion();
    const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
    const scale = useTransform(scrollYProgress, [0, 0.5], [1 + zoom, 1]);
    const y = useTransform(scrollYProgress, [0, 1], ['-3%', '3%']);
    return (
        <div ref={ref} className={`relative overflow-hidden ${className}`}>
            <m.img src={src} alt={alt} loading="lazy" decoding="async"
                style={reduced ? undefined : { scale, y }}
                className={`absolute inset-0 h-[106%] w-full object-cover ${imgClassName}`} />
            {children}
        </div>
    );
};
