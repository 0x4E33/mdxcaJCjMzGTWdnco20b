import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AnimatePresence, m as motion } from 'framer-motion';
import { Send, ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const TELEGRAM = 'https://t.me/ConaPayRicky';

/**
 * Phones/tablets only: a slim contact bar pinned to the bottom once the visitor scrolls past the first screen.
 * Hidden on the contact page itself.
 */
const MobileContactBar = () => {
    const { t } = useTranslation();
    const { pathname } = useLocation();
    const [show, setShow] = useState(false);

    useEffect(() => {
        const onScroll = () => setShow(window.scrollY > window.innerHeight * 0.8);
        onScroll();
        window.addEventListener('scroll', onScroll, { passive: true });
        return () => window.removeEventListener('scroll', onScroll);
    }, [pathname]);

    if (pathname.startsWith('/contact')) return null;

    return (
        <AnimatePresence>
            {show && (
                <motion.div
                    initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }} transition={{ type: 'spring', damping: 28, stiffness: 300 }}
                    className="fixed inset-x-0 bottom-0 z-40 border-t border-white/[0.08] bg-background/90 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-xl lg:hidden"
                >
                    <div className="mx-auto flex max-w-lg gap-2.5">
                        <a href={TELEGRAM} target="_blank" rel="noopener noreferrer" aria-label="Telegram"
                            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#229ED9] text-white">
                            <Send size={20} className="-ml-0.5" />
                        </a>
                        <Link to="/contact" className="btn-primary h-12 flex-1 py-0 text-[15px]">
                            {t('nav.contact')} <ArrowRight size={17} />
                        </Link>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default MobileContactBar;
