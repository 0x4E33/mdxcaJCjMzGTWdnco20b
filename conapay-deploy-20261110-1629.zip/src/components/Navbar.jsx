import { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, ArrowRight, Globe, Check } from 'lucide-react';
import { m as motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import logoMark from '../assets/logo-mark.png';

const LANGS = [
    { code: 'en', label: 'English', short: 'EN' },
    { code: 'zh', label: '简体中文', short: '中文' },
];

/**
 * Flat navigation: every destination is a real <a> in the prerendered HTML (crawlable,
 * descriptive anchor text) and there are no hover panels that can cover other controls.
 */
const Navbar = () => {
    const { t, i18n } = useTranslation();
    const { pathname, hash } = useLocation();
    const [scrolled, setScrolled] = useState(false);
    const [mobileOpen, setMobileOpen] = useState(false);
    const [langOpen, setLangOpen] = useState(false);
    const [hovered, setHovered] = useState(null);
    const langRef = useRef(null);
    const isZh = i18n.language?.startsWith('zh');
    const current = LANGS[isZh ? 1 : 0];

    const links = [
        { to: '/#coverage', label: t('nav.globalCoverage'), active: (pathname === '/' && hash === '#coverage') || pathname.startsWith('/payment-methods') },
        { to: '/industries', label: t('nav.solutions') },
        { to: '/capabilities', label: t('nav.capabilities') },
        { to: '/developers', label: t('nav.developers') },
        { to: '/about', label: t('nav.about') },
    ].map((l) => ({ ...l, active: l.active ?? pathname.startsWith(l.to) }));

    useEffect(() => {
        const onScroll = () => setScrolled(window.scrollY > 20);
        onScroll();
        window.addEventListener('scroll', onScroll, { passive: true });
        return () => window.removeEventListener('scroll', onScroll);
    }, []);

    useEffect(() => {
        setMobileOpen(false);
        setLangOpen(false);
    }, [pathname, hash]);

    // Close the language menu on outside click / Escape
    useEffect(() => {
        if (!langOpen) return;
        const onDown = (e) => { if (!langRef.current?.contains(e.target)) setLangOpen(false); };
        const onKey = (e) => { if (e.key === 'Escape') setLangOpen(false); };
        document.addEventListener('pointerdown', onDown);
        document.addEventListener('keydown', onKey);
        return () => { document.removeEventListener('pointerdown', onDown); document.removeEventListener('keydown', onKey); };
    }, [langOpen]);

    useEffect(() => {
        document.body.style.overflow = mobileOpen ? 'hidden' : '';
        return () => { document.body.style.overflow = ''; };
    }, [mobileOpen]);

    const changeLanguage = (code) => {
        i18n.changeLanguage(code);
        setLangOpen(false);
        setMobileOpen(false);
    };

    const solid = scrolled || mobileOpen;

    return (
        <nav className={`fixed inset-x-0 top-0 z-50 border-b transition-all duration-300 ${solid ? 'border-white/[0.07] bg-background/80 shadow-[0_10px_40px_-20px_rgba(0,0,0,0.9)] backdrop-blur-xl' : 'border-transparent bg-transparent'}`}>
            <div className="container mx-auto flex h-20 items-center justify-between gap-6 px-5">
                <Link to="/" className="flex shrink-0 items-center gap-2.5" aria-label="ConaPay home">
                    <img src={logoMark} alt="" width="27" height="32" className="h-8 w-auto" />
                    <span className="font-display text-xl font-bold tracking-tight text-white">Cona<span className="text-primary">Pay</span></span>
                </Link>

                {/* Desktop links with a sliding hover pill */}
                <ul className="hidden items-center lg:flex" onMouseLeave={() => setHovered(null)}>
                    {links.map((l) => (
                        <li key={l.to} className="relative">
                            <Link
                                to={l.to}
                                onMouseEnter={() => setHovered(l.to)}
                                aria-current={l.active ? 'page' : undefined}
                                className={`relative z-10 block whitespace-nowrap px-3.5 py-2 text-[15px] font-medium transition-colors xl:px-4 ${l.active ? 'text-white' : 'text-text-body hover:text-white'}`}
                            >
                                {l.label}
                            </Link>
                            {hovered === l.to && (
                                <motion.span layoutId="nav-pill" transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                                    className="absolute inset-0 rounded-full bg-white/[0.07]" />
                            )}
                            {l.active && <span className="absolute inset-x-4 -bottom-[3px] h-px bg-gradient-to-r from-transparent via-primary to-transparent" />}
                        </li>
                    ))}
                </ul>

                <div className="hidden shrink-0 items-center gap-3 lg:flex">
                    {/* Language: click or hover; sits above everything else in the bar */}
                    <div ref={langRef} className="relative z-[60]" onMouseEnter={() => setLangOpen(true)} onMouseLeave={() => setLangOpen(false)}>
                        <button
                            type="button"
                            aria-haspopup="listbox"
                            aria-expanded={langOpen}
                            aria-label={t('nav.language')}
                            onClick={() => setLangOpen(true)}
                            className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-medium text-text-body transition-colors hover:bg-white/[0.06] hover:text-white"
                        >
                            <Globe size={16} />
                            <span>{current.short}</span>
                            <ChevronDown size={12} className={`transition-transform duration-200 ${langOpen ? 'rotate-180' : ''}`} />
                        </button>
                        <AnimatePresence>
                            {langOpen && (
                                <motion.div
                                    initial={{ opacity: 0, y: -6, scale: 0.97 }}
                                    animate={{ opacity: 1, y: 0, scale: 1 }}
                                    exit={{ opacity: 0, y: -6, scale: 0.97 }}
                                    transition={{ duration: 0.16 }}
                                    className="absolute right-0 top-full pt-2"
                                >
                                    <ul role="listbox" className="w-40 rounded-xl border border-white/10 bg-surface-2/95 p-1.5 shadow-2xl backdrop-blur-xl">
                                        {LANGS.map((l) => (
                                            <li key={l.code}>
                                                <button
                                                    type="button"
                                                    role="option"
                                                    aria-selected={current.code === l.code}
                                                    onClick={() => changeLanguage(l.code)}
                                                    className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors ${current.code === l.code ? 'bg-white/[0.06] text-white' : 'text-text-body hover:bg-white/[0.06] hover:text-white'}`}
                                                >
                                                    {l.label}
                                                    {current.code === l.code && <Check size={14} className="text-primary" />}
                                                </button>
                                            </li>
                                        ))}
                                    </ul>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>

                    <a href="https://conapay.global" target="_blank" rel="noopener noreferrer"
                        className="hidden rounded-full border border-white/10 bg-white/5 px-5 py-2.5 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-300 hover:bg-white/10 xl:inline-flex">
                        {t('nav.portal')}
                    </a>

                    <Link to="/contact" className="btn-primary px-5 py-2.5 text-sm">
                        {t('nav.contact')} <ArrowRight size={14} />
                    </Link>
                </div>

                <button className="p-2 text-white lg:hidden" aria-label="Menu" aria-expanded={mobileOpen} onClick={() => setMobileOpen((v) => !v)}>
                    {mobileOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </div>

            {/* Mobile menu */}
            <AnimatePresence>
                {mobileOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -12 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -12 }}
                        transition={{ duration: 0.2 }}
                        className="absolute inset-x-0 top-full flex h-[calc(100dvh-5rem)] flex-col gap-6 overflow-y-auto border-t border-white/[0.07] bg-background px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-4 lg:hidden"
                    >
                        <ul className="flex flex-col">
                            {links.map((l, i) => (
                                <motion.li key={l.to} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.03 * i }}>
                                    <Link to={l.to} className={`flex items-center justify-between border-b border-white/[0.06] py-4 text-lg font-medium ${l.active ? 'text-primary' : 'text-text-heading'}`}>
                                        {l.label}
                                        <ArrowRight size={16} className="text-text-muted" />
                                    </Link>
                                </motion.li>
                            ))}
                        </ul>

                        <div className="flex items-center gap-2" role="group" aria-label={t('nav.language')}>
                            <Globe size={16} className="text-text-muted" />
                            {LANGS.map((l) => (
                                <button key={l.code} type="button" onClick={() => changeLanguage(l.code)}
                                    className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${current.code === l.code ? 'bg-primary/15 text-primary ring-1 ring-primary/40' : 'text-text-body ring-1 ring-white/10'}`}>
                                    {l.label}
                                </button>
                            ))}
                        </div>

                        <div className="flex flex-col gap-3">
                            <a href="https://conapay.global" target="_blank" rel="noopener noreferrer"
                                className="w-full rounded-full border border-white/10 bg-white/5 px-5 py-3 text-center text-sm font-semibold text-white">
                                {t('nav.portal')}
                            </a>
                            <Link to="/contact" className="btn-primary w-full py-3 text-sm">{t('nav.contact')}</Link>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </nav>
    );
};

export default Navbar;
