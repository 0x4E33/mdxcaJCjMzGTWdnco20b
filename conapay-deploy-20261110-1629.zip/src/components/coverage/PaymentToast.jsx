import { Check, ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { MethodIcon } from './shared';

// Illustrative ticket sizes (roughly USD 30–60) so the toast reads naturally in each local currency.
const SAMPLE = {
    USD: 49.9, EUR: 45, GBP: 39, AED: 180, MXN: 850, BRL: 250, COP: 200000, PEN: 180, CLP: 45000, CRC: 25000,
    GTQ: 380, PHP: 2800, MYR: 220, IDR: 750000, NGN: 75000, KES: 6500, ZAR: 900, EGP: 2400, GHS: 600,
    TZS: 125000, UGX: 180000, RWF: 65000, XOF: 30000, XAF: 30000, ZMW: 1300, MAD: 500, DZD: 6700, GNF: 430000,
};

const formatAmount = (currency, lang) => {
    if (currency === 'USDT') return '50.00 USDT';
    const value = SAMPLE[currency];
    if (value == null) return null;
    try {
        return new Intl.NumberFormat(lang?.startsWith('zh') ? 'zh-CN' : 'en-US', {
            style: 'currency', currency, maximumFractionDigits: value >= 1000 ? 0 : 2,
        }).format(value);
    } catch {
        return `${value.toLocaleString()} ${currency}`;
    }
};

const shortMethod = (method, market) => method.replace(new RegExp(`^(${market.name.en}|${market.currency}) `), '');

/**
 * Header accent on market pages: a "payment received" notification in the market's own currency,
 * through its first local method, settling to USDT. Marked as an example — it is illustrative, not live data.
 */
const PaymentToast = ({ market, className = '' }) => {
    const { t, i18n } = useTranslation();
    const method = market.payin[0];
    const amount = formatAmount(market.currency, i18n.language);
    return (
        <div aria-hidden="true" className={`w-[300px] rounded-2xl border border-white/10 bg-surface/80 p-4 shadow-[0_30px_60px_-24px_rgba(0,0,0,0.95)] backdrop-blur-xl ${className}`}>
            <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#34D399]">
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#34D399]/15"><Check size={10} strokeWidth={3} /></span>
                    {t('coverage.toast.received')}
                </span>
                <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] text-text-muted">{t('coverage.toast.example')}</span>
            </div>
            <div className="mt-3 flex items-center gap-3">
                <MethodIcon method={method} size={26} />
                <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-white">{shortMethod(method, market)}</p>
                    <p className="text-[11px] text-text-muted">{market.currency}</p>
                </div>
                {amount && <span className="font-mono text-base font-semibold text-white">{amount}</span>}
            </div>
            <div className="mt-3 flex items-center gap-1.5 border-t border-white/[0.06] pt-3 text-[11px] text-text-muted">
                {market.currency} <ArrowRight size={11} /> <span className="font-semibold text-[#6EE7B7]">USDT</span>
                <span className="ml-auto">{t('coverage.toast.settles')}</span>
            </div>
        </div>
    );
};

export default PaymentToast;
