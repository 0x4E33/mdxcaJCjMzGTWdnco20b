/**
 * Build-time prerender: turns the SPA into crawlable static HTML.
 *
 *   1. `vite build`                         -> dist/ (client bundle + index.html template)
 *   2. `vite build --ssr src/entry-server`  -> dist-ssr/entry-server.js
 *   3. this script renders every route into dist/<route>/index.html with its own
 *      <title>, meta description, canonical, Open Graph and JSON-LD, then writes
 *      sitemap.xml and llms.txt from the same channel data.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const ssrDir = path.join(root, 'dist-ssr');

const { render, getSeo, PRERENDER_ROUTES, MARKETS, REGIONS, COVERAGE_STATS, SITE_URL, hasPayout } =
    await import(pathToFileURL(path.join(ssrDir, 'entry-server.js')).href);

const template = await fs.readFile(path.join(dist, 'index.html'), 'utf8');

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const withHead = (html, seo) => {
    const jsonLd = seo.jsonLd
        .map((obj) => `<script type="application/ld+json">${JSON.stringify(obj).replace(/</g, '\\u003c')}</script>`)
        .join('\n    ');
    return html
        .replace(/<title>[\s\S]*?<\/title>/, `<title>${esc(seo.title)}</title>`)
        .replace(/(<meta name="description" content=")[^"]*(")/, `$1${esc(seo.description)}$2`)
        .replace(/(<meta property="og:title" content=")[^"]*(")/, `$1${esc(seo.title)}$2`)
        .replace(/(<meta property="og:description" content=")[^"]*(")/, `$1${esc(seo.description)}$2`)
        .replace(/(<meta property="og:url" content=")[^"]*(")/, `$1${esc(seo.canonical)}$2`)
        .replace(/(<meta name="twitter:title" content=")[^"]*(")/, `$1${esc(seo.title)}$2`)
        .replace(/(<meta name="twitter:description" content=")[^"]*(")/, `$1${esc(seo.description)}$2`)
        .replace(/(<link rel="canonical" href=")[^"]*(")/, `$1${esc(seo.canonical)}$2`)
        .replace('</head>', `    ${jsonLd}\n  </head>`);
};

const writeCompressed = async (file, content) => {
    await fs.mkdir(path.dirname(file), { recursive: true });
    await fs.writeFile(file, content);
    await fs.writeFile(`${file}.gz`, zlib.gzipSync(content, { level: 9 }));
    await fs.writeFile(`${file}.br`, zlib.brotliCompressSync(content));
};

let count = 0;
for (const route of PRERENDER_ROUTES) {
    const appHtml = await render(route);
    const html = withHead(template, getSeo(route, 'en'))
        .replace('<div id="root"></div>', `<div id="root" data-route="${route}">${appHtml}</div>`);
    const out = route === '/' ? path.join(dist, 'index.html') : path.join(dist, route.slice(1), 'index.html');
    await writeCompressed(out, html);
    count++;
}

// Legacy URL: /network -> home coverage section (nginx also 301s this; this is the fallback).
await writeCompressed(path.join(dist, 'network', 'index.html'),
    `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Payment coverage | ConaPay</title>` +
    `<link rel="canonical" href="${SITE_URL}/"><meta name="robots" content="noindex,follow">` +
    `<meta http-equiv="refresh" content="0; url=/#coverage"></head><body><a href="/#coverage">Payment coverage</a></body></html>`);

// ---------- sitemap.xml ----------
const today = new Date().toISOString().slice(0, 10);
const priority = (r) => (r === '/' ? '1.0' : r.startsWith('/payment-methods/') ? '0.9' : '0.6');
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${PRERENDER_ROUTES.map((r) => `  <url><loc>${SITE_URL}${r}</loc><lastmod>${today}</lastmod><priority>${priority(r)}</priority></url>`).join('\n')}
</urlset>
`;
await writeCompressed(path.join(dist, 'sitemap.xml'), sitemap);

// ---------- llms.txt (GEO: concise, factual summary for AI assistants / answer engines) ----------
const lines = [
    '# ConaPay',
    '',
    `> ConaPay is a payment gateway that gives merchants local pay-in (collection) and payout channels in ${COVERAGE_STATS.markets} markets across Africa, the Americas, Asia Pacific, Europe and the Middle East. Funds are settled in USDT, and many channels settle D+0 (same day).`,
    '',
    `- Pay-in methods: ${COVERAGE_STATS.payinMethods}`,
    `- Markets with payouts: ${COVERAGE_STATS.payoutMarkets}`,
    `- Currencies: ${COVERAGE_STATS.currencies}`,
    `- Contact sales: ${SITE_URL}/contact`,
    `- Developer docs: ${SITE_URL}/developers`,
    '',
];
for (const region of REGIONS) {
    const markets = MARKETS.filter((m) => m.region === region.key);
    if (!markets.length) continue;
    lines.push(`## ${region.en}`, '');
    for (const m of markets) {
        const via = m.networks ? `USDT on ${m.networks.join(', ')}` : m.payin.join(', ');
        lines.push(`- [${m.name.en} (${m.currency})](${SITE_URL}/payment-methods/${m.slug}): pay-in via ${via}; payout ${hasPayout(m) ? 'supported' : 'not yet available'}`);
    }
    lines.push('');
}
await writeCompressed(path.join(dist, 'llms.txt'), lines.join('\n'));

await fs.rm(ssrDir, { recursive: true, force: true });
console.log(`✓ prerendered ${count} routes, sitemap.xml and llms.txt`);
